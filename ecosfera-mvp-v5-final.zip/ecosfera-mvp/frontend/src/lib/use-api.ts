"use client";
import { useState, useEffect, useCallback, useRef } from "react";
import { ApiError } from "@/lib/api";

type State<T> = {
  data: T | null;
  loading: boolean;
  error: string | null;
};

// Хук для GET-запросов с автозапуском
export function useApi<T>(
  fetcher: () => Promise<T>,
  deps: unknown[] = []
): State<T> & { refetch: () => void } {
  const [state, setState] = useState<State<T>>({ data: null, loading: true, error: null });
  const mountedRef = useRef(true);

  const run = useCallback(async () => {
    setState((s) => ({ ...s, loading: true, error: null }));
    try {
      const data = await fetcher();
      if (mountedRef.current) setState({ data, loading: false, error: null });
    } catch (e) {
      if (mountedRef.current) {
        setState({ data: null, loading: false, error: e instanceof ApiError ? e.message : "Ошибка запроса" });
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);

  useEffect(() => {
    mountedRef.current = true;
    run();
    return () => { mountedRef.current = false; };
  }, [run]);

  return { ...state, refetch: run };
}

// Хук для мутаций (POST / PATCH / DELETE) — не запускается автоматически
export function useMutation<TArgs, TResult>(
  mutator: (args: TArgs) => Promise<TResult>
): {
  mutate: (args: TArgs) => Promise<TResult>;
  loading: boolean;
  error: string | null;
  reset: () => void;
} {
  const [loading, setLoading] = useState(false);
  const [error, setError]     = useState<string | null>(null);

  const mutate = useCallback(async (args: TArgs): Promise<TResult> => {
    setLoading(true);
    setError(null);
    try {
      const result = await mutator(args);
      return result;
    } catch (e) {
      const msg = e instanceof ApiError ? e.message : "Ошибка запроса";
      setError(msg);
      throw e;
    } finally {
      setLoading(false);
    }
  }, [mutator]);

  return { mutate, loading, error, reset: () => setError(null) };
}
