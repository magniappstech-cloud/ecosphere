// lib/api.ts — Централизованный API клиент
const BASE_URL = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:4000";

type RequestOptions = RequestInit & {
  token?: string;
};

class ApiError extends Error {
  constructor(
    public status: number,
    public data: { error: string; issues?: unknown[] }
  ) {
    super(data.error);
  }
}

async function request<T>(path: string, opts: RequestOptions = {}): Promise<T> {
  const { token, ...init } = opts;

  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...(init.headers as Record<string, string>),
  };

  const res = await fetch(`${BASE_URL}${path}`, { ...init, headers });

  if (!res.ok) {
    const data = await res.json().catch(() => ({ error: res.statusText }));
    throw new ApiError(res.status, data);
  }

  return res.json() as Promise<T>;
}

// ─── Auth ──────────────────────────────────────────────────────
export const authApi = {
  register: (body: { name: string; email: string; password: string }) =>
    request<{ user: User; accessToken: string; refreshToken: string }>("/auth/register", {
      method: "POST", body: JSON.stringify(body),
    }),

  login: (body: { email: string; password: string }) =>
    request<{ user: User; accessToken: string; refreshToken: string }>("/auth/login", {
      method: "POST", body: JSON.stringify(body),
    }),

  refresh: (refreshToken: string) =>
    request<{ accessToken: string; refreshToken: string }>("/auth/refresh", {
      method: "POST", body: JSON.stringify({ refreshToken }),
    }),

  logout: (refreshToken: string) =>
    request("/auth/logout", { method: "POST", body: JSON.stringify({ refreshToken }) }),

  me: (token: string) => request<User>("/auth/me", { token }),
};

// ─── Articles ─────────────────────────────────────────────────
export const articlesApi = {
  list: (params?: { tag?: string; limit?: number; offset?: number }, token?: string) => {
    const q = new URLSearchParams(params as Record<string, string>).toString();
    return request<{ articles: Article[]; total: number }>(`/articles${q ? `?${q}` : ""}`, { token });
  },

  my: (token: string) => request<Article[]>("/articles/my", { token }),

  get: (slug: string, token?: string) =>
    request<Article>(`/articles/${slug}`, { token }),

  getById: (id: string, token?: string) =>
    request<Article>(`/articles/id/${id}`, { token }),

  create: (body: Partial<Article>, token: string) =>
    request<Article>("/articles", { method: "POST", body: JSON.stringify(body), token }),

  update: (id: string, body: Partial<Article>, token: string) =>
    request<Article>(`/articles/${id}`, { method: "PATCH", body: JSON.stringify(body), token }),

  delete: (id: string, token: string) =>
    request(`/articles/${id}`, { method: "DELETE", token }),

  like: (id: string, token: string) =>
    request<{ id: string; likes: number }>(`/articles/${id}/like`, { method: "POST", token }),
};

// ─── Projects ─────────────────────────────────────────────────
export const projectsApi = {
  list: (params?: { stage?: string; limit?: number }) => {
    const q = new URLSearchParams(params as Record<string, string>).toString();
    return request<{ projects: Project[]; total: number }>(`/projects${q ? `?${q}` : ""}`);
  },

  get: (id: string) => request<Project>(`/projects/${id}`),

  create: (body: Partial<Project>, token: string) =>
    request<Project>("/projects", { method: "POST", body: JSON.stringify(body), token }),

  update: (id: string, body: Partial<Project>, token: string) =>
    request<Project>(`/projects/${id}`, { method: "PATCH", body: JSON.stringify(body), token }),

  myOwned: (token: string) => request<Project[]>("/projects/my/owned", { token }),

  myMember: (token: string) => request<Project[]>("/projects/my/member", { token }),

  sendRequest: (id: string, message: string, token: string) =>
    request("/projects/:id/request".replace(":id", id), {
      method: "POST", body: JSON.stringify({ message }), token,
    }),

  getRequests: (id: string, token: string) =>
    request<ProjectRequest[]>(`/projects/${id}/requests`, { token }),

  reviewRequest: (projectId: string, reqId: string, status: "APPROVED" | "REJECTED", token: string) =>
    request(`/projects/${projectId}/requests/${reqId}`, {
      method: "PATCH", body: JSON.stringify({ status }), token,
    }),
};

// ─── Users ─────────────────────────────────────────────────────
export const usersApi = {
  get: (id: string) => request<User>(`/users/${id}`),
  stats: (token: string) => request<DashboardStats>("/users/dashboard/stats", { token }),
  updateMe: (body: Partial<User>, token: string) =>
    request<User>("/users/me", { method: "PATCH", body: JSON.stringify(body), token }),
};

// ─── Types ─────────────────────────────────────────────────────
export type User = {
  id: string; name: string; email: string; avatarUrl?: string;
  bio?: string; role: "USER" | "EDITOR" | "ADMIN"; createdAt: string;
};

export type Article = {
  id: string; title: string; slug: string; lead?: string;
  content: Block[]; coverImage?: string; status: "DRAFT" | "PUBLISHED" | "ARCHIVED";
  tag: string; views: number; likes: number; readTime: number;
  authorId: string; author?: User; projectId?: string;
  createdAt: string; updatedAt: string;
};

export type Block = { type: string; text?: string; items?: string[] };

export type Project = {
  id: string; title: string; description: string;
  stage: "IDEA" | "PLANNING" | "ACTIVE" | "COMPLETED";
  status: "ACTIVE" | "PAUSED" | "ARCHIVED";
  location?: string; emoji?: string;
  ownerId: string; owner?: User; members?: ProjectMember[];
  createdAt: string;
};

export type ProjectMember = {
  id: string; role: "OWNER" | "EDITOR" | "MEMBER";
  userId: string; user?: User; projectId: string;
};

export type ProjectRequest = {
  id: string; message: string; status: "PENDING" | "APPROVED" | "REJECTED";
  userId: string; user?: User; projectId: string; createdAt: string;
};

export type DashboardStats = {
  articles: { published: number; drafts: number; totalViews: number; totalLikes: number };
  projects: { owned: number; pendingRequests: number };
};

export { ApiError };
