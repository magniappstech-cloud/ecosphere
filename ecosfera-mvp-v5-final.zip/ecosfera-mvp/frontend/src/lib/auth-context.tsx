"use client";
import { createContext, useContext, useEffect, useState, useCallback } from "react";
import { authApi, type User } from "@/lib/api";

type AuthState = {
  user: User | null;
  accessToken: string | null;
  loading: boolean;
};

type AuthContextType = AuthState & {
  login: (email: string, password: string) => Promise<void>;
  register: (name: string, email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
};

const AuthContext = createContext<AuthContextType | null>(null);

const STORAGE_KEY = "ecosfera_auth";

// Вспомогательные функции для cookie (middleware читает их серверно)
function setCookie(name: string, value: string, days = 7) {
  const expires = new Date(Date.now() + days * 864e5).toUTCString();
  document.cookie = `${name}=${encodeURIComponent(value)};expires=${expires};path=/;SameSite=Lax`;
}
function deleteCookie(name: string) {
  document.cookie = `${name}=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/`;
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<AuthState>({ user: null, accessToken: null, loading: true });

  // Восстановить сессию при загрузке
  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (!stored) { setState((s) => ({ ...s, loading: false })); return; }

    try {
      const { refreshToken } = JSON.parse(stored);
      authApi.refresh(refreshToken)
        .then(({ accessToken, refreshToken: newRefresh }) => {
          localStorage.setItem(STORAGE_KEY, JSON.stringify({ refreshToken: newRefresh }));
          return authApi.me(accessToken).then((user) => {
            setState({ user, accessToken, loading: false });
          });
        })
        .catch(() => {
          localStorage.removeItem(STORAGE_KEY);
          setState({ user: null, accessToken: null, loading: false });
        });
    } catch {
      setState((s) => ({ ...s, loading: false }));
    }
  }, []);

  const setSession = useCallback((user: User, accessToken: string, refreshToken: string) => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ refreshToken }));
    setCookie("ecosfera_access", accessToken, 1);   // 1 день — короткий, refresh обновит
    setState({ user, accessToken, loading: false });
  }, []);

  const login = useCallback(async (email: string, password: string) => {
    const res = await authApi.login({ email, password });
    setSession(res.user, res.accessToken, res.refreshToken);
  }, [setSession]);

  const register = useCallback(async (name: string, email: string, password: string) => {
    const res = await authApi.register({ name, email, password });
    setSession(res.user, res.accessToken, res.refreshToken);
  }, [setSession]);

  const logout = useCallback(async () => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      const { refreshToken } = JSON.parse(stored);
      await authApi.logout(refreshToken).catch(() => {});
    }
    localStorage.removeItem(STORAGE_KEY);
    deleteCookie("ecosfera_access");
    setState({ user: null, accessToken: null, loading: false });
  }, []);

  return (
    <AuthContext.Provider value={{ ...state, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside AuthProvider");
  return ctx;
}

// Хук для защищённых страниц
export function useRequireAuth() {
  const auth = useAuth();
  if (!auth.loading && !auth.user) {
    if (typeof window !== "undefined") window.location.href = "/login";
  }
  return auth;
}
