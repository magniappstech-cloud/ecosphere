"use client";
import { useState, useEffect, useRef, useCallback } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";

type SearchResult = {
  articles?: { id: string; title: string; slug: string; tag: string; author?: { name: string } }[];
  projects?: { id: string; title: string; stage: string; emoji?: string }[];
  news?:     { id: string; title: string; category: string }[];
  total:     number;
};

let debounceTimer: ReturnType<typeof setTimeout>;

export default function GlobalSearch() {
  const [open,    setOpen]    = useState(false);
  const [query,   setQuery]   = useState("");
  const [results, setResults] = useState<SearchResult | null>(null);
  const [loading, setLoading] = useState(false);
  const inputRef  = useRef<HTMLInputElement>(null);
  const router    = useRouter();

  // Cmd+K / Ctrl+K открывает поиск
  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        setOpen(o => !o);
      }
      if (e.key === "Escape") setOpen(false);
    }
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, []);

  useEffect(() => {
    if (open) setTimeout(() => inputRef.current?.focus(), 50);
    else { setQuery(""); setResults(null); }
  }, [open]);

  const search = useCallback((q: string) => {
    if (!q.trim()) { setResults(null); return; }
    setLoading(true);
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(async () => {
      try {
        const res = await fetch(
          `${process.env.NEXT_PUBLIC_API_URL}/search?q=${encodeURIComponent(q)}&limit=5`
        );
        if (res.ok) setResults(await res.json());
      } catch {
        /* silent */
      } finally {
        setLoading(false);
      }
    }, 300);
  }, []);

  function handleChange(e: React.ChangeEvent<HTMLInputElement>) {
    setQuery(e.target.value);
    search(e.target.value);
  }

  const hasResults = results && results.total > 0;

  if (!open) {
    return (
      <button
        onClick={() => setOpen(true)}
        className="flex items-center gap-2 rounded-lg border border-white/10 bg-white/3 px-3 py-1.5 text-sm text-slate-500 hover:border-white/20 hover:text-slate-300 transition"
      >
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
        Поиск
        <kbd className="ml-1 rounded bg-white/5 px-1.5 py-0.5 text-xs text-slate-600">⌘K</kbd>
      </button>
    );
  }

  return (
    // Backdrop
    <div
      className="fixed inset-0 z-50 flex items-start justify-center pt-20 px-4"
      style={{ background: "rgba(7,14,26,0.85)" }}
      onClick={() => setOpen(false)}
    >
      <div
        className="w-full max-w-xl rounded-xl border border-white/10 bg-[#0B1F3A] shadow-2xl"
        onClick={e => e.stopPropagation()}
      >
        {/* Input */}
        <div className="flex items-center gap-3 px-4 py-3 border-b border-white/8">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="text-slate-500 shrink-0">
            <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
          </svg>
          <input
            ref={inputRef}
            value={query}
            onChange={handleChange}
            placeholder="Поиск по статьям, проектам, новостям…"
            className="flex-1 bg-transparent text-sm text-slate-200 placeholder:text-slate-500 outline-none"
          />
          {loading && <div className="h-4 w-4 animate-spin rounded-full border-2 border-white/10 border-t-brand" />}
          <kbd className="rounded bg-white/5 px-1.5 py-0.5 text-xs text-slate-600">ESC</kbd>
        </div>

        {/* Results */}
        <div className="max-h-96 overflow-y-auto">
          {!query && (
            <div className="px-4 py-8 text-center text-sm text-slate-500">
              Начните вводить запрос…
            </div>
          )}

          {query && !hasResults && !loading && (
            <div className="px-4 py-8 text-center text-sm text-slate-500">
              Ничего не найдено по запросу «{query}»
            </div>
          )}

          {hasResults && (
            <div className="p-2">
              {/* Articles */}
              {(results.articles?.length ?? 0) > 0 && (
                <div className="mb-3">
                  <div className="px-3 py-1.5 text-xs font-medium text-slate-500 uppercase tracking-wider">Статьи</div>
                  {results.articles!.map(a => (
                    <Link key={a.id} href={`/articles/${a.slug}`} onClick={() => setOpen(false)}
                      className="flex items-center gap-3 rounded-lg px-3 py-2.5 hover:bg-white/5 transition group">
                      <span className="text-base">📝</span>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm text-slate-200 group-hover:text-brand transition truncate">{a.title}</p>
                        <p className="text-xs text-slate-500">{a.author?.name} · {a.tag}</p>
                      </div>
                    </Link>
                  ))}
                </div>
              )}

              {/* Projects */}
              {(results.projects?.length ?? 0) > 0 && (
                <div className="mb-3">
                  <div className="px-3 py-1.5 text-xs font-medium text-slate-500 uppercase tracking-wider">Проекты</div>
                  {results.projects!.map(p => (
                    <Link key={p.id} href={`/projects/${p.id}`} onClick={() => setOpen(false)}
                      className="flex items-center gap-3 rounded-lg px-3 py-2.5 hover:bg-white/5 transition group">
                      <span className="text-base">{p.emoji ?? "🚀"}</span>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm text-slate-200 group-hover:text-brand transition truncate">{p.title}</p>
                        <p className="text-xs text-slate-500">{p.stage}</p>
                      </div>
                    </Link>
                  ))}
                </div>
              )}

              {/* News */}
              {(results.news?.length ?? 0) > 0 && (
                <div className="mb-1">
                  <div className="px-3 py-1.5 text-xs font-medium text-slate-500 uppercase tracking-wider">Новости</div>
                  {results.news!.map(n => (
                    <div key={n.id}
                      className="flex items-center gap-3 rounded-lg px-3 py-2.5 hover:bg-white/5 transition cursor-default">
                      <span className="text-base">📰</span>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm text-slate-200 truncate">{n.title}</p>
                        <p className="text-xs text-slate-500">{n.category}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center gap-3 px-4 py-2 border-t border-white/8 text-xs text-slate-600">
          <span>↑↓ навигация</span>
          <span>↵ открыть</span>
          <span>ESC закрыть</span>
          {results && <span className="ml-auto">{results.total} результатов</span>}
        </div>
      </div>
    </div>
  );
}
