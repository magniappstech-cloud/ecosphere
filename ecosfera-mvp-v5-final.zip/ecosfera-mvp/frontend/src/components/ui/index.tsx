// components/ui/index.tsx — атомарные UI-компоненты

export function Spinner({ size = "md" }: { size?: "sm" | "md" | "lg" }) {
  const s = { sm: "h-4 w-4", md: "h-6 w-6", lg: "h-10 w-10" }[size];
  return (
    <div className={`${s} animate-spin rounded-full border-2 border-white/10 border-t-brand`} />
  );
}

export function PageSpinner() {
  return (
    <div className="flex h-64 items-center justify-center">
      <Spinner size="lg" />
    </div>
  );
}

export function Alert({
  type = "error",
  message,
}: {
  type?: "error" | "success" | "info";
  message: string;
}) {
  const cls = {
    error:   "bg-red-500/10 border-red-500/20 text-red-300",
    success: "bg-brand/10 border-brand/20 text-brand",
    info:    "bg-blue-500/10 border-blue-500/20 text-blue-300",
  }[type];
  return (
    <div className={`rounded-lg border px-4 py-3 text-sm ${cls}`}>{message}</div>
  );
}

export function EmptyState({ icon, title, sub }: { icon: string; title: string; sub?: string }) {
  return (
    <div className="flex flex-col items-center gap-3 py-16 text-center">
      <span className="text-4xl">{icon}</span>
      <p className="font-medium text-slate-300">{title}</p>
      {sub && <p className="text-sm text-slate-500">{sub}</p>}
    </div>
  );
}

export function StatCard({
  label,
  value,
  icon,
  sub,
}: {
  label: string;
  value: string | number;
  icon: string;
  sub?: string;
}) {
  return (
    <div className="card flex flex-col gap-1">
      <div className="flex items-center justify-between">
        <span className="text-xs text-slate-500 uppercase tracking-wider">{label}</span>
        <span className="text-lg">{icon}</span>
      </div>
      <span className="text-2xl font-semibold tabular-nums">
        {typeof value === "number" ? value.toLocaleString("ru-RU") : value}
      </span>
      {sub && <span className="text-xs text-slate-500">{sub}</span>}
    </div>
  );
}

export function StatusBadge({ status }: { status: string }) {
  const map: Record<string, string> = {
    DRAFT:     "badge-draft",
    PUBLISHED: "badge-published",
    ARCHIVED:  "badge-archived",
    IDEA:      "badge-idea",
    PLANNING:  "badge-planning",
    ACTIVE:    "badge-active",
    COMPLETED: "badge-completed",
  };
  const labels: Record<string, string> = {
    DRAFT: "Черновик", PUBLISHED: "Опубликована", ARCHIVED: "Архив",
    IDEA: "Идея", PLANNING: "Планирование", ACTIVE: "Активен", COMPLETED: "Завершён",
  };
  return (
    <span className={map[status] ?? "badge bg-slate-700 text-slate-400"}>
      {labels[status] ?? status}
    </span>
  );
}

// Скелетон-строки для таблиц
export function SkeletonRows({ rows = 4, cols = 3 }: { rows?: number; cols?: number }) {
  return (
    <>
      {Array.from({ length: rows }).map((_, i) => (
        <tr key={i} className="border-b border-white/5">
          {Array.from({ length: cols }).map((__, j) => (
            <td key={j} className="py-3 pr-4">
              <div className="h-4 w-full animate-pulse rounded bg-white/5" />
            </td>
          ))}
        </tr>
      ))}
    </>
  );
}

export function SkeletonCard() {
  return (
    <div className="card animate-pulse space-y-3">
      <div className="h-5 w-2/3 rounded bg-white/5" />
      <div className="h-3 w-full rounded bg-white/5" />
      <div className="h-3 w-4/5 rounded bg-white/5" />
    </div>
  );
}
