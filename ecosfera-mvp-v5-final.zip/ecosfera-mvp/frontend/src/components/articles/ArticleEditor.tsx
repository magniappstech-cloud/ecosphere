"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/lib/auth-context";
import { articlesApi, type Article, type Block } from "@/lib/api";
import { Alert, Spinner } from "@/components/ui";
import { z } from "zod";

const Schema = z.object({
  title: z.string().min(3, "Минимум 3 символа").max(200),
  lead:  z.string().max(500).optional(),
  tag:   z.enum(["iso", "ecology", "safety", "energy", "culture", "general"]),
  readTime: z.coerce.number().int().min(1).max(60),
});

const TAGS = [
  { value: "iso",      label: "ISO / ГОСТ" },
  { value: "ecology",  label: "Экология" },
  { value: "safety",   label: "Охрана труда" },
  { value: "energy",   label: "Энергетика" },
  { value: "culture",  label: "Культура" },
  { value: "general",  label: "Общее" },
];

type EditorProps = {
  initial?: Partial<Article>;
  mode: "create" | "edit";
};

export default function ArticleEditor({ initial, mode }: EditorProps) {
  const router = useRouter();
  const { accessToken } = useAuth();

  const [title,    setTitle]    = useState(initial?.title    ?? "");
  const [lead,     setLead]     = useState(initial?.lead     ?? "");
  const [tag,      setTag]      = useState<string>(initial?.tag ?? "general");
  const [readTime, setReadTime] = useState(initial?.readTime ?? 5);
  const [blocks,   setBlocks]   = useState<Block[]>(
    initial?.content ?? [{ type: "paragraph", text: "" }]
  );

  const [saving,  setSaving]  = useState<"draft" | "publish" | null>(null);
  const [error,   setError]   = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  // ── Block helpers ──────────────────────────────────────────
  function addBlock(type: Block["type"]) {
    setBlocks((b) => [...b, { type, text: "", items: type === "list" ? [""] : undefined }]);
  }

  function updateBlock(idx: number, patch: Partial<Block>) {
    setBlocks((b) => b.map((bl, i) => (i === idx ? { ...bl, ...patch } : bl)));
  }

  function removeBlock(idx: number) {
    setBlocks((b) => b.filter((_, i) => i !== idx));
  }

  // ── Save ───────────────────────────────────────────────────
  async function save(status: "DRAFT" | "PUBLISHED") {
    setError(null);
    setSuccess(null);

    const parsed = Schema.safeParse({ title, lead, tag, readTime });
    if (!parsed.success) {
      setError(parsed.error.errors[0].message);
      return;
    }

    setSaving(status === "DRAFT" ? "draft" : "publish");
    try {
      const payload = { title, lead, tag, readTime: Number(readTime), content: blocks, status };

      if (mode === "create") {
        const art = await articlesApi.create(payload, accessToken!);
        router.push(`/dashboard/articles/${art.id}/edit?saved=1`);
      } else {
        await articlesApi.update(initial!.id!, payload, accessToken!);
        setSuccess(status === "PUBLISHED" ? "Опубликовано!" : "Черновик сохранён");
      }
    } catch (e: any) {
      setError(e.message ?? "Ошибка сохранения");
    } finally {
      setSaving(null);
    }
  }

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      {/* Meta */}
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="text-xs text-slate-400 mb-1 block">Рубрика</label>
          <select
            value={tag}
            onChange={(e) => setTag(e.target.value)}
            className="input"
          >
            {TAGS.map((t) => <option key={t.value} value={t.value}>{t.label}</option>)}
          </select>
        </div>
        <div>
          <label className="text-xs text-slate-400 mb-1 block">Время чтения (мин)</label>
          <input
            type="number" min={1} max={60}
            value={readTime}
            onChange={(e) => setReadTime(Number(e.target.value))}
            className="input"
          />
        </div>
      </div>

      {/* Title */}
      <div>
        <label className="text-xs text-slate-400 mb-1 block">Заголовок *</label>
        <input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Введите заголовок статьи…"
          className="input text-lg font-medium"
        />
      </div>

      {/* Lead */}
      <div>
        <label className="text-xs text-slate-400 mb-1 block">Лид-абзац</label>
        <textarea
          value={lead}
          onChange={(e) => setLead(e.target.value)}
          placeholder="Краткий анонс статьи — 1-2 предложения"
          rows={2}
          className="input resize-none"
        />
      </div>

      {/* Blocks */}
      <div>
        <label className="text-xs text-slate-400 mb-2 block">Содержание *</label>
        <div className="space-y-3">
          {blocks.map((block, idx) => (
            <BlockEditor
              key={idx}
              block={block}
              onChange={(p) => updateBlock(idx, p)}
              onRemove={blocks.length > 1 ? () => removeBlock(idx) : undefined}
            />
          ))}
        </div>

        {/* Toolbar */}
        <div className="flex flex-wrap gap-2 mt-3 pt-3 border-t border-white/8">
          {[
            { type: "paragraph", label: "¶ Текст" },
            { type: "heading",   label: "H Заголовок" },
            { type: "quote",     label: "❝ Цитата" },
            { type: "list",      label: "≡ Список" },
          ].map((t) => (
            <button
              key={t.type}
              onClick={() => addBlock(t.type as Block["type"])}
              className="btn-ghost text-xs px-3 py-1.5"
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {/* Alerts */}
      {error   && <Alert type="error"   message={error} />}
      {success && <Alert type="success" message={success} />}

      {/* Actions */}
      <div className="flex gap-3 justify-end pt-4 border-t border-white/8">
        <button
          onClick={() => save("DRAFT")}
          disabled={!!saving}
          className="btn-ghost"
        >
          {saving === "draft" ? <Spinner size="sm" /> : null}
          Сохранить черновик
        </button>
        <button
          onClick={() => save("PUBLISHED")}
          disabled={!!saving}
          className="btn-primary"
        >
          {saving === "publish" ? <Spinner size="sm" /> : null}
          Опубликовать →
        </button>
      </div>
    </div>
  );
}

// ── Single block editor ─────────────────────────────────────
function BlockEditor({
  block,
  onChange,
  onRemove,
}: {
  block: Block;
  onChange: (p: Partial<Block>) => void;
  onRemove?: () => void;
}) {
  const base = "input resize-none w-full";

  return (
    <div className="group relative rounded-lg border border-white/8 bg-white/2 p-3">
      {block.type === "heading" && (
        <input
          value={block.text ?? ""}
          onChange={(e) => onChange({ text: e.target.value })}
          placeholder="Заголовок раздела"
          className={`${base} font-semibold text-base bg-transparent border-none p-0 focus:ring-0`}
        />
      )}
      {block.type === "paragraph" && (
        <textarea
          value={block.text ?? ""}
          onChange={(e) => onChange({ text: e.target.value })}
          placeholder="Введите текст…"
          rows={3}
          className={`${base} bg-transparent border-none p-0 focus:ring-0`}
        />
      )}
      {block.type === "quote" && (
        <textarea
          value={block.text ?? ""}
          onChange={(e) => onChange({ text: e.target.value })}
          placeholder="Цитата"
          rows={2}
          className={`${base} bg-transparent border-none p-0 focus:ring-0 italic text-slate-300 border-l-2 border-brand pl-3`}
        />
      )}
      {block.type === "list" && (
        <div className="space-y-1.5">
          {(block.items ?? [""]).map((item, i) => (
            <div key={i} className="flex items-center gap-2">
              <span className="text-brand text-xs">•</span>
              <input
                value={item}
                onChange={(e) => {
                  const items = [...(block.items ?? [])];
                  items[i] = e.target.value;
                  onChange({ items });
                }}
                className="flex-1 bg-transparent text-sm outline-none placeholder:text-slate-600"
                placeholder={`Пункт ${i + 1}`}
              />
            </div>
          ))}
          <button
            onClick={() => onChange({ items: [...(block.items ?? []), ""] })}
            className="text-xs text-slate-500 hover:text-brand transition"
          >
            + Добавить пункт
          </button>
        </div>
      )}

      {/* Type badge */}
      <span className="absolute top-2 right-8 text-xs text-slate-600">{block.type}</span>

      {/* Remove */}
      {onRemove && (
        <button
          onClick={onRemove}
          className="absolute top-1.5 right-2 text-slate-600 hover:text-red-400 opacity-0 group-hover:opacity-100 transition text-sm"
        >
          ✕
        </button>
      )}
    </div>
  );
}
