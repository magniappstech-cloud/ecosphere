import { NextRequest, NextResponse } from "next/server";

// Маршруты требующие авторизации
const PROTECTED = ["/dashboard", "/admin"];

// Маршруты только для гостей (редирект если уже залогинен)
const GUEST_ONLY = ["/login", "/register"];

export function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;

  // Проверяем наличие токена через cookie (устанавливается при логине)
  // Используем httpOnly cookie "ecosfera_access" для серверной проверки
  const token = req.cookies.get("ecosfera_access")?.value;

  const isProtected = PROTECTED.some((p) => pathname.startsWith(p));
  const isGuestOnly = GUEST_ONLY.some((p) => pathname.startsWith(p));

  // Не авторизован → редирект на /login
  if (isProtected && !token) {
    const url = req.nextUrl.clone();
    url.pathname = "/login";
    url.searchParams.set("from", pathname); // сохраняем откуда пришли
    return NextResponse.redirect(url);
  }

  // Уже залогинен → редирект на /dashboard
  if (isGuestOnly && token) {
    const url = req.nextUrl.clone();
    url.pathname = "/dashboard";
    return NextResponse.redirect(url);
  }

  return NextResponse.next();
}

export const config = {
  // Применяем middleware только к нужным маршрутам (исключаем _next, api, статику)
  matcher: [
    "/dashboard/:path*",
    "/admin/:path*",
    "/login",
    "/register",
  ],
};
