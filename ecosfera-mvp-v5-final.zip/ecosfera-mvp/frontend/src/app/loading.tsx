export default function Loading() {
  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="flex flex-col items-center gap-4">
        <div className="h-10 w-10 animate-spin rounded-full border-2 border-white/10 border-t-brand" />
        <p className="text-sm text-slate-500">Загрузка…</p>
      </div>
    </div>
  );
}
