"use client";
import { useState, useEffect, useCallback } from "react";
import Link from "next/link";
import { articlesApi, type Article } from "@/lib/api";
import { PageSpinner, Alert, StatusBadge, EmptyState } from "@/components/ui";

const TAGS = [
  { value: "all",     label: "Все" },
  { value: "iso",     label: "ISO / ГОСТ" },
  { value: "ecology", label: "Экология" },
  { value: "safety",  label: "Охрана труда" },
  { value: "energy",  label: "Энергетика" },
  { value: "culture", label: "Культура" },
];

const SORT = [
  { value: "newest",  label: "Сначала новые" },
  { value: "popular", label: "Популярные" },
  { value: "reading", label: "Быстрые (до 5 мин)" },
];

export default function ArticlesPage() {
  const [articles,    setArticles]    = useState<Article[]>([]);
  const [total,       setTotal]       = useState(0);
  const [loading,     setLoading]     = useState(true);
  const [error,       setError]       = useState<string | null>(null);
  const [tag,         setTag]         = useState("all");
  const [sort,        setSort]        = useState("newest");
  const [search,      setSearch]      = useState("");
  const [searchInput, setSearchInput] = useState("");
  const [offset,      setOffset]      = useState(0);
  const LIMIT = 12;

  const load = useCallback(async (reset = false) => {
    setLoading(true);
    setError(null);
    try {
      const params: Record<string, any> = {
        limit:  LIMIT,
        offset: reset ? 0 : offset,
        ...(tag !== "all" && { tag }),
      };
      const data = await articlesApi.list(params);
      if (reset) {
        setArticles(data.articles);
        setOffset(LIMIT);
      } else {
        setArticles((prev) => [...prev, ...data.articles]);
        setOffset((o) => o + LIMIT);
      }
      setTotal(data.total);
    } catch (e: any) {
      setError(e.message ?? "Ошибка загрузки");
    } finally {
      setLoading(false);
    }
  }, [tag, offset]);

  useEffect(() => {
    load(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tag]);

  // Клиентская фильтрация поиска и сортировки
  const filtered = articles
    .filter((a) =>
      !search ||
      a.title.toLowerCase().includes(search.toLowerCase()) ||
      (a.lead ?? "").toLowerCase().includes(search.toLowerCase())
    )
    .sort((a, b) => {
      if (sort === "popular") return b.views - a.views;
      if (sort === "reading") return a.readTime - b.readTime;
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });

  const hasMore = articles.length < total;

  return (
    <div className="min-h-screen">
      {/* Nav */}
      <header className="border-b border-white/8 bg-[#070E1A]/90 backdrop-blur-sm sticky top-0 z-20">
        <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <span className="text-xl">🌿</span>
            <span className="font-display font-semibold text-brand">ЭкоСфера</span>
          </Link>
          <nav className="flex items-center gap-6 text-sm text-slate-400">
            <Link href="/articles" className="text-white">Статьи</Link>
            <Link href="/projects" className="hover:text-white transition">Проекты</Link>
          </nav>
          <Link href="/dashboard" className="btn-primary text-sm px-4 py-2">Кабинет</Link>
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-6 py-10 space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-display font-bold">Статьи</h1>
          <p className="text-slate-400 mt-2">Глубокая аналитика от экспертов платформы</p>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-3 items-center">
          {/* Search */}
          <div className="relative flex-1 min-w-[200px] max-w-xs">
            <svg className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
            <input
              type="search"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && setSearch(searchInput)}
              placeholder="Поиск…"
              className="input pl-9"
            />
          </div>

          {/* Tags */}
          <div className="flex flex-wrap gap-2">
            {TAGS.map((t) => (
              <button
                key={t.value}
                onClick={() => { setTag(t.value); setOffset(0); }}
                className={`px-3 py-1.5 rounded-full text-xs font-medium border transition ${
                  tag === t.value
                    ? "bg-brand/15 border-brand/30 text-brand"
                    : "border-white/10 text-slate-400 hover:border-white/20"
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>

          {/* Sort */}
          <select value={sort} onChange={(e) => setSort(e.target.value)} className="input w-auto text-sm">
            {SORT.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
          </select>
        </div>

        {/* Error */}
        {error && <Alert type="error" message={error} />}

        {/* Articles grid */}
        {loading && articles.length === 0 ? (
          <PageSpinner />
        ) : filtered.length === 0 ? (
          <EmptyState icon="📝" title="Статей не найдено" sub="Попробуйте другой тег или запрос" />
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
            {filtered.map((a) => (
              <Link
                key={a.id}
                href={`/articles/${a.slug}`}
                className="card hover:border-brand/30 transition group flex flex-col"
              >
                {a.coverImage && (
                  <div className="aspect-video rounded-lg overflow-hidden bg-surface-2 mb-3 -mx-1">
                    <img src={a.coverImage} alt="" className="w-full h-full object-cover" loading="lazy" />
                  </div>
                )}
                <div className="flex items-center gap-2 mb-2">
                  <span className="badge bg-white/5 text-slate-400 text-xs">{a.tag}</span>
                  <span className="text-xs text-slate-500">{a.readTime} мин</span>
                </div>
                <h3 className="font-medium text-sm group-hover:text-brand transition leading-snug mb-2 flex-1">
                  {a.title}
                </h3>
                {a.lead && (
                  <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed mb-3">{a.lead}</p>
                )}
                {/* Author */}
                {a.author && (
                  <div className="flex items-center gap-2 pt-3 border-t border-white/5">
                    <div className="h-6 w-6 rounded-full bg-brand/20 flex items-center justify-center text-xs font-medium text-brand">
                      {a.author.name.charAt(0)}
                    </div>
                    <span className="text-xs text-slate-500 truncate">{a.author.name}</span>
                    <div className="ml-auto flex items-center gap-2 text-xs text-slate-600">
                      <span>👁️ {a.views.toLocaleString("ru-RU")}</span>
                      <span>❤️ {a.likes}</span>
                    </div>
                  </div>
                )}
              </Link>
            ))}
          </div>
        )}

        {/* Load more */}
        {hasMore && !loading && (
          <div className="text-center">
            <button onClick={() => load(false)} className="btn-ghost px-8">
              Загрузить ещё
            </button>
          </div>
        )}
        {loading && articles.length > 0 && (
          <div className="flex justify-center py-4">
            <div className="h-6 w-6 animate-spin rounded-full border-2 border-white/10 border-t-brand" />
          </div>
        )}
      </div>
    </div>
  );
}
