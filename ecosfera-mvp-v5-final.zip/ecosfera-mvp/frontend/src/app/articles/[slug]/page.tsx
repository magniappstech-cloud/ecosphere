import type { Metadata } from "next";
import ArticleReaderClient from "./ArticleReaderClient";

const API = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:4000";

// Генерируем SEO-метаданные на сервере
export async function generateMetadata(
  { params }: { params: { slug: string } }
): Promise<Metadata> {
  try {
    const res = await fetch(`${API}/articles/${params.slug}`, { next: { revalidate: 3600 } });
    if (!res.ok) return { title: "Статья не найдена" };
    const article = await res.json();
    return {
      title:       `${article.title} — ЭкоСфера Безопасности`,
      description: article.lead ?? "Статья на портале ЭкоСфера Безопасности",
      openGraph: {
        title:       article.title,
        description: article.lead ?? "",
        type:        "article",
        images:      article.coverImage ? [{ url: article.coverImage }] : [],
        publishedTime: article.createdAt,
        authors:     article.author ? [article.author.name] : [],
      },
    };
  } catch {
    return { title: "ЭкоСфера Безопасности" };
  }
}

export default function ArticlePage({ params }: { params: { slug: string } }) {
  return <ArticleReaderClient slug={params.slug} />;
}

