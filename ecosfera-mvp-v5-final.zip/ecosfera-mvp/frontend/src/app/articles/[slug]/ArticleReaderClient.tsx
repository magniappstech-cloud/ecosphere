"use client";
import { useState } from "react";
import Link from "next/link";
import { useAuth } from "@/lib/auth-context";
import { useApi, useMutation } from "@/lib/use-api";
import { articlesApi, type Block } from "@/lib/api";
import { PageSpinner, Alert, StatusBadge } from "@/components/ui";

export default function ArticleReaderClient({ slug }: { slug: string }) {
  const { user, accessToken } = useAuth();

  const { data: article, loading, error } = useApi(
    () => articlesApi.get(slug),
    [slug]
  );

  const [liked,     setLiked]     = useState(false);
  const [likeCount, setLikeCount] = useState<number | null>(null);

  const { mutate: doLike, loading: liking } = useMutation(() =>
    articlesApi.like(article!.id, accessToken!)
  );

  async function handleLike() {
    if (!user || liked) return;
    const res = await doLike(undefined as any);
    setLiked(true);
    setLikeCount((res as any).likes);
  }

  if (loading) return <PageSpinner />;
  if (error)   return <div className="p-8 max-w-3xl mx-auto"><Alert type="error" message={error} /></div>;
  if (!article) return null;

  const likes = likeCount ?? article.likes;

  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-10 border-b border-white/8 bg-[#070E1A]/90 backdrop-blur-sm">
        <div className="max-w-4xl mx-auto px-6 py-3 flex items-center gap-3">
          <Link href="/" className="text-brand font-display font-semibold text-sm">🌿 ЭкоСфера</Link>
          <span className="text-white/20">/</span>
          <Link href="/articles" className="text-slate-400 text-sm hover:text-brand transition">Статьи</Link>
          <span className="text-white/20">/</span>
          <span className="text-slate-400 text-sm truncate">{article.title}</span>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-6 py-12 space-y-8">
        <div className="space-y-4">
          <div className="flex flex-wrap gap-2">
            <StatusBadge status={article.status} />
            <span className="badge bg-white/5 text-slate-400">{article.tag}</span>
            <span className="badge bg-white/5 text-slate-400">{article.readTime} мин</span>
          </div>
          <h1 className="text-3xl font-display font-bold leading-tight">{article.title}</h1>
          {article.lead && <p className="text-lg text-slate-400 leading-relaxed">{article.lead}</p>}
          {article.author && (
            <div className="flex items-center gap-3 pt-2 border-t border-white/8">
              <div className="h-9 w-9 rounded-full bg-brand/20 flex items-center justify-center text-sm font-semibold text-brand">
                {article.author.name.charAt(0)}
              </div>
              <div>
                <p className="text-sm font-medium">{article.author.name}</p>
                <p className="text-xs text-slate-500">
                  {new Date(article.createdAt).toLocaleDateString("ru-RU", { day: "numeric", month: "long", year: "numeric" })}
                  {" · "}👁️ {article.views.toLocaleString("ru-RU")}
                </p>
              </div>
            </div>
          )}
        </div>

        {article.coverImage && (
          <div className="aspect-video rounded-xl overflow-hidden bg-surface-2">
            <img src={article.coverImage} alt="" className="w-full h-full object-cover" />
          </div>
        )}

        <div className="space-y-5">
          {(article.content ?? []).map((block: Block, i: number) => (
            <BlockRenderer key={i} block={block} />
          ))}
        </div>

        <div className="flex items-center gap-4 pt-6 border-t border-white/8">
          <button onClick={handleLike} disabled={liking || liked || !user}
            className={`flex items-center gap-2 rounded-full px-4 py-2 text-sm font-medium border transition ${
              liked ? "border-red-500/30 bg-red-500/10 text-red-400"
                    : "border-white/10 hover:border-red-500/30 hover:bg-red-500/5 hover:text-red-400"
            } disabled:opacity-40`}>
            {liked ? "❤️" : "🤍"} {likes}
          </button>
          <button onClick={() => navigator.clipboard.writeText(window.location.href)} className="btn-ghost text-sm">
            Скопировать ссылку
          </button>
          {!user && (
            <Link href="/login" className="ml-auto text-xs text-slate-500 hover:text-brand transition">
              Войдите чтобы ставить лайки →
            </Link>
          )}
        </div>

        {article.project && (
          <Link href={`/projects/${article.project.id}`}
            className="card flex items-center gap-3 hover:border-brand/30 transition">
            <span className="text-2xl">🚀</span>
            <div>
              <p className="text-xs text-slate-500 uppercase tracking-wider">Проект</p>
              <p className="text-sm font-medium">{(article.project as any).title}</p>
            </div>
            <span className="ml-auto text-slate-500">→</span>
          </Link>
        )}
      </main>
    </div>
  );
}

function BlockRenderer({ block }: { block: Block }) {
  switch (block.type) {
    case "heading":   return <h2 className="text-xl font-display font-semibold mt-8 mb-2">{block.text}</h2>;
    case "paragraph": return <p className="text-slate-300 leading-relaxed">{block.text}</p>;
    case "quote":     return <blockquote className="border-l-2 border-brand pl-5 py-1 text-slate-300 italic">{block.text}</blockquote>;
    case "list":      return <ul className="space-y-1.5 text-slate-300">{(block.items ?? []).map((item, i) => <li key={i} className="flex items-start gap-2"><span className="text-brand mt-1 shrink-0">•</span>{item}</li>)}</ul>;
    case "image":     return block.text ? <div className="rounded-xl overflow-hidden bg-surface-2"><img src={block.text} alt="" className="w-full" /></div> : null;
    default:          return <p className="text-slate-400 text-sm">{block.text}</p>;
  }
}
