import Link from "next/link";

export default function NotFound() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center gap-6 text-center p-8">
      <div className="text-7xl">🌿</div>
      <div>
        <h1 className="text-4xl font-display font-bold text-brand mb-2">404</h1>
        <p className="text-xl font-medium text-slate-300">Страница не найдена</p>
        <p className="text-slate-500 mt-2 max-w-sm mx-auto">
          Возможно, страница была удалена или вы перешли по неверной ссылке.
        </p>
      </div>
      <div className="flex gap-3">
        <Link href="/" className="btn-primary px-6 py-2.5">На главную</Link>
        <Link href="/articles" className="btn-ghost px-6 py-2.5">Статьи</Link>
      </div>
    </div>
  );
}
