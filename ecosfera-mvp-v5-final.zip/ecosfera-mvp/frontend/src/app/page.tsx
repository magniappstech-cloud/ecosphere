"use client";
import Link from "next/link";
import { useAuth } from "@/lib/auth-context";
import { useApi } from "@/lib/use-api";
import { articlesApi, projectsApi } from "@/lib/api";

export default function HomePage() {
  const { user } = useAuth();

  const { data: articlesData } = useApi(
    () => articlesApi.list({ limit: 3 }),
    []
  );
  const { data: projectsData } = useApi(
    () => projectsApi.list({ limit: 3 }),
    []
  );

  const articles = articlesData?.articles ?? [];
  const projects = projectsData?.projects ?? [];

  return (
    <div className="min-h-screen">
      {/* ── Nav ── */}
      <header className="border-b border-white/8 bg-[#070E1A]/90 backdrop-blur-sm sticky top-0 z-20">
        <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <span className="text-xl">🌿</span>
            <span className="font-display font-semibold text-brand tracking-tight">ЭкоСфера</span>
          </Link>
          <nav className="hidden md:flex items-center gap-6 text-sm text-slate-400">
            <Link href="/articles" className="hover:text-white transition">Статьи</Link>
            <Link href="/projects" className="hover:text-white transition">Проекты</Link>
          </nav>
          <div className="flex items-center gap-3">
            {user ? (
              <Link href="/dashboard" className="btn-primary text-sm px-4 py-2">
                Кабинет →
              </Link>
            ) : (
              <>
                <Link href="/login" className="btn-ghost text-sm px-4 py-2">Войти</Link>
                <Link href="/register" className="btn-primary text-sm px-4 py-2">Регистрация</Link>
              </>
            )}
          </div>
        </div>
      </header>

      {/* ── Hero ── */}
      <section className="max-w-6xl mx-auto px-6 pt-20 pb-16 text-center">
        <div className="inline-flex items-center gap-2 rounded-full border border-brand/20 bg-brand/5 px-4 py-1.5 text-xs text-brand mb-8">
          <span className="h-1.5 w-1.5 rounded-full bg-brand animate-pulse"></span>
          Портал культуры безопасности
        </div>
        <h1 className="font-display text-4xl md:text-6xl font-bold leading-tight mb-6">
          Безопасность —<br />
          <span className="text-brand">культура будущего</span>
        </h1>
        <p className="text-slate-400 text-lg max-w-2xl mx-auto mb-10 leading-relaxed">
          Объединяем экспертов, проекты и знания. Создаём пространство, где безопасность становится частью жизни каждого.
        </p>
        <div className="flex items-center justify-center gap-4 flex-wrap">
          <Link href="/register" className="btn-primary text-base px-8 py-3">
            Присоединиться →
          </Link>
          <Link href="/articles" className="btn-ghost text-base px-8 py-3">
            Читать статьи
          </Link>
        </div>
      </section>

      {/* ── Articles preview ── */}
      {articles.length > 0 && (
        <section className="max-w-6xl mx-auto px-6 py-12 border-t border-white/5">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-xl font-display font-semibold">Последние статьи</h2>
            <Link href="/articles" className="text-sm text-brand hover:underline">Все статьи →</Link>
          </div>
          <div className="grid md:grid-cols-3 gap-5">
            {articles.map((a) => (
              <Link
                key={a.id}
                href={`/articles/${a.slug}`}
                className="card hover:border-brand/30 transition group"
              >
                <div className="flex items-center gap-2 mb-3">
                  <span className="badge bg-white/5 text-slate-400 text-xs">{a.tag}</span>
                  <span className="text-xs text-slate-500">{a.readTime} мин</span>
                </div>
                <h3 className="font-medium text-sm group-hover:text-brand transition leading-snug mb-2">
                  {a.title}
                </h3>
                {a.lead && (
                  <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">{a.lead}</p>
                )}
                <div className="flex items-center gap-3 mt-3 text-xs text-slate-600">
                  <span>👁️ {a.views.toLocaleString("ru-RU")}</span>
                  <span>❤️ {a.likes}</span>
                </div>
              </Link>
            ))}
          </div>
        </section>
      )}

      {/* ── Projects preview ── */}
      {projects.length > 0 && (
        <section className="max-w-6xl mx-auto px-6 py-12 border-t border-white/5">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-xl font-display font-semibold">Активные проекты</h2>
            <Link href="/projects" className="text-sm text-brand hover:underline">Все проекты →</Link>
          </div>
          <div className="grid md:grid-cols-3 gap-5">
            {projects.map((p: any) => (
              <Link
                key={p.id}
                href={`/projects/${p.id}`}
                className="card hover:border-brand/30 transition group"
              >
                <div className="flex items-start gap-3">
                  <span className="text-2xl">{p.emoji ?? "🌿"}</span>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-medium text-sm group-hover:text-brand transition truncate">
                      {p.title}
                    </h3>
                    <p className="text-xs text-slate-500 mt-1 line-clamp-2">{p.description}</p>
                    <div className="flex items-center gap-2 mt-2">
                      <span className={`badge-${p.stage.toLowerCase()} badge`}>{p.stage}</span>
                      {p.location && (
                        <span className="text-xs text-slate-500">📍 {p.location}</span>
                      )}
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </section>
      )}

      {/* ── CTA ── */}
      <section className="max-w-6xl mx-auto px-6 py-16 border-t border-white/5 text-center">
        <h2 className="font-display text-2xl font-semibold mb-4">
          Готовы присоединиться?
        </h2>
        <p className="text-slate-400 text-sm mb-8">
          Создайте аккаунт и станьте частью сообщества экспертов по безопасности
        </p>
        <Link href="/register" className="btn-primary text-base px-8 py-3">
          Создать аккаунт бесплатно
        </Link>
      </section>

      {/* ── Footer ── */}
      <footer className="border-t border-white/8 py-8">
        <div className="max-w-6xl mx-auto px-6 flex items-center justify-between text-xs text-slate-600">
          <span>© 2026 ЭкоСфера Безопасности</span>
          <span>MagniApps Tech</span>
        </div>
      </footer>
    </div>
  );
}
