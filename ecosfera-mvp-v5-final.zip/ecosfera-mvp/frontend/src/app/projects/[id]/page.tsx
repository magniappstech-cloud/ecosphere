"use client";
import { useState } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import { useAuth } from "@/lib/auth-context";
import { useApi, useMutation } from "@/lib/use-api";
import { projectsApi } from "@/lib/api";
import {
  PageSpinner, Alert, StatusBadge, EmptyState, Spinner,
} from "@/components/ui";

export default function ProjectDetailPage() {
  const { id } = useParams<{ id: string }>();
  const { user, accessToken } = useAuth();

  const { data: project, loading, error } = useApi(
    () => projectsApi.get(id),
    [id]
  );

  const [message, setMessage] = useState("");
  const [sent,    setSent]    = useState(false);

  const { mutate: sendRequest, loading: sending, error: sendErr } = useMutation(
    (msg: string) => projectsApi.sendRequest(id, msg, accessToken!)
  );

  const isOwner   = project?.ownerId === user?.id;
  const isMember  = project?.members?.some((m) => m.userId === user?.id);
  const canJoin   = !!user && !isOwner && !isMember;

  async function handleJoin() {
    if (!message.trim()) return;
    await sendRequest(message);
    setSent(true);
  }

  if (loading) return <PageSpinner />;
  if (error)   return <div className="p-8"><Alert type="error" message={error} /></div>;
  if (!project) return null;

  return (
    <div className="max-w-4xl mx-auto px-6 py-10 space-y-8">
      {/* Header */}
      <div className="flex items-start gap-4">
        <span className="text-5xl">{project.emoji ?? "🌿"}</span>
        <div className="flex-1 min-w-0">
          <div className="flex flex-wrap items-center gap-2 mb-1">
            <h1 className="text-2xl font-display font-semibold">{project.title}</h1>
            <StatusBadge status={project.stage} />
            <StatusBadge status={project.status} />
          </div>
          <p className="text-slate-400 text-sm">
            Автор: {project.owner?.name}
            {project.location && <> · 📍 {project.location}</>}
            {" · "}
            {new Date(project.createdAt).toLocaleDateString("ru-RU")}
          </p>
        </div>

        {isOwner && (
          <Link href={`/dashboard/projects/${id}`} className="btn-ghost text-sm shrink-0">
            Управление
          </Link>
        )}
      </div>

      {/* Description */}
      <div className="card">
        <h2 className="text-sm font-medium text-slate-400 uppercase tracking-wider mb-3">
          О проекте
        </h2>
        <p className="text-slate-300 leading-relaxed whitespace-pre-wrap">{project.description}</p>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        {/* Members */}
        <div className="md:col-span-2 space-y-4">
          <h2 className="font-medium">👥 Участники ({project.members?.length ?? 0})</h2>
          {project.members?.length === 0 ? (
            <EmptyState icon="👥" title="Участников пока нет" />
          ) : (
            <div className="space-y-2">
              {project.members?.map((m) => (
                <div key={m.id} className="card flex items-center gap-3 py-3">
                  <div className="h-9 w-9 rounded-full bg-brand/20 flex items-center justify-center text-sm font-semibold text-brand shrink-0">
                    {m.user?.name?.charAt(0) ?? "?"}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium">{m.user?.name}</p>
                  </div>
                  <span className={`badge ${
                    m.role === "OWNER"  ? "badge-active" :
                    m.role === "EDITOR" ? "badge-planning" : "badge-draft"
                  }`}>
                    {m.role}
                  </span>
                </div>
              ))}
            </div>
          )}

          {/* Articles */}
          {project.articles && project.articles.length > 0 && (
            <div>
              <h2 className="font-medium mb-3">📝 Статьи проекта</h2>
              <div className="space-y-2">
                {project.articles.map((a: any) => (
                  <Link
                    key={a.id}
                    href={`/articles/${a.slug}`}
                    className="card flex items-center gap-3 hover:border-brand/30 transition"
                  >
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{a.title}</p>
                      <p className="text-xs text-slate-500 mt-0.5">
                        {a.readTime} мин · 👁️ {a.views}
                      </p>
                    </div>
                    <span className="text-slate-500 text-xs">→</span>
                  </Link>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Join sidebar */}
        <div className="space-y-4">
          {isMember && (
            <div className="card border-brand/20 bg-brand/5 text-center">
              <p className="text-brand font-medium text-sm">✓ Вы участник проекта</p>
            </div>
          )}

          {canJoin && !sent && (
            <div className="card space-y-3">
              <h3 className="font-medium text-sm">Вступить в проект</h3>
              <textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Расскажите, чем хотите помочь проекту…"
                rows={4}
                className="input resize-none text-sm"
              />
              {sendErr && <Alert type="error" message={sendErr} />}
              <button
                onClick={handleJoin}
                disabled={sending || !message.trim()}
                className="btn-primary w-full justify-center"
              >
                {sending ? <Spinner size="sm" /> : null}
                Отправить заявку
              </button>
            </div>
          )}

          {sent && (
            <Alert type="success" message="Заявка отправлена! Ждите ответа от автора." />
          )}

          {!user && (
            <div className="card text-center space-y-3">
              <p className="text-sm text-slate-400">Войдите чтобы подать заявку</p>
              <Link href="/login" className="btn-primary w-full justify-center">
                Войти
              </Link>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
