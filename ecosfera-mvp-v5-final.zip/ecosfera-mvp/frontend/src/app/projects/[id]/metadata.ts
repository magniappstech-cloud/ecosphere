import type { Metadata } from "next";

const API = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:4000";

export async function generateProjectMetadata(id: string): Promise<Metadata> {
  try {
    const res = await fetch(`${API}/projects/${id}`, { next: { revalidate: 3600 } });
    if (!res.ok) return { title: "Проект не найден" };
    const project = await res.json();
    return {
      title:       `${project.title} — ЭкоСфера Безопасности`,
      description: project.description?.slice(0, 160) ?? "Проект на платформе ЭкоСфера",
      openGraph: {
        title:       project.title,
        description: project.description?.slice(0, 160) ?? "",
        type:        "website",
      },
    };
  } catch {
    return { title: "ЭкоСфера Безопасности" };
  }
}
