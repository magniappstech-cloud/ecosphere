"use client";
import { useState } from "react";
import Link from "next/link";
import { useApi } from "@/lib/use-api";
import { projectsApi } from "@/lib/api";
import { PageSpinner, Alert, StatusBadge, EmptyState, SkeletonCard } from "@/components/ui";

const STAGES = [
  { value: "all",       label: "Все" },
  { value: "IDEA",      label: "Идея" },
  { value: "PLANNING",  label: "Планирование" },
  { value: "ACTIVE",    label: "Активные" },
  { value: "COMPLETED", label: "Завершённые" },
];

export default function ProjectsPage() {
  const [stage, setStage] = useState("all");

  const { data, loading, error } = useApi(
    () => projectsApi.list({ limit: 24 }),
    []
  );

  const all = data?.projects ?? [];
  const filtered = stage === "all" ? all : all.filter((p: any) => p.stage === stage);

  return (
    <div className="min-h-screen">
      {/* Nav */}
      <header className="border-b border-white/8 bg-[#070E1A]/90 backdrop-blur-sm sticky top-0 z-20">
        <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <span className="text-xl">🌿</span>
            <span className="font-display font-semibold text-brand">ЭкоСфера</span>
          </Link>
          <nav className="flex items-center gap-6 text-sm text-slate-400">
            <Link href="/articles" className="hover:text-white transition">Статьи</Link>
            <Link href="/projects" className="text-white">Проекты</Link>
          </nav>
          <Link href="/dashboard" className="btn-primary text-sm px-4 py-2">Кабинет</Link>
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-6 py-10 space-y-8">
        {/* Header */}
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div>
            <h1 className="text-3xl font-display font-bold">Проекты</h1>
            <p className="text-slate-400 mt-2">
              {data?.total ?? 0} проектов в сообществе
            </p>
          </div>
          <Link href="/dashboard/projects/create" className="btn-primary">
            + Создать проект
          </Link>
        </div>

        {/* Stage filter */}
        <div className="flex flex-wrap gap-2">
          {STAGES.map((s) => (
            <button
              key={s.value}
              onClick={() => setStage(s.value)}
              className={`px-3 py-1.5 rounded-full text-xs font-medium border transition ${
                stage === s.value
                  ? "bg-brand/15 border-brand/30 text-brand"
                  : "border-white/10 text-slate-400 hover:border-white/20"
              }`}
            >
              {s.label}
            </button>
          ))}
        </div>

        {error && <Alert type="error" message={error} />}

        {/* Projects grid */}
        {loading ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
            {[...Array(6)].map((_, i) => <SkeletonCard key={i} />)}
          </div>
        ) : filtered.length === 0 ? (
          <EmptyState icon="🚀" title="Проектов не найдено" sub="Попробуйте другой фильтр" />
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
            {filtered.map((p: any) => (
              <Link
                key={p.id}
                href={`/projects/${p.id}`}
                className="card hover:border-brand/30 transition group flex flex-col gap-3"
              >
                <div className="flex items-start gap-3">
                  <span className="text-3xl leading-none">{p.emoji ?? "🌿"}</span>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-medium group-hover:text-brand transition leading-snug">
                      {p.title}
                    </h3>
                    <p className="text-xs text-slate-500 mt-1 line-clamp-2 leading-relaxed">
                      {p.description}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                  <StatusBadge status={p.stage} />
                  {p.location && (
                    <span className="text-xs text-slate-500">📍 {p.location}</span>
                  )}
                </div>

                <div className="flex items-center justify-between pt-3 border-t border-white/5 text-xs text-slate-500">
                  <span>👥 {p.members?.length ?? 0} участников</span>
                  <span>{new Date(p.createdAt).toLocaleDateString("ru-RU", { day: "numeric", month: "short" })}</span>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
