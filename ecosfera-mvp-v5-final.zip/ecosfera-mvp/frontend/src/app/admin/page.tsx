"use client";
import Link from "next/link";
import { useAuth } from "@/lib/auth-context";
import { useApi } from "@/lib/use-api";
import { StatCard, PageSpinner } from "@/components/ui";

export default function AdminPage() {
  const { accessToken } = useAuth();

  const { data: stats, loading } = useApi(
    () => fetch(`${process.env.NEXT_PUBLIC_API_URL}/stats/public`).then(r => r.json()),
    []
  );
  const { data: initData } = useApi(
    () => fetch(`${process.env.NEXT_PUBLIC_API_URL}/initiatives?limit=1`,
      { headers: { Authorization: `Bearer ${accessToken}` } }).then(r => r.json()),
    [accessToken]
  );

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-xl font-display font-semibold">Панель администратора</h1>
        <p className="text-slate-400 text-sm mt-0.5">Управление платформой ЭкоСфера</p>
      </div>

      {loading ? <PageSpinner /> : stats && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <StatCard label="Пользователей" value={stats.users}     icon="👥" />
          <StatCard label="Проектов"      value={stats.projects}  icon="🚀" />
          <StatCard label="Статей"        value={stats.articles}  icon="📝" />
          <StatCard label="Стран"         value={stats.countries} icon="🌍" />
        </div>
      )}

      <div className="grid md:grid-cols-3 gap-4">
        {[
          { href: "/admin/users",       title: "Пользователи",  desc: "Назначение ролей и лидеров",    icon: "👥" },
          { href: "/admin/initiatives", title: "Инициативы",    desc: "Модерация заявок",              icon: "💡",
            badge: initData?.total ?? null },
          { href: "/admin/news",        title: "Новости",        desc: "Создание и публикация новостей", icon: "📰" },
        ].map((item) => (
          <Link key={item.href} href={item.href}
            className="card hover:border-brand/30 transition group">
            <div className="flex items-start justify-between mb-3">
              <span className="text-2xl">{item.icon}</span>
              {item.badge != null && item.badge > 0 && (
                <span className="badge bg-amber-500/15 text-amber-300 text-xs">
                  {item.badge} новых
                </span>
              )}
            </div>
            <p className="font-medium group-hover:text-brand transition">{item.title}</p>
            <p className="text-xs text-slate-500 mt-1">{item.desc}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
