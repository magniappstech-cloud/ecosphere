"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect } from "react";
import { useAuth } from "@/lib/auth-context";
import { Spinner } from "@/components/ui";

const NAV = [
  { href: "/admin",             label: "Обзор",        icon: "▦" },
  { href: "/admin/users",       label: "Пользователи", icon: "👥" },
  { href: "/admin/initiatives", label: "Инициативы",   icon: "💡" },
  { href: "/admin/news",        label: "Новости",      icon: "📰" },
];

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  const router   = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    if (!loading && (!user || user.role !== "ADMIN")) {
      router.replace("/dashboard");
    }
  }, [loading, user, router]);

  if (loading) return (
    <div className="flex h-screen items-center justify-center">
      <Spinner size="lg" />
    </div>
  );
  if (!user || user.role !== "ADMIN") return null;

  return (
    <div className="flex min-h-screen">
      <aside className="sticky top-0 h-screen w-52 shrink-0 border-r border-white/8 bg-surface-2 flex flex-col">
        <div className="flex items-center gap-2 px-5 py-5 border-b border-white/8">
          <span className="text-base">🛡️</span>
          <span className="font-display font-semibold text-sm tracking-tight">Администратор</span>
        </div>
        <nav className="flex-1 px-3 py-3 space-y-0.5">
          {NAV.map((item) => {
            const active = pathname === item.href;
            return (
              <Link key={item.href} href={item.href}
                className={`flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm transition ${
                  active ? "bg-brand/10 text-brand font-medium" : "text-slate-400 hover:text-slate-200 hover:bg-white/5"
                }`}>
                <span className="text-base w-5 text-center">{item.icon}</span>
                {item.label}
              </Link>
            );
          })}
        </nav>
        <div className="border-t border-white/8 p-4 space-y-2">
          <Link href="/dashboard" className="flex items-center gap-2 text-xs text-slate-500 hover:text-slate-300 transition px-3 py-2">
            ← Кабинет
          </Link>
        </div>
      </aside>
      <main className="flex-1 overflow-y-auto">
        <div className="max-w-5xl mx-auto px-6 py-8">{children}</div>
      </main>
    </div>
  );
}
