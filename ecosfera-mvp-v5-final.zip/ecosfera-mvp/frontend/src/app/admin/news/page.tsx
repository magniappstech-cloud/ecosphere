"use client";
import { useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { useApi } from "@/lib/use-api";
import { Alert, PageSpinner, EmptyState, Spinner } from "@/components/ui";
import { z } from "zod";

const Schema = z.object({
  title:      z.string().min(3).max(200),
  headline:   z.string().max(300).optional(),
  body:       z.string().min(10),
  category:   z.string(),
  authorName: z.string().min(2),
  readTime:   z.coerce.number().int().min(1).max(30).default(3),
  isSplash:   z.boolean().default(false),
});

const CATEGORIES = ["Экология","Энергетика","Наука","Города","Проекты","Культура","Охрана труда"];

export default function AdminNewsPage() {
  const { accessToken } = useAuth();
  const [creating, setCreating] = useState(false);
  const [saving,   setSaving]   = useState(false);
  const [error,    setError]    = useState<string | null>(null);

  const [form, setForm] = useState({
    title: "", headline: "", body: "", category: "Экология",
    authorName: "", readTime: 3, isSplash: false,
  });

  const { data, loading, refetch } = useApi(
    () => fetch(
      `${process.env.NEXT_PUBLIC_API_URL}/news?limit=20`,
      { headers: { Authorization: `Bearer ${accessToken}` } }
    ).then(r => r.json()),
    [accessToken]
  );

  const items: any[] = data?.items ?? (Array.isArray(data) ? data : []);

  function set(key: string, val: any) {
    setForm(f => ({ ...f, [key]: val }));
  }

  async function handleCreate() {
    setError(null);
    const parsed = Schema.safeParse(form);
    if (!parsed.success) { setError(parsed.error.errors[0].message); return; }
    setSaving(true);
    try {
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/news`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${accessToken}` },
        body: JSON.stringify(parsed.data),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error ?? "Ошибка");
      setCreating(false);
      setForm({ title:"", headline:"", body:"", category:"Экология", authorName:"", readTime:3, isSplash:false });
      refetch();
    } catch (e: any) {
      setError(e.message);
    } finally {
      setSaving(false);
    }
  }

  async function deleteNews(id: string) {
    if (!confirm("Удалить новость?")) return;
    await fetch(`${process.env.NEXT_PUBLIC_API_URL}/news/${id}`, {
      method: "DELETE",
      headers: { Authorization: `Bearer ${accessToken}` },
    });
    refetch();
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-display font-semibold">Новости</h1>
          <p className="text-slate-400 text-sm mt-0.5">Управление новостной лентой</p>
        </div>
        <button onClick={() => setCreating(c => !c)} className="btn-primary">
          {creating ? "Отмена" : "+ Добавить новость"}
        </button>
      </div>

      {/* Create form */}
      {creating && (
        <div className="card space-y-4">
          <h2 className="font-medium text-sm">Новая новость</h2>
          <div className="grid grid-cols-2 gap-4">
            <div><label className="text-xs text-slate-400 mb-1 block">Заголовок *</label>
              <input value={form.title} onChange={e => set("title", e.target.value)} className="input text-sm" placeholder="Заголовок новости" /></div>
            <div><label className="text-xs text-slate-400 mb-1 block">Рубрика</label>
              <select value={form.category} onChange={e => set("category", e.target.value)} className="input text-sm">
                {CATEGORIES.map(c => <option key={c}>{c}</option>)}
              </select></div>
          </div>
          <div><label className="text-xs text-slate-400 mb-1 block">Подзаголовок / deck</label>
            <input value={form.headline} onChange={e => set("headline", e.target.value)} className="input text-sm" placeholder="Краткий анонс" /></div>
          <div><label className="text-xs text-slate-400 mb-1 block">Текст *</label>
            <textarea value={form.body} onChange={e => set("body", e.target.value)} rows={5} className="input resize-none text-sm" placeholder="Содержание новости…" /></div>
          <div className="grid grid-cols-3 gap-4">
            <div><label className="text-xs text-slate-400 mb-1 block">Автор *</label>
              <input value={form.authorName} onChange={e => set("authorName", e.target.value)} className="input text-sm" placeholder="Имя автора" /></div>
            <div><label className="text-xs text-slate-400 mb-1 block">Время чтения (мин)</label>
              <input type="number" min={1} max={30} value={form.readTime} onChange={e => set("readTime", +e.target.value)} className="input text-sm" /></div>
            <div className="flex items-end pb-1">
              <label className="flex items-center gap-2 cursor-pointer text-sm">
                <input type="checkbox" checked={form.isSplash} onChange={e => set("isSplash", e.target.checked)} />
                <span className="text-slate-300">Главная новость</span>
              </label>
            </div>
          </div>
          {error && <Alert type="error" message={error} />}
          <div className="flex gap-3">
            <button onClick={handleCreate} disabled={saving} className="btn-primary">
              {saving ? <Spinner size="sm" /> : null} Опубликовать
            </button>
            <button onClick={() => setCreating(false)} className="btn-ghost">Отмена</button>
          </div>
        </div>
      )}

      {/* News list */}
      {loading ? <PageSpinner /> : items.length === 0 ? (
        <EmptyState icon="📰" title="Новостей нет" sub="Создайте первую новость" />
      ) : (
        <div className="space-y-3">
          {items.map((n: any) => (
            <div key={n.id} className="card flex items-start gap-3">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1 flex-wrap">
                  <span className="font-medium text-sm">{n.title}</span>
                  {n.isSplash && <span className="badge badge-published text-xs">Главная</span>}
                  <span className="badge bg-white/5 text-slate-400 text-xs">{n.category}</span>
                </div>
                {n.headline && <p className="text-xs text-slate-500 mb-1">{n.headline}</p>}
                <p className="text-xs text-slate-600">
                  {n.authorName} · {new Date(n.createdAt).toLocaleDateString("ru-RU")} · {n.readTime} мин
                </p>
              </div>
              <button onClick={() => deleteNews(n.id)} className="btn-danger text-xs px-2 py-1 shrink-0">
                Удалить
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
