"use client";
import { useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { useApi, useMutation } from "@/lib/use-api";
import { Alert, PageSpinner, Spinner } from "@/components/ui";

const ROLES = ["USER", "EDITOR", "LEADER", "ADMIN"] as const;
type Role = typeof ROLES[number];

const ROLE_COLORS: Record<Role, string> = {
  USER:   "badge-gray",
  EDITOR: "badge-info",
  LEADER: "badge-active",
  ADMIN:  "badge-published",
};

function fetchUsers(token: string) {
  return fetch(`${process.env.NEXT_PUBLIC_API_URL}/users?limit=100`,
    { headers: { Authorization: `Bearer ${token}` } }
  ).then(r => r.json());
}

export default function AdminUsersPage() {
  const { user: me, accessToken } = useAuth();
  const [search, setSearch] = useState("");
  const [updating, setUpdating] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<{ id: string; msg: string; ok: boolean } | null>(null);

  const { data, loading, error, refetch } = useApi(
    () => fetchUsers(accessToken!),
    [accessToken]
  );

  const users: any[] = Array.isArray(data) ? data : (data?.users ?? []);

  const filtered = users.filter(u =>
    !search ||
    u.name.toLowerCase().includes(search.toLowerCase()) ||
    u.email.toLowerCase().includes(search.toLowerCase())
  );

  async function changeRole(userId: string, role: Role) {
    setUpdating(userId);
    setFeedback(null);
    try {
      const res = await fetch(
        `${process.env.NEXT_PUBLIC_API_URL}/users/${userId}/role`,
        {
          method: "PATCH",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${accessToken}` },
          body: JSON.stringify({ role }),
        }
      );
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Ошибка");
      setFeedback({ id: userId, msg: `Роль изменена на ${role}`, ok: true });
      refetch();
    } catch (e: any) {
      setFeedback({ id: userId, msg: e.message, ok: false });
    } finally {
      setUpdating(null);
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-display font-semibold">Пользователи</h1>
          <p className="text-slate-400 text-sm mt-0.5">{users.length} зарегистрировано</p>
        </div>
        <input
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Поиск по имени или email…"
          className="input w-64 text-sm"
        />
      </div>

      {error && <Alert type="error" message={error} />}

      {loading ? <PageSpinner /> : (
        <div className="card p-0 overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-white/8 text-slate-500 text-xs uppercase tracking-wider">
                <th className="text-left px-5 py-3 font-medium">Пользователь</th>
                <th className="text-left px-4 py-3 font-medium">Email</th>
                <th className="text-left px-4 py-3 font-medium">Текущая роль</th>
                <th className="text-left px-4 py-3 font-medium">Изменить роль</th>
                <th className="px-4 py-3" />
              </tr>
            </thead>
            <tbody>
              {filtered.map((u) => {
                const isSelf = u.id === me?.id;
                return (
                  <tr key={u.id} className="border-b border-white/5 hover:bg-white/2 transition">
                    <td className="px-5 py-3">
                      <div className="flex items-center gap-2">
                        <div className="h-7 w-7 rounded-full bg-brand/20 flex items-center justify-center text-xs font-medium text-brand shrink-0">
                          {u.name?.charAt(0) ?? "?"}
                        </div>
                        <div>
                          <span className="font-medium">{u.name}</span>
                          {isSelf && <span className="ml-1 text-xs text-slate-500">(вы)</span>}
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-slate-400 text-xs">{u.email}</td>
                    <td className="px-4 py-3">
                      <span className={`badge ${ROLE_COLORS[u.role as Role] ?? "badge-gray"}`}>
                        {u.role}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      {!isSelf && (
                        <select
                          value={u.role}
                          onChange={e => changeRole(u.id, e.target.value as Role)}
                          disabled={updating === u.id}
                          className="input py-1 text-xs w-36"
                        >
                          {ROLES.map(r => <option key={r} value={r}>{r}</option>)}
                        </select>
                      )}
                    </td>
                    <td className="px-4 py-3 text-xs">
                      {updating === u.id && <Spinner size="sm" />}
                      {feedback?.id === u.id && (
                        <span className={feedback.ok ? "text-brand" : "text-red-400"}>
                          {feedback.msg}
                        </span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      <div className="card bg-amber-500/5 border-amber-500/20">
        <p className="text-sm text-amber-300 font-medium mb-1">Роль LEADER</p>
        <p className="text-xs text-slate-400 leading-relaxed">
          Пользователь с ролью LEADER отображается в карусели лидеров на главной странице.
          Заполните поля <code className="text-xs bg-white/5 px-1 rounded">quote</code> и <code className="text-xs bg-white/5 px-1 rounded">emoji</code> через PATCH /users/:id/leader-profile.
          Карточка лидера активна только если у него есть опубликованные статьи.
        </p>
      </div>
    </div>
  );
}
