"use client";
import { useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { useApi } from "@/lib/use-api";
import { Alert, PageSpinner, EmptyState, Spinner } from "@/components/ui";

const STATUS_LABELS: Record<string, string> = {
  PENDING:   "Новая",
  REVIEWING: "На рассмотрении",
  APPROVED:  "Одобрена",
  REJECTED:  "Отклонена",
};
const STATUS_BADGE: Record<string, string> = {
  PENDING:   "badge-amber",
  REVIEWING: "badge-info",
  APPROVED:  "badge-published",
  REJECTED:  "badge-bad",
};

export default function AdminInitiativesPage() {
  const { accessToken } = useAuth();
  const [filter, setFilter] = useState("PENDING");
  const [updating, setUpdating] = useState<string | null>(null);

  const { data, loading, error, refetch } = useApi(
    () => fetch(
      `${process.env.NEXT_PUBLIC_API_URL}/initiatives?status=${filter}&limit=50`,
      { headers: { Authorization: `Bearer ${accessToken}` } }
    ).then(r => r.json()),
    [filter, accessToken]
  );

  const items: any[] = data?.items ?? [];

  async function updateStatus(id: string, status: string) {
    setUpdating(id);
    try {
      await fetch(`${process.env.NEXT_PUBLIC_API_URL}/initiatives/${id}/status`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${accessToken}` },
        body: JSON.stringify({ status }),
      });
      refetch();
    } finally {
      setUpdating(null);
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-display font-semibold">Инициативы</h1>
        <p className="text-slate-400 text-sm mt-0.5">Модерация заявок от пользователей</p>
      </div>

      {/* Filter tabs */}
      <div className="flex gap-1 border-b border-white/8">
        {["PENDING","REVIEWING","APPROVED","REJECTED"].map(s => (
          <button key={s} onClick={() => setFilter(s)}
            className={`px-4 py-2 text-sm border-b-2 -mb-px transition ${
              filter === s ? "border-brand text-brand font-medium" : "border-transparent text-slate-500 hover:text-slate-300"
            }`}>
            {STATUS_LABELS[s]}
          </button>
        ))}
      </div>

      {error && <Alert type="error" message={error} />}
      {loading ? <PageSpinner /> : items.length === 0 ? (
        <EmptyState icon="💡" title="Инициатив нет" sub={`Нет заявок со статусом «${STATUS_LABELS[filter]}»`} />
      ) : (
        <div className="space-y-3">
          {items.map((item: any) => (
            <div key={item.id} className="card space-y-3">
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap mb-1">
                    <span className="font-medium">{item.name}</span>
                    <span className={`badge ${STATUS_BADGE[item.status] ?? "badge-gray"}`}>
                      {STATUS_LABELS[item.status] ?? item.status}
                    </span>
                    <span className="badge bg-white/5 text-slate-400">{item.category}</span>
                  </div>
                  <p className="text-xs text-slate-500">
                    Автор: {item.authorName} · {new Date(item.createdAt).toLocaleDateString("ru-RU")}
                  </p>
                </div>
              </div>

              <div className="space-y-2 text-sm">
                <div><span className="text-xs text-slate-500 uppercase tracking-wider">Описание:</span><p className="text-slate-300 mt-0.5">{item.shortDesc}</p></div>
                <div><span className="text-xs text-slate-500 uppercase tracking-wider">Проблема:</span><p className="text-slate-300 mt-0.5">{item.problem}</p></div>
                <div><span className="text-xs text-slate-500 uppercase tracking-wider">Решение:</span><p className="text-slate-300 mt-0.5">{item.solution}</p></div>
                {item.location && <p className="text-xs text-slate-500">📍 {item.location}{item.duration ? ` · ${item.duration}` : ""}</p>}
              </div>

              {filter === "PENDING" && (
                <div className="flex gap-2 pt-2 border-t border-white/8">
                  <button onClick={() => updateStatus(item.id, "REVIEWING")} disabled={!!updating}
                    className="btn-ghost text-xs">
                    {updating === item.id ? <Spinner size="sm" /> : "На рассмотрение"}
                  </button>
                  <button onClick={() => updateStatus(item.id, "APPROVED")} disabled={!!updating}
                    className="btn-primary text-xs">
                    ✓ Одобрить
                  </button>
                  <button onClick={() => updateStatus(item.id, "REJECTED")} disabled={!!updating}
                    className="btn-danger text-xs">
                    ✕ Отклонить
                  </button>
                </div>
              )}
              {filter === "REVIEWING" && (
                <div className="flex gap-2 pt-2 border-t border-white/8">
                  <button onClick={() => updateStatus(item.id, "APPROVED")} disabled={!!updating}
                    className="btn-primary text-xs">✓ Одобрить</button>
                  <button onClick={() => updateStatus(item.id, "REJECTED")} disabled={!!updating}
                    className="btn-danger text-xs">✕ Отклонить</button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
