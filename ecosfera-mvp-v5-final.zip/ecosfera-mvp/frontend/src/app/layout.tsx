import type { Metadata } from "next";
import { Inter, Syne } from "next/font/google";
import { AuthProvider } from "@/lib/auth-context";
import "./globals.css";

const inter = Inter({ subsets: ["latin", "cyrillic"], variable: "--f-body" });
const syne  = Syne({ subsets: ["latin"], variable: "--f-display" });

export const metadata: Metadata = {
  title: {
    default:  "ЭкоСфера Безопасности",
    template: "%s — ЭкоСфера",
  },
  description: "Портал культуры безопасности — наука, практика, творчество. Объединяем экспертов и проекты.",
  metadataBase: new URL(process.env.NEXT_PUBLIC_BASE_URL ?? "http://localhost:3000"),
  openGraph: {
    siteName:    "ЭкоСфера Безопасности",
    locale:      "ru_RU",
    type:        "website",
    images: [{ url: "/og-image.svg", width: 1200, height: 630, alt: "ЭкоСфера Безопасности" }],
  },
  twitter: {
    card:  "summary_large_image",
    title: "ЭкоСфера Безопасности",
    images: ["/og-image.svg"],
  },
  icons: {
    icon:  [{ url: "/favicon.svg", type: "image/svg+xml" }],
    apple: "/favicon.svg",
  },
  manifest: "/site.webmanifest",
  themeColor: "#2AF598",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ru" className={`${inter.variable} ${syne.variable}`}>
      <body className="font-sans">
        <AuthProvider>{children}</AuthProvider>
      </body>
    </html>
  );
}
