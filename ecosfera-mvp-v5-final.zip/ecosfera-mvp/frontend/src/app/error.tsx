"use client";
import { useEffect } from "react";
import Link from "next/link";

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error("[GlobalError]", error);
  }, [error]);

  return (
    <div className="min-h-screen flex flex-col items-center justify-center gap-6 text-center p-8">
      <div className="text-7xl">⚠️</div>
      <div>
        <h1 className="text-2xl font-display font-semibold text-slate-300 mb-2">Что-то пошло не так</h1>
        <p className="text-slate-500 max-w-sm mx-auto">
          Произошла непредвиденная ошибка. Попробуйте обновить страницу.
        </p>
        {process.env.NODE_ENV === "development" && (
          <pre className="mt-4 text-left text-xs text-red-400 bg-red-500/10 border border-red-500/20 rounded-lg p-4 max-w-lg overflow-auto">
            {error.message}
          </pre>
        )}
      </div>
      <div className="flex gap-3">
        <button onClick={reset} className="btn-primary px-6 py-2.5">Попробовать снова</button>
        <Link href="/" className="btn-ghost px-6 py-2.5">На главную</Link>
      </div>
    </div>
  );
}
