"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect } from "react";
import { useAuth } from "@/lib/auth-context";
import { Spinner } from "@/components/ui";
import GlobalSearch from "@/components/ui/GlobalSearch";

const NAV = [
  { href: "/dashboard",           label: "Профиль",     icon: "👤" },
  { href: "/dashboard/articles",  label: "Мои статьи",  icon: "📝" },
  { href: "/dashboard/drafts",    label: "Черновики",   icon: "🗒️" },
  { href: "/dashboard/projects",  label: "Проекты",     icon: "🚀" },
  { href: "/dashboard/stats",     label: "Статистика",  icon: "📊" },
  { href: "/dashboard/settings",  label: "Настройки",   icon: "⚙️" },
];

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const { user, loading, logout } = useAuth();
  const router   = useRouter();
  const pathname = usePathname();

  // Редирект если не авторизован
  useEffect(() => {
    if (!loading && !user) router.replace("/login");
  }, [loading, user, router]);

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <Spinner size="lg" />
      </div>
    );
  }

  if (!user) return null;

  return (
    <div className="flex min-h-screen">
      {/* ── Sidebar ── */}
      <aside className="sticky top-0 h-screen w-60 shrink-0 border-r border-white/8 bg-surface-2 flex flex-col">
        {/* Logo */}
        <div className="flex items-center gap-2 px-5 py-5 border-b border-white/8">
          <span className="text-lg">🌿</span>
          <span className="font-display font-semibold text-brand tracking-tight">ЭкоСфера</span>
        </div>

        {/* Search */}
        <div className="px-3 pb-3">
          <GlobalSearch />
        </div>

        {/* Nav */}
        <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-0.5">
          {NAV.map((item) => {
            const active = pathname === item.href;
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm transition ${
                  active
                    ? "bg-brand/10 text-brand font-medium"
                    : "text-slate-400 hover:text-slate-200 hover:bg-white/5"
                }`}
              >
                <span className="text-base w-5 text-center">{item.icon}</span>
                {item.label}
              </Link>
            );
          })}
        </nav>

        {/* User footer */}
        <div className="border-t border-white/8 p-4">
          <div className="flex items-center gap-3 mb-3">
            <div className="h-8 w-8 rounded-full bg-brand/20 flex items-center justify-center text-sm font-medium text-brand">
              {user.name.charAt(0)}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">{user.name}</p>
              <p className="text-xs text-slate-500 truncate">{user.email}</p>
            </div>
          </div>
          <button onClick={logout} className="btn-ghost w-full justify-center text-xs text-slate-500">
            Выйти
          </button>
        </div>
      </aside>

      {/* ── Main ── */}
      <main className="flex-1 overflow-y-auto">
        <div className="max-w-5xl mx-auto px-6 py-8">{children}</div>
      </main>
    </div>
  );
}
