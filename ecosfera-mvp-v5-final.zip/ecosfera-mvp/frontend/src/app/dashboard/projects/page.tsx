"use client";
import Link from "next/link";
import { useAuth } from "@/lib/auth-context";
import { useApi, useMutation } from "@/lib/use-api";
import { projectsApi, type Project, type ProjectRequest } from "@/lib/api";
import { PageSpinner, Alert, EmptyState, StatusBadge, SkeletonCard } from "@/components/ui";
import { useState } from "react";

export default function ProjectsPage() {
  const { accessToken } = useAuth();
  const [selected, setSelected] = useState<string | null>(null);

  const { data: owned, loading, error, refetch } = useApi(
    () => projectsApi.myOwned(accessToken!),
    [accessToken]
  );

  const { data: requestsData, loading: reqLoading, refetch: refetchReqs } = useApi(
    () =>
      selected
        ? projectsApi.getRequests(selected, accessToken!)
        : Promise.resolve(null),
    [selected, accessToken]
  );

  const { mutate: review, loading: reviewing } = useMutation(
    ({ projectId, reqId, status }: { projectId: string; reqId: string; status: "APPROVED" | "REJECTED" }) =>
      projectsApi.reviewRequest(projectId, reqId, status, accessToken!)
  );

  const projects = owned ?? [];
  const requests = requestsData as ProjectRequest[] | null;

  async function handleReview(projectId: string, reqId: string, status: "APPROVED" | "REJECTED") {
    await review({ projectId, reqId, status });
    refetchReqs();
    refetch();
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-display font-semibold">Мои проекты</h1>
          <p className="text-slate-400 text-sm mt-0.5">{projects.length} проектов</p>
        </div>
        <Link href="/dashboard/projects/create" className="btn-primary">
          + Создать
        </Link>
      </div>

      {error && <Alert type="error" message={error} />}

      {loading ? (
        <div className="space-y-3">
          <SkeletonCard /><SkeletonCard />
        </div>
      ) : projects.length === 0 ? (
        <EmptyState icon="🚀" title="Проектов пока нет" sub="Создай первый проект" />
      ) : (
        <div className="space-y-3">
          {projects.map((p: any) => (
            <div
              key={p.id}
              className={`card cursor-pointer transition hover:border-white/20 ${
                selected === p.id ? "border-brand/40 bg-brand/5" : ""
              }`}
              onClick={() => setSelected(selected === p.id ? null : p.id)}
            >
              <div className="flex items-start gap-3">
                <span className="text-2xl">{p.emoji ?? "🌿"}</span>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-medium">{p.title}</span>
                    <StatusBadge status={p.stage} />
                    {p._count?.requests > 0 && (
                      <span className="badge bg-amber-500/15 text-amber-300">
                        🔔 {p._count.requests} заявок
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-slate-500 mt-1 line-clamp-2">{p.description}</p>
                  <div className="flex items-center gap-4 mt-2 text-xs text-slate-500">
                    <span>👥 {p.members?.length ?? 0} участников</span>
                    {p.location && <span>📍 {p.location}</span>}
                    <span>{new Date(p.createdAt).toLocaleDateString("ru-RU")}</span>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Link
                    href={`/dashboard/projects/${p.id}`}
                    className="btn-ghost text-xs"
                    onClick={(e) => e.stopPropagation()}
                  >
                    Открыть
                  </Link>
                </div>
              </div>

              {/* Pending requests panel */}
              {selected === p.id && (
                <div
                  className="mt-4 pt-4 border-t border-white/8"
                  onClick={(e) => e.stopPropagation()}
                >
                  <h3 className="text-xs font-medium text-slate-400 uppercase tracking-wider mb-3">
                    Заявки на вступление
                  </h3>
                  {reqLoading ? (
                    <p className="text-sm text-slate-500">Загрузка…</p>
                  ) : !requests || requests.length === 0 ? (
                    <p className="text-sm text-slate-500">Новых заявок нет</p>
                  ) : (
                    <div className="space-y-2">
                      {requests.map((r) => (
                        <div key={r.id} className="flex items-start gap-3 rounded-lg bg-white/3 p-3">
                          <div className="h-8 w-8 rounded-full bg-brand/20 flex items-center justify-center text-sm font-medium text-brand shrink-0">
                            {r.user?.name?.charAt(0) ?? "?"}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium">{r.user?.name}</p>
                            <p className="text-xs text-slate-400 mt-0.5 line-clamp-2">{r.message}</p>
                          </div>
                          <div className="flex gap-2 shrink-0">
                            <button
                              onClick={() => handleReview(p.id, r.id, "APPROVED")}
                              disabled={reviewing}
                              className="btn-primary text-xs px-2 py-1"
                            >
                              ✓ Принять
                            </button>
                            <button
                              onClick={() => handleReview(p.id, r.id, "REJECTED")}
                              disabled={reviewing}
                              className="btn-danger text-xs px-2 py-1"
                            >
                              ✕
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
