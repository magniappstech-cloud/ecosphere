"use client";
import { useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { useAuth } from "@/lib/auth-context";
import { useApi, useMutation } from "@/lib/use-api";
import { projectsApi } from "@/lib/api";
import {
  PageSpinner, Alert, StatusBadge, EmptyState, Spinner,
} from "@/components/ui";

export default function DashboardProjectDetailPage() {
  const { id }  = useParams<{ id: string }>();
  const router  = useRouter();
  const { user, accessToken } = useAuth();

  const { data: project, loading, error, refetch } = useApi(
    () => projectsApi.get(id),
    [id]
  );

  const { data: requests, loading: reqLoading, refetch: refetchReqs } = useApi(
    () => (project ? projectsApi.getRequests(id, accessToken!) : Promise.resolve([])),
    [project, accessToken]
  );

  const { mutate: review, loading: reviewing } = useMutation(
    ({ reqId, status }: { reqId: string; status: "APPROVED" | "REJECTED" }) =>
      projectsApi.reviewRequest(id, reqId, status, accessToken!)
  );

  const { mutate: deleteProject, loading: deleting } = useMutation(() =>
    projectsApi.update(id, { status: "ARCHIVED" }, accessToken!)
  );

  const [tab, setTab] = useState<"members" | "requests" | "articles">("members");

  async function handleReview(reqId: string, status: "APPROVED" | "REJECTED") {
    await review({ reqId, status });
    refetchReqs();
    refetch();
  }

  async function handleArchive() {
    if (!confirm("Архивировать проект?")) return;
    await deleteProject(undefined as any);
    router.push("/dashboard/projects");
  }

  if (loading) return <PageSpinner />;
  if (error)   return <div className="p-6"><Alert type="error" message={error} /></div>;
  if (!project) return null;

  const isOwner = project.ownerId === user?.id;
  const reqArr  = Array.isArray(requests) ? requests : [];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start gap-3">
        <span className="text-3xl">{project.emoji ?? "🌿"}</span>
        <div className="flex-1 min-w-0">
          <div className="flex flex-wrap items-center gap-2 mb-1">
            <h1 className="text-xl font-display font-semibold">{project.title}</h1>
            <StatusBadge status={project.stage} />
          </div>
          <p className="text-sm text-slate-400 line-clamp-2">{project.description}</p>
        </div>
        <div className="flex gap-2 shrink-0">
          <Link href={`/projects/${id}`} className="btn-ghost text-xs" target="_blank">
            Публичная страница ↗
          </Link>
          {isOwner && (
            <button onClick={handleArchive} disabled={deleting} className="btn-danger text-xs">
              {deleting ? <Spinner size="sm" /> : "Архивировать"}
            </button>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 border-b border-white/8">
        {([
          { key: "members",  label: `Участники (${project.members?.length ?? 0})` },
          { key: "requests", label: `Заявки (${reqArr.length})`, badge: reqArr.length > 0 },
          { key: "articles", label: `Статьи (${project.articles?.length ?? 0})` },
        ] as const).map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`px-4 py-2 text-sm font-medium border-b-2 -mb-px transition ${
              tab === t.key
                ? "border-brand text-brand"
                : "border-transparent text-slate-500 hover:text-slate-300"
            }`}
          >
            {t.label}
            {t.badge && (
              <span className="ml-1.5 inline-flex h-4 w-4 items-center justify-center rounded-full bg-amber-500/20 text-amber-300 text-xs">
                {reqArr.length}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Members tab */}
      {tab === "members" && (
        <div className="space-y-2">
          {(project.members ?? []).length === 0 ? (
            <EmptyState icon="👥" title="Участников нет" />
          ) : (
            (project.members ?? []).map((m: any) => (
              <div key={m.id} className="card flex items-center gap-3">
                <div className="h-9 w-9 rounded-full bg-brand/20 flex items-center justify-center text-sm font-semibold text-brand shrink-0">
                  {m.user?.name?.charAt(0) ?? "?"}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium">{m.user?.name}</p>
                  <p className="text-xs text-slate-500">
                    {new Date(m.joinedAt).toLocaleDateString("ru-RU")}
                  </p>
                </div>
                <StatusBadge status={m.role} />
              </div>
            ))
          )}
        </div>
      )}

      {/* Requests tab */}
      {tab === "requests" && (
        <div className="space-y-3">
          {reqLoading ? (
            <p className="text-slate-500 text-sm">Загрузка…</p>
          ) : reqArr.length === 0 ? (
            <EmptyState icon="📬" title="Новых заявок нет" />
          ) : (
            reqArr.map((r: any) => (
              <div key={r.id} className="card space-y-3">
                <div className="flex items-center gap-3">
                  <div className="h-9 w-9 rounded-full bg-brand/20 flex items-center justify-center text-sm font-semibold text-brand shrink-0">
                    {r.user?.name?.charAt(0) ?? "?"}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium">{r.user?.name}</p>
                    <p className="text-xs text-slate-500">
                      {new Date(r.createdAt).toLocaleDateString("ru-RU")}
                    </p>
                  </div>
                </div>
                <p className="text-sm text-slate-300 bg-white/3 rounded-lg p-3">{r.message}</p>
                <div className="flex gap-2">
                  <button
                    onClick={() => handleReview(r.id, "APPROVED")}
                    disabled={reviewing}
                    className="btn-primary text-sm"
                  >
                    {reviewing ? <Spinner size="sm" /> : "✓"} Принять
                  </button>
                  <button
                    onClick={() => handleReview(r.id, "REJECTED")}
                    disabled={reviewing}
                    className="btn-danger text-sm"
                  >
                    ✕ Отклонить
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* Articles tab */}
      {tab === "articles" && (
        <div className="space-y-2">
          {(project.articles ?? []).length === 0 ? (
            <EmptyState icon="📝" title="Статей пока нет" sub="Напишите первую статью для этого проекта" />
          ) : (
            (project.articles ?? []).map((a: any) => (
              <Link key={a.id} href={`/articles/${a.slug}`} className="card flex items-center gap-3 hover:border-brand/30 transition">
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{a.title}</p>
                  <p className="text-xs text-slate-500 mt-0.5">
                    {new Date(a.createdAt).toLocaleDateString("ru-RU")} · 👁️ {a.views}
                  </p>
                </div>
                <StatusBadge status={a.status} />
              </Link>
            ))
          )}
        </div>
      )}
    </div>
  );
}
