"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/lib/auth-context";
import { projectsApi } from "@/lib/api";
import { Alert, Spinner } from "@/components/ui";
import { z } from "zod";

const Schema = z.object({
  title:       z.string().min(3, "Минимум 3 символа").max(200),
  description: z.string().min(10, "Минимум 10 символов").max(2000),
  stage:       z.enum(["IDEA", "PLANNING", "ACTIVE", "COMPLETED"]),
  location:    z.string().max(100).optional(),
  emoji:       z.string().max(4).optional(),
});

const STAGES = [
  { value: "IDEA",      label: "💡 Идея" },
  { value: "PLANNING",  label: "📋 Планирование" },
  { value: "ACTIVE",    label: "🚀 Активен" },
  { value: "COMPLETED", label: "✅ Завершён" },
];

const EMOJIS = ["🌿", "⚡", "🔬", "🏗️", "🎨", "🌍", "♻️", "🛡️", "💧", "🌱"];

export default function CreateProjectPage() {
  const router = useRouter();
  const { accessToken } = useAuth();

  const [title,       setTitle]       = useState("");
  const [description, setDescription] = useState("");
  const [stage,       setStage]       = useState("IDEA");
  const [location,    setLocation]    = useState("");
  const [emoji,       setEmoji]       = useState("🌿");

  const [loading, setLoading] = useState(false);
  const [error,   setError]   = useState<string | null>(null);

  async function handleSubmit() {
    setError(null);
    const parsed = Schema.safeParse({ title, description, stage, location: location || undefined, emoji });
    if (!parsed.success) {
      setError(parsed.error.errors[0].message);
      return;
    }

    setLoading(true);
    try {
      const project = await projectsApi.create(parsed.data, accessToken!);
      router.push(`/dashboard/projects/${project.id}`);
    } catch (e: any) {
      setError(e.message ?? "Ошибка создания");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="max-w-2xl space-y-6">
      <div>
        <h1 className="text-xl font-display font-semibold">Новый проект</h1>
        <p className="text-slate-400 text-sm mt-0.5">Заполни информацию о проекте</p>
      </div>

      {/* Emoji picker */}
      <div>
        <label className="text-xs text-slate-400 mb-2 block">Иконка</label>
        <div className="flex flex-wrap gap-2">
          {EMOJIS.map((e) => (
            <button
              key={e}
              onClick={() => setEmoji(e)}
              className={`text-2xl p-1.5 rounded-lg transition ${
                emoji === e ? "bg-brand/20 ring-1 ring-brand/40" : "hover:bg-white/5"
              }`}
            >
              {e}
            </button>
          ))}
        </div>
      </div>

      {/* Title */}
      <div>
        <label className="text-xs text-slate-400 mb-1 block">Название *</label>
        <input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Краткое название проекта"
          className="input"
        />
      </div>

      {/* Description */}
      <div>
        <label className="text-xs text-slate-400 mb-1 block">Описание *</label>
        <textarea
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="Опишите цели, задачи и ожидаемый результат проекта"
          rows={4}
          className="input resize-none"
        />
        <p className="text-xs text-slate-600 mt-1">{description.length} / 2000</p>
      </div>

      {/* Stage + Location */}
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="text-xs text-slate-400 mb-1 block">Стадия</label>
          <select value={stage} onChange={(e) => setStage(e.target.value)} className="input">
            {STAGES.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
          </select>
        </div>
        <div>
          <label className="text-xs text-slate-400 mb-1 block">Локация</label>
          <input
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            placeholder="Город / Регион"
            className="input"
          />
        </div>
      </div>

      {error && <Alert type="error" message={error} />}

      <div className="flex gap-3 justify-end pt-4 border-t border-white/8">
        <button onClick={() => router.back()} className="btn-ghost">Отмена</button>
        <button onClick={handleSubmit} disabled={loading} className="btn-primary">
          {loading ? <Spinner size="sm" /> : null}
          Создать проект
        </button>
      </div>
    </div>
  );
}
