"use client";
import Link from "next/link";
import { useAuth } from "@/lib/auth-context";
import { useApi } from "@/lib/use-api";
import { usersApi } from "@/lib/api";
import { PageSpinner, StatCard } from "@/components/ui";

export default function DashboardProfilePage() {
  const { user, accessToken } = useAuth();

  const { data: stats, loading } = useApi(
    () => usersApi.stats(accessToken!),
    [accessToken]
  );

  if (loading) return <PageSpinner />;

  return (
    <div className="space-y-8">
      {/* Profile card */}
      <div className="card flex items-start gap-5">
        <div className="h-16 w-16 rounded-full bg-brand/20 flex items-center justify-center text-2xl font-bold text-brand shrink-0">
          {user?.avatarUrl ? (
            <img src={user.avatarUrl} alt="" className="w-full h-full rounded-full object-cover" />
          ) : (
            user?.name?.charAt(0)
          )}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <h2 className="text-lg font-semibold">{user?.name}</h2>
            <span className={`badge ${
              user?.role === "ADMIN"  ? "badge-active" :
              user?.role === "EDITOR" ? "badge-planning" : "badge-draft"
            }`}>
              {user?.role}
            </span>
          </div>
          <p className="text-slate-400 text-sm mt-0.5">{user?.email}</p>
          {user?.bio && <p className="text-slate-300 text-sm mt-2">{user.bio}</p>}
        </div>
        <Link href="/dashboard/settings" className="btn-ghost text-sm shrink-0">
          Редактировать
        </Link>
      </div>

      {/* Stats */}
      {stats && (
        <div>
          <h2 className="font-medium mb-4">Статистика</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <StatCard label="Опубликовано"    value={stats.articles.published}  icon="📝" />
            <StatCard label="Черновики"        value={stats.articles.drafts}     icon="🗒️" />
            <StatCard label="Просмотры"        value={stats.articles.totalViews} icon="👁️" />
            <StatCard label="Проектов"         value={stats.projects.owned}      icon="🚀" />
          </div>
        </div>
      )}

      {/* Quick links */}
      <div>
        <h2 className="font-medium mb-4">Быстрый переход</h2>
        <div className="grid md:grid-cols-3 gap-3">
          {[
            { href: "/dashboard/articles/new", label: "Написать статью",   icon: "✍️",  desc: "Создать новую публикацию" },
            { href: "/dashboard/projects/create", label: "Создать проект", icon: "🚀",  desc: "Запустить новую инициативу" },
            { href: "/dashboard/stats",         label: "Статистика",       icon: "📊",  desc: "Просмотры и лайки" },
          ].map((a) => (
            <Link key={a.href} href={a.href} className="card hover:border-brand/30 hover:bg-brand/3 transition">
              <div className="text-2xl mb-2">{a.icon}</div>
              <p className="font-medium text-sm">{a.label}</p>
              <p className="text-xs text-slate-500 mt-0.5">{a.desc}</p>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
