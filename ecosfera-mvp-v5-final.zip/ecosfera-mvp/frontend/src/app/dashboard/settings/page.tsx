"use client";
import { useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { usersApi } from "@/lib/api";
import { Alert, Spinner } from "@/components/ui";
import { z } from "zod";

const Schema = z.object({
  name:      z.string().min(2, "Минимум 2 символа").max(80),
  bio:       z.string().max(500).optional(),
  avatarUrl: z.string().url("Некорректный URL").optional().or(z.literal("")),
});

export default function SettingsPage() {
  const { user, accessToken } = useAuth();

  const [name,      setName]      = useState(user?.name      ?? "");
  const [bio,       setBio]       = useState(user?.bio       ?? "");
  const [avatarUrl, setAvatarUrl] = useState(user?.avatarUrl ?? "");

  const [loading, setLoading] = useState(false);
  const [error,   setError]   = useState<string | null>(null);
  const [saved,   setSaved]   = useState(false);

  async function handleSave() {
    setError(null);
    setSaved(false);

    const parsed = Schema.safeParse({ name, bio, avatarUrl: avatarUrl || undefined });
    if (!parsed.success) {
      setError(parsed.error.errors[0].message);
      return;
    }

    setLoading(true);
    try {
      await usersApi.updateMe(parsed.data, accessToken!);
      setSaved(true);
    } catch (e: any) {
      setError(e.message ?? "Ошибка сохранения");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="max-w-xl space-y-6">
      <div>
        <h1 className="text-xl font-display font-semibold">Настройки профиля</h1>
        <p className="text-slate-400 text-sm mt-0.5">Обновите публичную информацию</p>
      </div>

      {/* Avatar preview */}
      <div className="flex items-center gap-4">
        <div className="h-16 w-16 rounded-full bg-brand/20 flex items-center justify-center text-2xl font-semibold text-brand overflow-hidden">
          {avatarUrl ? (
            <img src={avatarUrl} alt="" className="w-full h-full object-cover" onError={() => setAvatarUrl("")} />
          ) : (
            user?.name?.charAt(0)
          )}
        </div>
        <div className="flex-1">
          <label className="text-xs text-slate-400 mb-1 block">URL аватара</label>
          <input
            value={avatarUrl}
            onChange={(e) => setAvatarUrl(e.target.value)}
            placeholder="https://example.com/avatar.jpg"
            className="input text-sm"
          />
        </div>
      </div>

      {/* Read-only email */}
      <div>
        <label className="text-xs text-slate-400 mb-1 block">Email</label>
        <input value={user?.email ?? ""} disabled className="input opacity-50 cursor-not-allowed" />
        <p className="text-xs text-slate-600 mt-1">Email изменить нельзя</p>
      </div>

      {/* Name */}
      <div>
        <label className="text-xs text-slate-400 mb-1 block">Имя *</label>
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Имя и фамилия"
          className="input"
        />
      </div>

      {/* Bio */}
      <div>
        <label className="text-xs text-slate-400 mb-1 block">О себе</label>
        <textarea
          value={bio}
          onChange={(e) => setBio(e.target.value)}
          placeholder="Кратко о себе, роль, город"
          rows={3}
          className="input resize-none"
        />
        <p className="text-xs text-slate-600 mt-1">{bio.length} / 500</p>
      </div>

      {/* Role badge (read-only) */}
      <div className="card flex items-center gap-3">
        <span className="text-lg">🏷️</span>
        <div>
          <p className="text-sm font-medium">Роль: {user?.role}</p>
          <p className="text-xs text-slate-500">Роль назначается администратором</p>
        </div>
      </div>

      {error && <Alert type="error" message={error} />}
      {saved && <Alert type="success" message="Профиль сохранён!" />}

      <button onClick={handleSave} disabled={loading} className="btn-primary">
        {loading ? <Spinner size="sm" /> : null}
        Сохранить
      </button>
    </div>
  );
}
