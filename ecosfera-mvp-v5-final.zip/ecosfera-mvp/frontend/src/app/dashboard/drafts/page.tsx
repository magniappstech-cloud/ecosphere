"use client";
import Link from "next/link";
import { useAuth } from "@/lib/auth-context";
import { useApi } from "@/lib/use-api";
import { articlesApi } from "@/lib/api";
import { PageSpinner, Alert, EmptyState, SkeletonCard } from "@/components/ui";

export default function DraftsPage() {
  const { accessToken } = useAuth();

  const { data, loading, error, refetch } = useApi(
    () => articlesApi.my(accessToken!),
    [accessToken]
  );

  const drafts = (data ?? []).filter((a) => a.status === "DRAFT");

  async function publish(id: string) {
    await articlesApi.update(id, { status: "PUBLISHED" }, accessToken!);
    refetch();
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-display font-semibold">Черновики</h1>
        <p className="text-slate-400 text-sm mt-0.5">{drafts.length} не опубликовано</p>
      </div>

      {error && <Alert type="error" message={error} />}

      {loading ? (
        <div className="space-y-3">
          <SkeletonCard /><SkeletonCard /><SkeletonCard />
        </div>
      ) : drafts.length === 0 ? (
        <EmptyState icon="🗒️" title="Черновиков нет" sub="Все статьи опубликованы" />
      ) : (
        <div className="space-y-3">
          {drafts.map((a) => (
            <div key={a.id} className="card flex items-start gap-4 hover:border-white/20 transition">
              <div className="flex-1 min-w-0">
                <Link
                  href={`/dashboard/articles/${a.id}/edit`}
                  className="font-medium hover:text-brand transition"
                >
                  {a.title}
                </Link>
                {a.lead && (
                  <p className="text-sm text-slate-500 mt-1 line-clamp-2">{a.lead}</p>
                )}
                <p className="text-xs text-slate-600 mt-2">
                  Изменено: {new Date(a.updatedAt).toLocaleDateString("ru-RU")} · {a.readTime} мин
                </p>
              </div>
              <div className="flex gap-2 shrink-0">
                <Link href={`/dashboard/articles/${a.id}/edit`} className="btn-ghost text-xs">
                  Редактировать
                </Link>
                <button
                  onClick={() => publish(a.id)}
                  className="btn-primary text-xs"
                >
                  Опубликовать
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
