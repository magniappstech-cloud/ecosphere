"use client";
import { useParams, useSearchParams } from "next/navigation";
import Link from "next/link";
import { useAuth } from "@/lib/auth-context";
import { useApi } from "@/lib/use-api";
import { articlesApi } from "@/lib/api";
import ArticleEditor from "@/components/articles/ArticleEditor";
import { PageSpinner, Alert } from "@/components/ui";

export default function EditArticlePage() {
  const { id } = useParams<{ id: string }>();
  const searchParams = useSearchParams();
  const justSaved = searchParams.get("saved") === "1";
  const { accessToken } = useAuth();

  // Загружаем статью по id — используем slug или id
  const { data: article, loading, error } = useApi(
    () => articlesApi.getById(id, accessToken!),
    [id, accessToken]
  );

  if (loading) return <PageSpinner />;
  if (error)   return <div className="p-4"><Alert type="error" message={error} /></div>;
  if (!article) return null;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Link href="/dashboard/articles" className="text-slate-500 hover:text-slate-300 transition text-sm">
          ← Назад к статьям
        </Link>
        <div className="flex-1">
          <h1 className="text-xl font-display font-semibold">Редактировать статью</h1>
          <p className="text-slate-400 text-sm mt-0.5">
            Последнее изменение: {new Date(article.updatedAt).toLocaleDateString("ru-RU", {
              day: "numeric", month: "long", year: "numeric",
            })}
          </p>
        </div>
      </div>

      {justSaved && (
        <Alert type="success" message="Статья сохранена!" />
      )}

      <ArticleEditor mode="edit" initial={article} />
    </div>
  );
}
