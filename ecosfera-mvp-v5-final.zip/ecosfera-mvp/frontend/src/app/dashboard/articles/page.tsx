"use client";
import Link from "next/link";
import { useAuth } from "@/lib/auth-context";
import { useApi, useMutation } from "@/lib/use-api";
import { articlesApi, type Article } from "@/lib/api";
import { PageSpinner, Alert, EmptyState, StatusBadge, SkeletonRows } from "@/components/ui";
import { useState } from "react";

export default function ArticlesPage() {
  const { accessToken } = useAuth();
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const { data, loading, error, refetch } = useApi(
    () => articlesApi.my(accessToken!),
    [accessToken]
  );

  const { mutate: deleteArt } = useMutation((id: string) =>
    articlesApi.delete(id, accessToken!)
  );

  const published = (data ?? []).filter((a) => a.status === "PUBLISHED");

  async function handleDelete(id: string) {
    if (!confirm("Удалить статью? Это действие нельзя отменить.")) return;
    setDeletingId(id);
    try {
      await deleteArt(id);
      refetch();
    } finally {
      setDeletingId(null);
    }
  }

  async function handleToggleStatus(a: Article) {
    const newStatus = a.status === "PUBLISHED" ? "DRAFT" : "PUBLISHED";
    await articlesApi.update(a.id, { status: newStatus }, accessToken!);
    refetch();
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-display font-semibold">Мои статьи</h1>
          <p className="text-slate-400 text-sm mt-0.5">{published.length} опубликовано</p>
        </div>
        <Link href="/dashboard/articles/new" className="btn-primary">
          + Написать статью
        </Link>
      </div>

      {error && <Alert type="error" message={error} />}

      <div className="card p-0 overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-white/8 text-slate-500 text-xs uppercase tracking-wider">
              <th className="text-left px-5 py-3 font-medium">Заголовок</th>
              <th className="text-left px-4 py-3 font-medium">Рубрика</th>
              <th className="text-right px-4 py-3 font-medium">👁️</th>
              <th className="text-right px-4 py-3 font-medium">❤️</th>
              <th className="text-left px-4 py-3 font-medium">Статус</th>
              <th className="px-4 py-3" />
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <SkeletonRows rows={5} cols={6} />
            ) : published.length === 0 ? (
              <tr>
                <td colSpan={6}>
                  <EmptyState icon="📝" title="Нет опубликованных статей" sub="Создай первую статью" />
                </td>
              </tr>
            ) : (
              published.map((a) => (
                <tr key={a.id} className="border-b border-white/5 hover:bg-white/2 transition group">
                  <td className="px-5 py-3">
                    <Link
                      href={`/dashboard/articles/${a.id}/edit`}
                      className="font-medium hover:text-brand transition line-clamp-1"
                    >
                      {a.title}
                    </Link>
                    <span className="text-xs text-slate-500 block mt-0.5">
                      {new Date(a.createdAt).toLocaleDateString("ru-RU")}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-slate-400">{a.tag}</td>
                  <td className="px-4 py-3 text-right tabular-nums">{a.views.toLocaleString("ru-RU")}</td>
                  <td className="px-4 py-3 text-right tabular-nums">{a.likes}</td>
                  <td className="px-4 py-3">
                    <StatusBadge status={a.status} />
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition justify-end">
                      <button
                        onClick={() => handleToggleStatus(a)}
                        className="btn-ghost text-xs px-2 py-1"
                        title="Снять с публикации"
                      >
                        В черновик
                      </button>
                      <button
                        onClick={() => handleDelete(a.id)}
                        disabled={deletingId === a.id}
                        className="btn-danger text-xs px-2 py-1"
                      >
                        {deletingId === a.id ? "…" : "Удалить"}
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
