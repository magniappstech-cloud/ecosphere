// app/dashboard/articles/new/page.tsx
import ArticleEditor from "@/components/articles/ArticleEditor";

export default function NewArticlePage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-display font-semibold">Новая статья</h1>
        <p className="text-slate-400 text-sm mt-0.5">Заполни поля и опубликуй или сохрани черновик</p>
      </div>
      <ArticleEditor mode="create" />
    </div>
  );
}
