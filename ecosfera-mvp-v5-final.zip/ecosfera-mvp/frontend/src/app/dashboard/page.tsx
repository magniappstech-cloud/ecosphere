"use client";
import Link from "next/link";
import { useAuth } from "@/lib/auth-context";
import { useApi } from "@/lib/use-api";
import { usersApi, projectsApi } from "@/lib/api";
import { StatCard, PageSpinner, Alert, SkeletonCard } from "@/components/ui";

export default function DashboardPage() {
  const { user, accessToken } = useAuth();

  const { data: stats, loading: statsLoading, error: statsError } = useApi(
    () => usersApi.stats(accessToken!),
    [accessToken]
  );

  const { data: projectsRes, loading: projLoading } = useApi(
    () => projectsApi.myOwned(accessToken!),
    [accessToken]
  );

  const projects = Array.isArray(projectsRes) ? projectsRes : [];

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-display font-semibold">
          Привет, {user?.name?.split(" ")[0]} 👋
        </h1>
        <p className="text-slate-400 text-sm mt-1">Вот что происходит на твоей платформе</p>
      </div>

      {/* Stats grid */}
      {statsError && <Alert type="error" message={statsError} />}
      {statsLoading ? (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="card h-24 animate-pulse bg-white/4" />
          ))}
        </div>
      ) : stats ? (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <StatCard label="Просмотры"    value={stats.articles.totalViews} icon="👁️" />
          <StatCard label="Лайки"        value={stats.articles.totalLikes} icon="❤️" />
          <StatCard label="Опубликовано" value={stats.articles.published}  icon="📝" />
          <StatCard label="Черновики"    value={stats.articles.drafts}     icon="🗒️" />
        </div>
      ) : null}

      {/* Pending requests alert */}
      {stats?.projects.pendingRequests > 0 && (
        <Link href="/dashboard/projects" className="block">
          <div className="card border-amber-500/30 bg-amber-500/5 flex items-center gap-3 hover:bg-amber-500/8 transition">
            <span className="text-xl">🔔</span>
            <div>
              <p className="text-sm font-medium text-amber-300">
                {stats.projects.pendingRequests} новых заявок на вступление в проект
              </p>
              <p className="text-xs text-slate-500">Перейти к проектам →</p>
            </div>
          </div>
        </Link>
      )}

      {/* Active projects */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-semibold">🚀 Мои проекты</h2>
          <Link href="/dashboard/projects/create" className="btn-primary text-xs px-3 py-1.5">
            + Создать
          </Link>
        </div>

        {projLoading ? (
          <div className="grid md:grid-cols-2 gap-4">
            <SkeletonCard /><SkeletonCard />
          </div>
        ) : projects.length === 0 ? (
          <div className="card text-center py-10">
            <p className="text-slate-500 text-sm">У тебя пока нет проектов</p>
            <Link href="/dashboard/projects/create" className="btn-primary mt-4 inline-flex">
              Создать первый
            </Link>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 gap-4">
            {projects.slice(0, 4).map((p: any) => (
              <Link href={`/dashboard/projects/${p.id}`} key={p.id} className="card hover:border-brand/30 transition group">
                <div className="flex items-start gap-3">
                  <span className="text-2xl">{p.emoji ?? "🌿"}</span>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-sm group-hover:text-brand transition truncate">{p.title}</p>
                    <p className="text-xs text-slate-500 mt-1 line-clamp-2">{p.description}</p>
                    <div className="flex items-center gap-3 mt-2">
                      <span className={`badge-${p.stage.toLowerCase()}`}>{p.stage}</span>
                      <span className="text-xs text-slate-500">{p.members?.length ?? 0} участников</span>
                      {p._count?.requests > 0 && (
                        <span className="badge bg-amber-500/15 text-amber-300">
                          {p._count.requests} заявок
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>

      {/* Quick actions */}
      <div>
        <h2 className="font-semibold mb-4">💡 Быстрые действия</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {[
            { href: "/dashboard/articles/new", label: "Написать статью", icon: "✍️" },
            { href: "/dashboard/projects/create", label: "Создать проект", icon: "🚀" },
            { href: "/dashboard/drafts", label: "Продолжить черновик", icon: "🗒️" },
          ].map((a) => (
            <Link
              key={a.href}
              href={a.href}
              className="card hover:border-brand/30 hover:bg-brand/5 transition flex items-center gap-3 text-sm"
            >
              <span className="text-xl">{a.icon}</span>
              <span className="text-slate-300">{a.label}</span>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
