"use client";
import { useAuth } from "@/lib/auth-context";
import { useApi } from "@/lib/use-api";
import { articlesApi, usersApi } from "@/lib/api";
import { PageSpinner, Alert, StatCard } from "@/components/ui";
import {
  LineChart, Line, XAxis, YAxis, Tooltip,
  ResponsiveContainer, CartesianGrid, BarChart, Bar,
} from "recharts";

// Recharts tooltip кастомный
function CustomTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-lg border border-white/10 bg-surface-2 px-3 py-2 text-xs shadow-xl">
      <p className="text-slate-400 mb-1">{label}</p>
      {payload.map((p: any) => (
        <p key={p.name} style={{ color: p.color }} className="font-medium">
          {p.name}: {p.value.toLocaleString("ru-RU")}
        </p>
      ))}
    </div>
  );
}

export default function StatsPage() {
  const { accessToken } = useAuth();

  const { data: stats,    loading: sLoading, error: sError }  = useApi(() => usersApi.stats(accessToken!),    [accessToken]);
  const { data: articles, loading: aLoading }                  = useApi(() => articlesApi.my(accessToken!),   [accessToken]);

  const published = (articles ?? []).filter((a) => a.status === "PUBLISHED");

  // По рубрикам
  const byTag = published.reduce<Record<string, { views: number; likes: number }>>(
    (acc, a) => {
      if (!acc[a.tag]) acc[a.tag] = { views: 0, likes: 0 };
      acc[a.tag].views += a.views;
      acc[a.tag].likes += a.likes;
      return acc;
    },
    {}
  );

  const tagData = Object.entries(byTag).map(([tag, d]) => ({
    tag,
    views: d.views,
    likes: d.likes,
  }));

  // Топ статей
  const topArticles = [...published]
    .sort((a, b) => b.views - a.views)
    .slice(0, 5);

  // Хронология (по createdAt)
  const timelineData = published
    .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime())
    .map((a) => ({
      date: new Date(a.createdAt).toLocaleDateString("ru-RU", { day: "numeric", month: "short" }),
      views: a.views,
      likes: a.likes,
    }));

  if (sLoading || aLoading) return <PageSpinner />;

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-xl font-display font-semibold">Статистика</h1>
        <p className="text-slate-400 text-sm mt-0.5">Данные по твоим публикациям</p>
      </div>

      {sError && <Alert type="error" message={sError} />}

      {/* Summary stats */}
      {stats && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <StatCard label="Всего просмотров" value={stats.articles.totalViews} icon="👁️" />
          <StatCard label="Всего лайков"     value={stats.articles.totalLikes} icon="❤️" />
          <StatCard label="Опубликовано"     value={stats.articles.published}  icon="📝" />
          <StatCard label="Черновиков"       value={stats.articles.drafts}     icon="🗒️" />
        </div>
      )}

      {/* Timeline chart */}
      {timelineData.length > 1 && (
        <div className="card">
          <h2 className="text-sm font-medium mb-4 text-slate-300">Просмотры по статьям</h2>
          <ResponsiveContainer width="100%" height={240}>
            <LineChart data={timelineData} margin={{ top: 4, right: 4, bottom: 4, left: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
              <XAxis dataKey="date" tick={{ fill: "#64748b", fontSize: 11 }} />
              <YAxis tick={{ fill: "#64748b", fontSize: 11 }} />
              <Tooltip content={<CustomTooltip />} />
              <Line
                type="monotone" dataKey="views" name="Просмотры"
                stroke="#2AF598" strokeWidth={2} dot={false} activeDot={{ r: 4 }}
              />
              <Line
                type="monotone" dataKey="likes" name="Лайки"
                stroke="#3B82F6" strokeWidth={2} dot={false} activeDot={{ r: 4 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}

      <div className="grid md:grid-cols-2 gap-6">
        {/* По рубрикам */}
        {tagData.length > 0 && (
          <div className="card">
            <h2 className="text-sm font-medium mb-4 text-slate-300">Просмотры по рубрикам</h2>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={tagData} margin={{ top: 4, right: 4, bottom: 4, left: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                <XAxis dataKey="tag" tick={{ fill: "#64748b", fontSize: 11 }} />
                <YAxis tick={{ fill: "#64748b", fontSize: 11 }} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="views" name="Просмотры" fill="#2AF598" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}

        {/* Топ статей */}
        {topArticles.length > 0 && (
          <div className="card">
            <h2 className="text-sm font-medium mb-4 text-slate-300">Топ-5 статей</h2>
            <div className="space-y-3">
              {topArticles.map((a, i) => (
                <div key={a.id} className="flex items-center gap-3">
                  <span className="text-xs text-slate-600 w-5 text-right">{i + 1}</span>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm truncate">{a.title}</p>
                    <div className="flex gap-3 mt-0.5">
                      <span className="text-xs text-slate-500">👁️ {a.views.toLocaleString("ru-RU")}</span>
                      <span className="text-xs text-slate-500">❤️ {a.likes}</span>
                    </div>
                  </div>
                  {/* Mini bar */}
                  <div className="w-16 h-1.5 rounded-full bg-white/5 overflow-hidden">
                    <div
                      className="h-full rounded-full bg-brand"
                      style={{ width: `${Math.min(100, (a.views / (topArticles[0]?.views || 1)) * 100)}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {published.length === 0 && (
        <div className="card text-center py-12 text-slate-500 text-sm">
          Опубликуй первую статью — и здесь появится статистика
        </div>
      )}
    </div>
  );
}
