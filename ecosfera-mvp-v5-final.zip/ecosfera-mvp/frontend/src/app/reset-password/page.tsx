"use client";
import { useState } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import Link from "next/link";
import { Alert, Spinner } from "@/components/ui";

function strength(pw: string) {
  let s = 0;
  if (pw.length >= 8) s++;
  if (/[A-Z]/.test(pw)) s++;
  if (/[0-9]/.test(pw)) s++;
  if (/[^A-Za-z0-9]/.test(pw)) s++;
  return s;
}
const strengthColor = ["", "bg-red-500", "bg-amber-500", "bg-blue-500", "bg-brand"];

export default function ResetPasswordPage() {
  const searchParams = useSearchParams();
  const router       = useRouter();
  const token        = searchParams.get("token") ?? "";

  const [password, setPassword] = useState("");
  const [confirm,  setConfirm]  = useState("");
  const [loading,  setLoading]  = useState(false);
  const [done,     setDone]     = useState(false);
  const [error,    setError]    = useState<string | null>(null);

  const pw_strength = strength(password);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (password.length < 8)        { setError("Пароль минимум 8 символов"); return; }
    if (password !== confirm)        { setError("Пароли не совпадают"); return; }
    if (!token)                      { setError("Токен не найден в ссылке"); return; }

    setLoading(true);
    try {
      const res = await fetch(
        `${process.env.NEXT_PUBLIC_API_URL}/auth/reset-password`,
        { method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ token, password }) }
      );
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Ошибка");
      setDone(true);
      setTimeout(() => router.push("/login"), 3000);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  if (!token) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <Alert type="error" message="Ссылка недействительна. Запросите новую." />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="w-full max-w-sm space-y-6">
        <div className="text-center">
          <div className="text-4xl mb-3">🔒</div>
          <h1 className="text-2xl font-display font-semibold">Новый пароль</h1>
        </div>

        {done ? (
          <Alert type="success" message="Пароль изменён! Перенаправляем на страницу входа…" />
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="text-xs text-slate-400 mb-1 block">Новый пароль</label>
              <input type="password" value={password} onChange={(e) => setPassword(e.target.value)}
                placeholder="Минимум 8 символов" className="input" required />
              {password && (
                <div className="mt-1.5 flex gap-1">
                  {[1,2,3,4].map((i) => (
                    <div key={i} className={`flex-1 h-1 rounded-full transition-colors ${i <= pw_strength ? strengthColor[pw_strength] : "bg-white/10"}`} />
                  ))}
                </div>
              )}
            </div>
            <div>
              <label className="text-xs text-slate-400 mb-1 block">Подтвердить пароль</label>
              <input type="password" value={confirm} onChange={(e) => setConfirm(e.target.value)}
                placeholder="Повторите пароль" className="input" required />
            </div>
            {error && <Alert type="error" message={error} />}
            <button type="submit" disabled={loading} className="btn-primary w-full justify-center">
              {loading ? <Spinner size="sm" /> : null}
              Сохранить пароль
            </button>
          </form>
        )}

        <p className="text-center text-sm text-slate-500">
          <Link href="/login" className="text-brand hover:underline">← К входу</Link>
        </p>
      </div>
    </div>
  );
}
