"use client";
import { useState } from "react";
import Link from "next/link";
import { Alert, Spinner } from "@/components/ui";

export default function ForgotPasswordPage() {
  const [email,   setEmail]   = useState("");
  const [loading, setLoading] = useState(false);
  const [sent,    setSent]    = useState(false);
  const [error,   setError]   = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (!email.includes("@")) { setError("Введите корректный email"); return; }
    setLoading(true);
    try {
      const res = await fetch(
        `${process.env.NEXT_PUBLIC_API_URL}/auth/forgot-password`,
        { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email }) }
      );
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Ошибка");
      setSent(true);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="w-full max-w-sm space-y-6">
        <div className="text-center">
          <div className="text-4xl mb-3">🔑</div>
          <h1 className="text-2xl font-display font-semibold">Сброс пароля</h1>
          <p className="text-slate-400 text-sm mt-1">Укажите email для получения ссылки</p>
        </div>

        {sent ? (
          <Alert type="success" message="Если email зарегистрирован — письмо отправлено. Проверьте почту." />
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="text-xs text-slate-400 mb-1 block">Email</label>
              <input type="email" value={email} onChange={(e) => setEmail(e.target.value)}
                placeholder="alex@example.com" className="input" required />
            </div>
            {error && <Alert type="error" message={error} />}
            <button type="submit" disabled={loading} className="btn-primary w-full justify-center">
              {loading ? <Spinner size="sm" /> : null}
              Отправить ссылку
            </button>
          </form>
        )}

        <p className="text-center text-sm text-slate-500">
          <Link href="/login" className="text-brand hover:underline">← Вернуться к входу</Link>
        </p>
      </div>
    </div>
  );
}
