"use client";
import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useAuth } from "@/lib/auth-context";
import { Alert, Spinner } from "@/components/ui";
import { z } from "zod";

const Schema = z.object({
  email:    z.string().email("Некорректный email"),
  password: z.string().min(1, "Введите пароль"),
});

export default function LoginPage() {
  const router = useRouter();
  const { login } = useAuth();

  const [email,    setEmail]    = useState("");
  const [password, setPassword] = useState("");
  const [loading,  setLoading]  = useState(false);
  const [error,    setError]    = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    const parsed = Schema.safeParse({ email, password });
    if (!parsed.success) { setError(parsed.error.errors[0].message); return; }

    setLoading(true);
    try {
      await login(email, password);
      router.push("/dashboard");
    } catch (err: any) {
      setError(err.message ?? "Неверный email или пароль");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="w-full max-w-sm space-y-6">
        <div className="text-center">
          <div className="text-4xl mb-3">🌿</div>
          <h1 className="text-2xl font-display font-semibold">ЭкоСфера</h1>
          <p className="text-slate-400 text-sm mt-1">Войдите в свой аккаунт</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="text-xs text-slate-400 mb-1 block">Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="alex@example.com"
              autoComplete="email"
              className="input"
              required
            />
          </div>
          <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs text-slate-400">Пароль</label>
                <Link href="/forgot-password" className="text-xs text-slate-500 hover:text-brand transition">
                  Забыли пароль?
                </Link>
              </div>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                autoComplete="current-password"
                className="input"
                required
              />
            </div>

          {error && <Alert type="error" message={error} />}

          <button type="submit" disabled={loading} className="btn-primary w-full justify-center">
            {loading ? <Spinner size="sm" /> : null}
            Войти
          </button>
        </form>

        <p className="text-center text-sm text-slate-500">
          Нет аккаунта?{" "}
          <Link href="/register" className="text-brand hover:underline">
            Зарегистрироваться
          </Link>
        </p>
      </div>
    </div>
  );
}
