"use client";
import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useAuth } from "@/lib/auth-context";
import { Alert, Spinner } from "@/components/ui";
import { z } from "zod";

const Schema = z.object({
  name:     z.string().min(2, "Минимум 2 символа"),
  email:    z.string().email("Некорректный email"),
  password: z.string().min(8, "Минимум 8 символов"),
});

function strength(pw: string) {
  let s = 0;
  if (pw.length >= 8) s++;
  if (/[A-Z]/.test(pw)) s++;
  if (/[0-9]/.test(pw)) s++;
  if (/[^A-Za-z0-9]/.test(pw)) s++;
  return s;
}

export default function RegisterPage() {
  const router = useRouter();
  const { register } = useAuth();

  const [name,     setName]     = useState("");
  const [email,    setEmail]    = useState("");
  const [password, setPassword] = useState("");
  const [loading,  setLoading]  = useState(false);
  const [error,    setError]    = useState<string | null>(null);

  const pw_strength = strength(password);
  const strengthColor = ["", "bg-red-500", "bg-amber-500", "bg-blue-500", "bg-brand"][pw_strength];

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    const parsed = Schema.safeParse({ name, email, password });
    if (!parsed.success) { setError(parsed.error.errors[0].message); return; }

    setLoading(true);
    try {
      await register(name, email, password);
      router.push("/dashboard");
    } catch (err: any) {
      setError(err.message ?? "Ошибка регистрации");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="w-full max-w-sm space-y-6">
        <div className="text-center">
          <div className="text-4xl mb-3">🌿</div>
          <h1 className="text-2xl font-display font-semibold">Создать аккаунт</h1>
          <p className="text-slate-400 text-sm mt-1">Присоединитесь к сообществу</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="text-xs text-slate-400 mb-1 block">Имя</label>
            <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Александр Петров" className="input" required />
          </div>
          <div>
            <label className="text-xs text-slate-400 mb-1 block">Email</label>
            <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="alex@example.com" autoComplete="email" className="input" required />
          </div>
          <div>
            <label className="text-xs text-slate-400 mb-1 block">Пароль</label>
            <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Минимум 8 символов" autoComplete="new-password" className="input" required />
            {password && (
              <div className="mt-1.5 flex gap-1">
                {[1,2,3,4].map((i) => (
                  <div key={i} className={`flex-1 h-1 rounded-full transition-colors ${i <= pw_strength ? strengthColor : "bg-white/10"}`} />
                ))}
              </div>
            )}
          </div>

          {error && <Alert type="error" message={error} />}

          <button type="submit" disabled={loading} className="btn-primary w-full justify-center">
            {loading ? <Spinner size="sm" /> : null}
            Зарегистрироваться →
          </button>
        </form>

        <p className="text-center text-sm text-slate-500">
          Уже есть аккаунт?{" "}
          <Link href="/login" className="text-brand hover:underline">Войти</Link>
        </p>
      </div>
    </div>
  );
}
