/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        brand: {
          DEFAULT: "#2AF598",
          dark:    "#1BC97A",
          dim:     "rgba(42,245,152,0.1)",
        },
        surface: {
          DEFAULT: "#0B1F3A",
          2:       "#0F2847",
          3:       "#152F52",
        },
      },
      fontFamily: {
        sans: ["Inter", "system-ui", "sans-serif"],
        display: ["Syne", "sans-serif"],
      },
    },
  },
  plugins: [],
};
