import "dotenv/config";
import express from "express";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";

import authRouter        from "./routes/auth.js";
import articlesRouter    from "./routes/articles.js";
import projectsRouter    from "./routes/projects.js";
import usersRouter       from "./routes/users.js";
import statsRouter       from "./routes/stats.js";
import initiativesRouter from "./routes/initiatives.js";
import newsRouter        from "./routes/news.js";
import tracksRouter      from "./routes/tracks.js";
import galleryRouter     from "./routes/gallery.js";
import uploadRouter      from "./routes/upload.js";
import searchRouter      from "./routes/search.js";
import { errorHandler }  from "./lib/errors.js";
import logger            from "./lib/logger.js";

const app  = express();
const PORT = process.env.PORT ?? 4000;

// ─── Security headers ─────────────────────────────────────────
app.use(helmet({ crossOriginResourcePolicy: { policy: "cross-origin" } }));

// ─── CORS ─────────────────────────────────────────────────────
app.use(cors({
  origin:         process.env.CLIENT_URL ?? "http://localhost:3000",
  methods:        ["GET","POST","PATCH","DELETE","OPTIONS"],
  allowedHeaders: ["Content-Type","Authorization"],
  credentials:    true,
}));

app.use(express.json({ limit: "1mb" }));

// ─── Rate limiting ────────────────────────────────────────────
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, max: 20,
  standardHeaders: true, legacyHeaders: false,
  message: { error: "Too many requests, please try again later" },
  skip: (req) => req.method === "OPTIONS",
});

const apiLimiter = rateLimit({
  windowMs: 60 * 1000, max: 120,
  standardHeaders: true, legacyHeaders: false,
  message: { error: "Too many requests" },
  skip: (req) => req.method === "OPTIONS",
});

app.use("/auth", authLimiter);
app.use(apiLimiter);

// ─── Request logger ────────────────────────────────────────────
app.use((req, res, next) => {
  const start = Date.now();
  res.on("finish", () => {
    const ms  = Date.now() - start;
    const lvl = res.statusCode >= 500 ? "error" : res.statusCode >= 400 ? "warn" : "http";
    logger[lvl]?.(`${req.method} ${req.path} → ${res.statusCode} (${ms}ms)`);
  });
  next();
});

// ─── Routes ──────────────────────────────────────────────────
app.get("/health", (_req, res) => res.json({ ok: true, ts: new Date() }));

app.use("/auth",        authRouter);
app.use("/articles",    articlesRouter);
app.use("/projects",    projectsRouter);
app.use("/users",       usersRouter);
app.use("/stats",       statsRouter);
app.use("/initiatives", initiativesRouter);
app.use("/news",        newsRouter);
app.use("/tracks",      tracksRouter);
app.use("/gallery",     galleryRouter);
app.use("/upload",      uploadRouter);
app.use("/search",      searchRouter);

// 404
app.use((_req, res) => res.status(404).json({ error: "Not found" }));

// Global error handler — MUST be last
app.use(errorHandler);

// ─── Start ───────────────────────────────────────────────────
app.listen(PORT, () => {
  logger.info(`API ready → http://localhost:${PORT}`);
  logger.info(`ENV: ${process.env.NODE_ENV ?? "development"}`);
  logger.debug("Routes: /auth /articles /projects /users /stats /initiatives /news /tracks /gallery /upload /search");
});

const app  = express();
const PORT = process.env.PORT ?? 4000;

// ─── Security headers ─────────────────────────────────────────
app.use(helmet({
  crossOriginResourcePolicy: { policy: "cross-origin" },
}));

// ─── CORS ─────────────────────────────────────────────────────
app.use(cors({
  origin:         process.env.CLIENT_URL ?? "http://localhost:3000",
  methods:        ["GET","POST","PATCH","DELETE","OPTIONS"],
  allowedHeaders: ["Content-Type","Authorization"],
  credentials:    true,
}));

app.use(express.json({ limit: "1mb" }));

// ─── Rate limiting ────────────────────────────────────────────
// Жёсткий лимит для auth-эндпоинтов (защита от брутфорса)
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,  // 15 минут
  max: 20,                    // 20 попыток за 15 минут
  standardHeaders: true,
  legacyHeaders:   false,
  message: { error: "Too many requests, please try again later" },
  skip: (req) => req.method === "OPTIONS",
});

// Мягкий лимит для всего остального API
const apiLimiter = rateLimit({
  windowMs: 60 * 1000,   // 1 минута
  max: 120,              // 120 запросов в минуту
  standardHeaders: true,
  legacyHeaders:   false,
  message: { error: "Too many requests" },
  skip: (req) => req.method === "OPTIONS",
});

app.use("/auth", authLimiter);
app.use(apiLimiter);

// Dev logger
if (process.env.NODE_ENV !== "production") {
  app.use((req, _res, next) => {
    console.log(`${req.method} ${req.path}`);
    next();
  });
}

// ─── Routes ──────────────────────────────────────────────────
app.get("/health", (_req, res) => res.json({ ok: true, ts: new Date() }));

app.use("/auth",        authRouter);
app.use("/articles",    articlesRouter);
app.use("/projects",    projectsRouter);
app.use("/users",       usersRouter);
app.use("/stats",       statsRouter);
app.use("/initiatives", initiativesRouter);
app.use("/news",        newsRouter);
app.use("/tracks",      tracksRouter);
app.use("/gallery",     galleryRouter);
app.use("/upload",      uploadRouter);
app.use("/search",      searchRouter);

// 404
app.use((_req, res) => res.status(404).json({ error: "Not found" }));

// Global error handler — MUST be last
app.use(errorHandler);

// ─── Start ───────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`✅  API ready        → http://localhost:${PORT}`);
  console.log(`    ENV: ${process.env.NODE_ENV ?? "development"}`);
});
