import { verifyAccessToken } from "../lib/jwt.js";
import { AppError } from "../lib/errors.js";
import prisma from "../lib/prisma.js";

// Проверяет Bearer токен, кладёт req.user
export async function authenticate(req, res, next) {
  const header = req.headers.authorization;
  if (!header?.startsWith("Bearer ")) {
    return next(new AppError("No token provided", 401));
  }

  try {
    const token = header.slice(7);
    const payload = verifyAccessToken(token);
    const user = await prisma.user.findUnique({ where: { id: payload.sub } });
    if (!user) return next(new AppError("User not found", 401));
    req.user = user;
    next();
  } catch (err) {
    next(err);
  }
}

// Проверяет минимальную роль (ADMIN > EDITOR > USER)
const ROLES = { USER: 0, EDITOR: 1, ADMIN: 2 };

export function requireRole(minRole) {
  return (req, res, next) => {
    if (!req.user) return next(new AppError("Not authenticated", 401));
    if (ROLES[req.user.role] < ROLES[minRole]) {
      return next(new AppError("Insufficient permissions", 403));
    }
    next();
  };
}
