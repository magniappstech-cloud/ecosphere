import { Router } from "express";
import { z } from "zod";
import prisma from "../lib/prisma.js";
import { AppError, wrap } from "../lib/errors.js";
import { authenticate, requireRole } from "../middleware/auth.js";

const router = Router();

const InitiativeSchema = z.object({
  name:       z.string().min(3).max(200),
  category:   z.enum(["Экология","Охрана труда","Энергетика","Образование","Здоровье","Культура"]),
  shortDesc:  z.string().min(10).max(500),
  problem:    z.string().min(10).max(2000),
  solution:   z.string().min(10).max(2000),
  result:     z.string().max(1000).optional(),
  location:   z.string().max(100).optional(),
  duration:   z.string().max(100).optional(),
  resources:  z.string().max(500).optional(),
  links:      z.string().max(500).optional(),
  authorName: z.string().min(2).max(80),
});

// POST /initiatives — подать инициативу (публично, авторизация опциональна)
router.post("/", wrap(async (req, res) => {
  const data = InitiativeSchema.parse(req.body);

  // Пробуем определить авторизованного пользователя
  let authorId: string | null = null;
  const authHeader = req.headers.authorization;
  if (authHeader?.startsWith("Bearer ")) {
    try {
      const { verifyAccessToken } = await import("../lib/jwt.js");
      const payload = verifyAccessToken(authHeader.slice(7)) as { sub: string };
      authorId = payload.sub;
    } catch { /* не авторизован — ок */ }
  }

  const initiative = await prisma.initiative.create({
    data: { ...data, authorId },
  });

  res.status(201).json({
    ok: true,
    id: initiative.id,
    message: "Инициатива принята. Модератор свяжется с вами в течение 3 рабочих дней.",
  });
}));

// GET /initiatives — список для администратора
router.get("/", authenticate, requireRole("ADMIN"), wrap(async (req, res) => {
  const { status, limit = 20, offset = 0 } = req.query as Record<string, string>;

  const where = status ? { status: status as any } : {};
  const [items, total] = await Promise.all([
    prisma.initiative.findMany({
      where,
      orderBy: { createdAt: "desc" },
      take: Number(limit),
      skip: Number(offset),
    }),
    prisma.initiative.count({ where }),
  ]);

  res.json({ items, total });
}));

// GET /initiatives/:id — одна инициатива (admin)
router.get("/:id", authenticate, requireRole("ADMIN"), wrap(async (req, res) => {
  const item = await prisma.initiative.findUnique({
    where: { id: req.params.id },
    include: { files: true },
  });
  if (!item) throw new AppError("Initiative not found", 404);
  res.json(item);
}));

// PATCH /initiatives/:id/status — модерация (admin)
router.patch("/:id/status", authenticate, requireRole("ADMIN"), wrap(async (req, res) => {
  const { status } = z.object({
    status: z.enum(["REVIEWING","APPROVED","REJECTED"]),
  }).parse(req.body);

  const item = await prisma.initiative.update({
    where: { id: req.params.id },
    data:  { status },
  });
  res.json(item);
}));

export default router;
