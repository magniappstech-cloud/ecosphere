import { Router } from "express";
import { z } from "zod";
import prisma from "../lib/prisma.js";
import { wrap } from "../lib/errors.js";
import { authenticate, requireRole } from "../middleware/auth.js";

const router = Router();

// GET /gallery — публичный список (type=GRID|CASCADE|all)
router.get("/", wrap(async (req, res) => {
  const { type, limit = 24, offset = 0 } = req.query;
  const where = type && type !== "all" ? { type: type.toString().toUpperCase() } : {};
  const [items, total] = await Promise.all([
    prisma.galleryItem.findMany({
      where,
      orderBy: { sortOrder: "asc" },
      take: Number(limit),
      skip: Number(offset),
    }),
    prisma.galleryItem.count({ where }),
  ]);
  res.json({ items, total });
}));

// POST /gallery — добавить (admin)
router.post("/", authenticate, requireRole("ADMIN"), wrap(async (req, res) => {
  const data = z.object({
    title:      z.string().min(1).max(200),
    imageUrl:   z.string().url(),
    author:     z.string().max(100).optional(),
    category:   z.string().default("general"),
    type:       z.enum(["GRID", "CASCADE"]).default("GRID"),
    sortOrder:  z.coerce.number().int().default(0),
  }).parse(req.body);
  const item = await prisma.galleryItem.create({ data });
  res.status(201).json(item);
}));

// DELETE /gallery/:id — удалить (admin)
router.delete("/:id", authenticate, requireRole("ADMIN"), wrap(async (req, res) => {
  await prisma.galleryItem.delete({ where: { id: req.params.id } });
  res.json({ ok: true });
}));

export default router;
