import { Router } from "express";
import { z } from "zod";
import prisma from "../lib/prisma.js";
import { AppError, wrap } from "../lib/errors.js";

const router = Router();

// GET /search?q=текст&type=all|articles|projects|news&limit=10
router.get("/", wrap(async (req, res) => {
  const { q, type = "all", limit = 10 } = z.object({
    q:     z.string().min(1).max(200),
    type:  z.enum(["all", "articles", "projects", "news"]).default("all"),
    limit: z.coerce.number().int().min(1).max(50).default(10),
  }).parse(req.query);

  const term = q.trim();
  if (!term) throw new AppError("Query is required", 400);

  const results = {};

  // ── Статьи ──────────────────────────────────────────────────
  if (type === "all" || type === "articles") {
    results.articles = await prisma.article.findMany({
      where: {
        status: "PUBLISHED",
        OR: [
          { title: { contains: term, mode: "insensitive" } },
          { lead:  { contains: term, mode: "insensitive" } },
        ],
      },
      select: {
        id: true, title: true, slug: true, lead: true,
        tag: true, readTime: true, views: true, createdAt: true,
        author: { select: { id: true, name: true } },
      },
      take: Number(limit),
      orderBy: { views: "desc" },
    });
  }

  // ── Проекты ─────────────────────────────────────────────────
  if (type === "all" || type === "projects") {
    results.projects = await prisma.project.findMany({
      where: {
        status: { in: ["ACTIVE", "COMPLETED"] },
        OR: [
          { title:       { contains: term, mode: "insensitive" } },
          { description: { contains: term, mode: "insensitive" } },
          { location:    { contains: term, mode: "insensitive" } },
        ],
      },
      select: {
        id: true, title: true, description: true,
        stage: true, location: true, emoji: true,
        owner: { select: { id: true, name: true } },
      },
      take: Number(limit),
      orderBy: { createdAt: "desc" },
    });
  }

  // ── Новости ─────────────────────────────────────────────────
  if (type === "all" || type === "news") {
    results.news = await prisma.news.findMany({
      where: {
        status: "PUBLISHED",
        OR: [
          { title:    { contains: term, mode: "insensitive" } },
          { headline: { contains: term, mode: "insensitive" } },
          { body:     { contains: term, mode: "insensitive" } },
        ],
      },
      select: {
        id: true, title: true, headline: true,
        category: true, createdAt: true, authorName: true,
      },
      take: Number(limit),
      orderBy: { createdAt: "desc" },
    });
  }

  // Считаем общее количество результатов
  const total =
    (results.articles?.length ?? 0) +
    (results.projects?.length ?? 0) +
    (results.news?.length    ?? 0);

  res.json({ q: term, total, ...results });
}));

export default router;
