import { Router } from "express";
import prisma from "../lib/prisma.js";
import { AppError, wrap } from "../lib/errors.js";
import { authenticate, requireRole } from "../middleware/auth.js";
import { z } from "zod";

const router = Router();

// ─────────────────────────────────────────────────────────────────────
// ВАЖНО: порядок роутов в Express имеет значение.
// /leaders, /dashboard/stats и /me — ДО /:id
// ─────────────────────────────────────────────────────────────────────

// GET /users/leaders — публичный список лидеров (role=LEADER)
router.get("/leaders", wrap(async (req, res) => {
  const leaders = await prisma.user.findMany({
    where: { role: "LEADER" },
    select: {
      id: true, name: true, avatarUrl: true,
      bio: true, quote: true, emoji: true, role: true,
      _count: { select: { articles: { where: { status: "PUBLISHED" } } } },
    },
    orderBy: { name: "asc" },
  });
  res.json(leaders.map((l) => ({
    id:            l.id,
    name:          l.name,
    avatarUrl:     l.avatarUrl ?? null,
    bio:           l.bio       ?? null,
    quote:         l.quote     ?? null,
    emoji:         l.emoji     ?? null,
    role:          l.role,
    articlesCount: l._count.articles,
  })));
}));

// PATCH /users/:id/role — только ADMIN назначает роли (в т.ч. LEADER)
router.patch("/:id/role", authenticate, requireRole("ADMIN"), wrap(async (req, res) => {
  const { role } = z.object({ role: z.enum(["USER","EDITOR","ADMIN","LEADER"]) }).parse(req.body);
  if (req.params.id === req.user.id && role !== "ADMIN") {
    throw new AppError("Cannot demote yourself from ADMIN", 403);
  }
  const target = await prisma.user.findUnique({ where: { id: req.params.id } });
  if (!target) throw new AppError("User not found", 404);
  const updated = await prisma.user.update({
    where: { id: req.params.id },
    data:  { role },
    select: { id: true, name: true, email: true, role: true },
  });
  res.json(updated);
}));

// PATCH /users/:id/leader-profile — ADMIN редактирует карточку лидера
router.patch("/:id/leader-profile", authenticate, requireRole("ADMIN"), wrap(async (req, res) => {
  const data = z.object({
    quote:     z.string().max(300).optional(),
    emoji:     z.string().max(4).optional(),
    bio:       z.string().max(500).optional(),
    avatarUrl: z.string().url().optional(),
  }).parse(req.body);
  const user = await prisma.user.update({
    where: { id: req.params.id },
    data,
    select: { id: true, name: true, quote: true, emoji: true, bio: true, avatarUrl: true, role: true },
  });
  res.json(user);
}));

// GET /users/dashboard/stats — личная статистика (авт.)
router.get("/dashboard/stats", authenticate, wrap(async (req, res) => {
  const [articleStats, projectStats, pendingRequests] = await Promise.all([
    prisma.article.groupBy({
      by: ["status"], where: { authorId: req.user.id },
      _count: true, _sum: { views: true, likes: true },
    }),
    prisma.project.count({ where: { ownerId: req.user.id } }),
    prisma.projectRequest.count({
      where: { project: { ownerId: req.user.id }, status: "PENDING" },
    }),
  ]);
  const published = articleStats.find((s) => s.status === "PUBLISHED");
  const drafts    = articleStats.find((s) => s.status === "DRAFT");
  res.json({
    articles: {
      published:  published?._count        ?? 0,
      drafts:     drafts?._count           ?? 0,
      totalViews: published?._sum?.views   ?? 0,
      totalLikes: published?._sum?.likes   ?? 0,
    },
    projects: { owned: projectStats, pendingRequests },
  });
}));

// PATCH /users/me — обновить собственный профиль
router.patch("/me", authenticate, wrap(async (req, res) => {
  const data = z.object({
    name:      z.string().min(2).max(80).optional(),
    bio:       z.string().max(500).optional(),
    avatarUrl: z.string().url().optional().or(z.literal("")),
  }).parse(req.body);
  const user = await prisma.user.update({
    where: { id: req.user.id },
    data,
    select: { id: true, name: true, email: true, avatarUrl: true, bio: true, role: true },
  });
  res.json(user);
}));

// GET /users/:id — публичный профиль (ПОСЛЕДНИЙ — ловит любой :id)
router.get("/:id", wrap(async (req, res) => {
  const user = await prisma.user.findUnique({
    where: { id: req.params.id },
    select: {
      id: true, name: true, avatarUrl: true,
      bio: true, quote: true, emoji: true, role: true, createdAt: true,
      _count: { select: { articles: true, ownedProjects: true } },
    },
  });
  if (!user) throw new AppError("User not found", 404);
  res.json(user);
}));

export default router;
