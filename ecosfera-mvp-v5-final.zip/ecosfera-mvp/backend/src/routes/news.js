import { Router } from "express";
import { z } from "zod";
import prisma from "../lib/prisma.js";
import { AppError, wrap } from "../lib/errors.js";
import { authenticate, requireRole } from "../middleware/auth.js";

const router = Router();

const NewsSchema = z.object({
  title:      z.string().min(3).max(200),
  headline:   z.string().max(300).optional(),
  body:       z.string().min(10),
  category:   z.string().default("general"),
  coverImage: z.string().url().optional(),
  isSplash:   z.boolean().default(false),
  authorName: z.string().min(2).max(80),
  readTime:   z.coerce.number().int().min(1).max(30).default(3),
});

// GET /news — публичный список опубликованных новостей
router.get("/", wrap(async (req, res) => {
  const { category, limit = 20, offset = 0 } = req.query;
  const where = {
    status: "PUBLISHED",
    ...(category && category !== "all" && { category }),
  };
  const [items, total] = await Promise.all([
    prisma.news.findMany({
      where,
      orderBy: [{ isSplash: "desc" }, { createdAt: "desc" }],
      take:    Number(limit),
      skip:    Number(offset),
    }),
    prisma.news.count({ where }),
  ]);
  res.json({ items, total });
}));

// GET /news/:id — одна новость
router.get("/:id", wrap(async (req, res) => {
  const news = await prisma.news.findUnique({ where: { id: req.params.id } });
  if (!news || news.status !== "PUBLISHED") throw new AppError("Not found", 404);
  res.json(news);
}));

// POST /news — создать (admin)
router.post("/", authenticate, requireRole("ADMIN"), wrap(async (req, res) => {
  const data = NewsSchema.parse(req.body);
  // Если isSplash — снимаем с остальных
  if (data.isSplash) {
    await prisma.news.updateMany({ where: { isSplash: true }, data: { isSplash: false } });
  }
  const news = await prisma.news.create({
    data: { ...data, authorId: req.user.id, status: "PUBLISHED" },
  });
  res.status(201).json(news);
}));

// PATCH /news/:id — обновить (admin)
router.patch("/:id", authenticate, requireRole("ADMIN"), wrap(async (req, res) => {
  const data = NewsSchema.partial().parse(req.body);
  if (data.isSplash) {
    await prisma.news.updateMany({ where: { isSplash: true }, data: { isSplash: false } });
  }
  const news = await prisma.news.update({ where: { id: req.params.id }, data });
  res.json(news);
}));

// DELETE /news/:id — удалить (admin)
router.delete("/:id", authenticate, requireRole("ADMIN"), wrap(async (req, res) => {
  await prisma.news.delete({ where: { id: req.params.id } });
  res.json({ ok: true });
}));

export default router;
