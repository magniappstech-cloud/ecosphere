import { Router } from "express";
import bcrypt from "bcryptjs";
import prisma from "../lib/prisma.js";
import { signAccessToken, signRefreshToken, verifyRefreshToken } from "../lib/jwt.js";
import { AppError, wrap } from "../lib/errors.js";
import { authenticate } from "../middleware/auth.js";
import { RegisterSchema, LoginSchema } from "../lib/schemas.js";
import { passwordResetRouter } from "./password-reset.js";
import { sendWelcomeEmail } from "../lib/email.js";

const router = Router();

// Подключаем роуты сброса пароля
router.use(passwordResetRouter);

// POST /auth/register
router.post("/register", wrap(async (req, res) => {
  const data = RegisterSchema.parse(req.body);
  const passwordHash = await bcrypt.hash(data.password, 12);

  const user = await prisma.user.create({
    data: { name: data.name, email: data.email, passwordHash },
    select: { id: true, name: true, email: true, role: true, createdAt: true },
  });

  const accessToken  = signAccessToken({ sub: user.id, role: user.role });
  const refreshToken = signRefreshToken({ sub: user.id });

  await prisma.refreshToken.create({
    data: {
      token: refreshToken,
      userId: user.id,
      expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
    },
  });

  // Welcome email — fire-and-forget, не блокируем ответ
  sendWelcomeEmail(user.email, user.name).catch(() => {});

  res.status(201).json({ user, accessToken, refreshToken });
}));

// POST /auth/login
router.post("/login", wrap(async (req, res) => {
  const { email, password } = LoginSchema.parse(req.body);

  const user = await prisma.user.findUnique({ where: { email } });
  if (!user) throw new AppError("Invalid credentials", 401);

  const valid = await bcrypt.compare(password, user.passwordHash);
  if (!valid) throw new AppError("Invalid credentials", 401);

  const accessToken  = signAccessToken({ sub: user.id, role: user.role });
  const refreshToken = signRefreshToken({ sub: user.id });

  await prisma.refreshToken.create({
    data: {
      token: refreshToken,
      userId: user.id,
      expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
    },
  });

  const { passwordHash: _, ...safeUser } = user;
  res.json({ user: safeUser, accessToken, refreshToken });
}));

// POST /auth/refresh
router.post("/refresh", wrap(async (req, res) => {
  const { refreshToken } = req.body;
  if (!refreshToken) throw new AppError("Refresh token required", 400);

  const payload = verifyRefreshToken(refreshToken);

  const stored = await prisma.refreshToken.findUnique({ where: { token: refreshToken } });
  if (!stored || stored.expiresAt < new Date()) {
    throw new AppError("Invalid refresh token", 401);
  }

  // Rotate токен
  await prisma.refreshToken.delete({ where: { id: stored.id } });

  const user = await prisma.user.findUnique({ where: { id: payload.sub } });
  if (!user) throw new AppError("User not found", 401);

  const newAccess  = signAccessToken({ sub: user.id, role: user.role });
  const newRefresh = signRefreshToken({ sub: user.id });

  await prisma.refreshToken.create({
    data: {
      token: newRefresh,
      userId: user.id,
      expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
    },
  });

  res.json({ accessToken: newAccess, refreshToken: newRefresh });
}));

// POST /auth/logout
router.post("/logout", wrap(async (req, res) => {
  const { refreshToken } = req.body;
  if (refreshToken) {
    await prisma.refreshToken.deleteMany({ where: { token: refreshToken } });
  }
  res.json({ ok: true });
}));

// GET /auth/me
router.get("/me", authenticate, wrap(async (req, res) => {
  const { passwordHash: _, ...user } = req.user;
  res.json(user);
}));

export default router;
