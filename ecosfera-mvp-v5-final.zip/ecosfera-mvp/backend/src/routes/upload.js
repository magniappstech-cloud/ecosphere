import { Router } from "express";
import multer from "multer";
import { AppError, wrap } from "../lib/errors.js";
import { authenticate } from "../middleware/auth.js";

const router = Router();

// Multer — memory storage (файл в буфере, отправляем в облако)
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB
  },
  fileFilter: (_req, file, cb) => {
    const allowed = ["image/jpeg", "image/png", "image/webp", "image/gif"];
    if (allowed.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new AppError("Only images are allowed (jpeg, png, webp, gif)", 400));
    }
  },
});

// ─── Cloudinary upload helper ────────────────────────────────
async function uploadToCloudinary(buffer, folder = "ecosfera") {
  // В dev — возвращаем заглушку, в prod подключить Cloudinary SDK
  if (process.env.NODE_ENV !== "production" || !process.env.CLOUDINARY_URL) {
    console.log("[Upload] Dev mode — returning placeholder URL");
    return `https://via.placeholder.com/800x600?text=uploaded`;
  }

  // Production: раскомментировать после npm install cloudinary
  // const { v2: cloudinary } = await import("cloudinary");
  // cloudinary.config({ cloudinary_url: process.env.CLOUDINARY_URL });
  // return new Promise((resolve, reject) => {
  //   const stream = cloudinary.uploader.upload_stream(
  //     { folder, resource_type: "image", transformation: [{ quality: "auto" }] },
  //     (err, result) => err ? reject(err) : resolve(result.secure_url)
  //   );
  //   stream.end(buffer);
  // });
}

// POST /upload — загрузить одно изображение (авт.)
router.post("/", authenticate, upload.single("file"), wrap(async (req, res) => {
  if (!req.file) throw new AppError("No file uploaded", 400);

  const folder = req.body.folder ?? "general"; // avatars | articles | gallery | news
  const url    = await uploadToCloudinary(req.file.buffer, `ecosfera/${folder}`);

  res.json({ url, originalName: req.file.originalname, size: req.file.size });
}));

// POST /upload/multiple — до 5 файлов (авт.)
router.post("/multiple", authenticate, upload.array("files", 5), wrap(async (req, res) => {
  const files = req.files;
  if (!files || !files.length) throw new AppError("No files uploaded", 400);

  const folder = req.body.folder ?? "general";
  const uploads = await Promise.all(
    files.map((f) => uploadToCloudinary(f.buffer, `ecosfera/${folder}`))
  );

  res.json({ urls: uploads, count: uploads.length });
}));

export default router;
