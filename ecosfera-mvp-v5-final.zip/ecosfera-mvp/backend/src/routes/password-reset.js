import { Router } from "express";
import crypto from "crypto";
import bcrypt from "bcryptjs";
import { z } from "zod";
import prisma from "../lib/prisma.js";
import { AppError, wrap } from "../lib/errors.js";
import { sendPasswordResetEmail } from "../lib/email.js";

const router = Router();

// POST /auth/forgot-password
// Принимает email, создаёт токен сброса, отправляет письмо.
router.post("/forgot-password", wrap(async (req, res) => {
  const { email } = z.object({ email: z.string().email() }).parse(req.body);

  const user = await prisma.user.findUnique({ where: { email } });

  // Всегда отвечаем 200 — не раскрываем существование email
  if (!user) {
    return res.json({ ok: true, message: "Если email зарегистрирован, письмо отправлено." });
  }

  // Инвалидируем старые токены этого пользователя
  await prisma.passwordReset.deleteMany({ where: { userId: user.id } });

  // Генерируем криптостойкий токен
  const token     = crypto.randomBytes(32).toString("hex");
  const expiresAt = new Date(Date.now() + 60 * 60 * 1000); // 1 час

  await prisma.passwordReset.create({
    data: { token, userId: user.id, expiresAt },
  });

  const resetUrl = `${process.env.CLIENT_URL ?? "http://localhost:3000"}/reset-password?token=${token}`;
  await sendPasswordResetEmail(email, token);

  res.json({ ok: true, message: "Если email зарегистрирован, письмо отправлено." });
}));

// POST /auth/reset-password
// Принимает token + newPassword, сбрасывает пароль.
router.post("/reset-password", wrap(async (req, res) => {
  const { token, password } = z.object({
    token:    z.string().min(1),
    password: z.string().min(8).max(72),
  }).parse(req.body);

  const record = await prisma.passwordReset.findUnique({ where: { token } });

  if (!record || record.usedAt || record.expiresAt < new Date()) {
    throw new AppError("Токен недействителен или истёк", 400);
  }

  const passwordHash = await bcrypt.hash(password, 12);

  // Транзакция: обновить пароль + пометить токен использованным
  await prisma.$transaction([
    prisma.user.update({
      where: { id: record.userId },
      data:  { passwordHash },
    }),
    prisma.passwordReset.update({
      where: { id: record.id },
      data:  { usedAt: new Date() },
    }),
    // Инвалидируем все refresh-токены (принудительный logout)
    prisma.refreshToken.deleteMany({ where: { userId: record.userId } }),
  ]);

  res.json({ ok: true, message: "Пароль успешно изменён. Войдите с новым паролем." });
}));

export { router as passwordResetRouter };
