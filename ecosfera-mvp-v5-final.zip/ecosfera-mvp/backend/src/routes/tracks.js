import { Router } from "express";
import { z } from "zod";
import prisma from "../lib/prisma.js";
import { AppError, wrap } from "../lib/errors.js";
import { authenticate, requireRole } from "../middleware/auth.js";

const router = Router();

// GET /tracks — публичный список треков для плеера
router.get("/", wrap(async (req, res) => {
  const tracks = await prisma.track.findMany({
    orderBy: [{ isNew: "desc" }, { likes: "desc" }, { sortOrder: "asc" }],
    select: {
      id: true, title: true, artist: true,
      duration: true, durationSec: true,
      src: true, coverImage: true,
      emoji: true, likes: true, isNew: true,
    },
  });
  res.json({ tracks, total: tracks.length });
}));

// POST /tracks/:id/like — лайк трека per-user (toggle)
router.post("/:id/like", authenticate, wrap(async (req, res) => {
  const trackId = req.params.id;
  const userId  = req.user.id;

  const track = await prisma.track.findUnique({ where: { id: trackId } });
  if (!track) throw new AppError("Track not found", 404);

  const existing = await prisma.trackLike.findUnique({
    where: { trackId_userId: { trackId, userId } },
  });

  if (existing) {
    await prisma.$transaction([
      prisma.trackLike.delete({ where: { id: existing.id } }),
      prisma.track.update({ where: { id: trackId }, data: { likes: { decrement: 1 } } }),
    ]);
    return res.json({ liked: false, likes: Math.max(0, track.likes - 1) });
  }

  const [, updated] = await prisma.$transaction([
    prisma.trackLike.create({ data: { trackId, userId } }),
    prisma.track.update({ where: { id: trackId }, data: { likes: { increment: 1 } } }),
  ]);
  res.json({ liked: true, likes: updated.likes });
}));

// POST /tracks — создать трек (admin)
router.post("/", authenticate, requireRole("ADMIN"), wrap(async (req, res) => {
  const data = z.object({
    title:       z.string().min(1).max(200),
    artist:      z.string().min(1).max(200),
    duration:    z.string().default("0:00"),
    durationSec: z.coerce.number().int().default(0),
    src:         z.string().url().optional(),
    coverImage:  z.string().url().optional(),
    emoji:       z.string().max(4).optional(),
    isNew:       z.boolean().default(false),
    sortOrder:   z.coerce.number().int().default(0),
  }).parse(req.body);
  const track = await prisma.track.create({ data });
  res.status(201).json(track);
}));

// DELETE /tracks/:id — удалить (admin)
router.delete("/:id", authenticate, requireRole("ADMIN"), wrap(async (req, res) => {
  await prisma.track.delete({ where: { id: req.params.id } });
  res.json({ ok: true });
}));

export default router;
