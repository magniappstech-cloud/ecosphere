// Добавляем в существующий users.js — новые эндпоинты для лидеров

/*
  PATCH /users/:id/role
  ─────────────────────────────────────────────────────────────────────
  Только ADMIN может назначать роли пользователям, в том числе LEADER.
  Допустимые роли: USER | EDITOR | ADMIN | LEADER
  ─────────────────────────────────────────────────────────────────────
  GET /users/leaders
  ─────────────────────────────────────────────────────────────────────
  Публичный список пользователей с role=LEADER.
  Каждый объект содержит articlesCount — число опубликованных статей.
  Если articlesCount === 0, фронтенд делает карточку неактивной.
  ─────────────────────────────────────────────────────────────────────
*/

import { Router } from "express";
import prisma from "../lib/prisma.js";
import { AppError, wrap } from "../lib/errors.js";
import { authenticate, requireRole } from "../middleware/auth.js";
import { z } from "zod";

const router = Router();

/* GET /users/leaders — публичный список лидеров */
router.get("/leaders", wrap(async (req, res) => {
  const leaders = await prisma.user.findMany({
    where: { role: "LEADER" },
    select: {
      id:        true,
      name:      true,
      avatarUrl: true,
      bio:       true,
      role:      true,
      quote:     true,   /* поле цитаты — добавлено в схему ниже */
      emoji:     true,   /* эмодзи-аватар                        */
      _count: {
        select: {
          articles: {
            where: { status: "PUBLISHED" },
          },
        },
      },
    },
    orderBy: { name: "asc" },
  });

  /* Нормализуем: articlesCount вместо _count.articles */
  const result = leaders.map((l) => ({
    id:            l.id,
    name:          l.name,
    avatarUrl:     l.avatarUrl,
    bio:           l.bio,
    role:          l.role,
    quote:         l.quote,
    emoji:         l.emoji,
    articlesCount: l._count.articles,
  }));

  res.json(result);
}));

/* PATCH /users/:id/role — только ADMIN назначает роли */
router.patch("/:id/role", authenticate, requireRole("ADMIN"), wrap(async (req, res) => {
  const RoleSchema = z.object({
    role: z.enum(["USER", "EDITOR", "ADMIN", "LEADER"]),
  });

  const { role } = RoleSchema.parse(req.body);

  /* Нельзя снять роль с себя самого */
  if (req.params.id === req.user.id && role !== "ADMIN") {
    throw new AppError("Cannot change your own admin role", 403);
  }

  const user = await prisma.user.update({
    where: { id: req.params.id },
    data:  { role },
    select: { id: true, name: true, email: true, role: true },
  });

  res.json(user);
}));

/* GET /users/:id — публичный профиль (существующий роут дублировать не нужно) */

/* GET /users/dashboard/stats — личная статистика (существующий) */

/* PATCH /users/me — обновить профиль (существующий) */

export default router;
