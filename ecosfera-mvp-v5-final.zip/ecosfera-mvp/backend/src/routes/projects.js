import { Router } from "express";
import prisma from "../lib/prisma.js";
import { AppError, wrap } from "../lib/errors.js";
import { authenticate } from "../middleware/auth.js";
import {
  CreateProjectSchema,
  UpdateProjectSchema,
  JoinRequestSchema,
  ReviewRequestSchema,
} from "../lib/schemas.js";

const router = Router();

const USER_SELECT = { id: true, name: true, avatarUrl: true };

// GET /projects
router.get("/", wrap(async (req, res) => {
  const { stage, status = "ACTIVE", limit = 20, offset = 0 } = req.query;
  const where = { status, ...(stage && { stage }) };

  const [projects, total] = await Promise.all([
    prisma.project.findMany({
      where,
      include: {
        owner: { select: USER_SELECT },
        members: { include: { user: { select: USER_SELECT } } },
        _count: { select: { articles: true } },
      },
      orderBy: { createdAt: "desc" },
      take: Number(limit),
      skip: Number(offset),
    }),
    prisma.project.count({ where }),
  ]);

  res.json({ projects, total });
}));

// GET /projects/:id
router.get("/:id", wrap(async (req, res) => {
  const project = await prisma.project.findUnique({
    where: { id: req.params.id },
    include: {
      owner: { select: USER_SELECT },
      members: { include: { user: { select: USER_SELECT } } },
      articles: {
        where: { status: "PUBLISHED" },
        orderBy: { createdAt: "desc" },
        take: 5,
      },
    },
  });
  if (!project) throw new AppError("Project not found", 404);
  res.json(project);
}));

// POST /projects — создать (авт.)
router.post("/", authenticate, wrap(async (req, res) => {
  const data = CreateProjectSchema.parse(req.body);

  const project = await prisma.project.create({
    data: {
      ...data,
      ownerId: req.user.id,
      // Автор сразу становится OWNER-участником
      members: {
        create: { userId: req.user.id, role: "OWNER" },
      },
    },
    include: { owner: { select: USER_SELECT }, members: true },
  });

  res.status(201).json(project);
}));

// PATCH /projects/:id — обновить (только owner)
router.patch("/:id", authenticate, wrap(async (req, res) => {
  const project = await prisma.project.findUnique({ where: { id: req.params.id } });
  if (!project) throw new AppError("Project not found", 404);
  if (project.ownerId !== req.user.id && req.user.role !== "ADMIN") {
    throw new AppError("Forbidden", 403);
  }

  const data = UpdateProjectSchema.parse(req.body);
  const updated = await prisma.project.update({
    where: { id: req.params.id },
    data,
    include: { owner: { select: USER_SELECT }, members: true },
  });

  res.json(updated);
}));

// DELETE /projects/:id
router.delete("/:id", authenticate, wrap(async (req, res) => {
  const project = await prisma.project.findUnique({ where: { id: req.params.id } });
  if (!project) throw new AppError("Project not found", 404);
  if (project.ownerId !== req.user.id && req.user.role !== "ADMIN") {
    throw new AppError("Forbidden", 403);
  }
  await prisma.project.delete({ where: { id: req.params.id } });
  res.json({ ok: true });
}));

// ─── JOIN REQUESTS ─────────────────────────────────────────────

// POST /projects/:id/request — подать заявку
router.post("/:id/request", authenticate, wrap(async (req, res) => {
  const { message } = JoinRequestSchema.parse(req.body);
  const project = await prisma.project.findUnique({ where: { id: req.params.id } });
  if (!project) throw new AppError("Project not found", 404);

  // Уже участник?
  const isMember = await prisma.projectMember.findUnique({
    where: { projectId_userId: { projectId: req.params.id, userId: req.user.id } },
  });
  if (isMember) throw new AppError("Already a member", 409);

  const request = await prisma.projectRequest.create({
    data: { projectId: req.params.id, userId: req.user.id, message },
  });
  res.status(201).json(request);
}));

// GET /projects/:id/requests — список заявок (owner)
router.get("/:id/requests", authenticate, wrap(async (req, res) => {
  const project = await prisma.project.findUnique({ where: { id: req.params.id } });
  if (!project) throw new AppError("Project not found", 404);
  if (project.ownerId !== req.user.id) throw new AppError("Forbidden", 403);

  const requests = await prisma.projectRequest.findMany({
    where: { projectId: req.params.id, status: "PENDING" },
    include: { user: { select: USER_SELECT } },
  });
  res.json(requests);
}));

// PATCH /projects/:id/requests/:reqId — approve/reject
router.patch("/:id/requests/:reqId", authenticate, wrap(async (req, res) => {
  const { status } = ReviewRequestSchema.parse(req.body);

  const project = await prisma.project.findUnique({ where: { id: req.params.id } });
  if (!project) throw new AppError("Project not found", 404);
  if (project.ownerId !== req.user.id) throw new AppError("Forbidden", 403);

  const request = await prisma.projectRequest.update({
    where: { id: req.params.reqId },
    data: { status },
  });

  // При одобрении — добавляем участника
  if (status === "APPROVED") {
    await prisma.projectMember.create({
      data: { projectId: req.params.id, userId: request.userId, role: "MEMBER" },
    });
  }

  res.json(request);
}));

// GET /projects/my — мои проекты (owner)
router.get("/my/owned", authenticate, wrap(async (req, res) => {
  const projects = await prisma.project.findMany({
    where: { ownerId: req.user.id },
    include: {
      members: { include: { user: { select: USER_SELECT } } },
      _count: { select: { requests: true } },
    },
    orderBy: { createdAt: "desc" },
  });
  res.json(projects);
}));

// GET /projects/my/member — проекты где я участник
router.get("/my/member", authenticate, wrap(async (req, res) => {
  const memberships = await prisma.projectMember.findMany({
    where: { userId: req.user.id },
    include: {
      project: {
        include: { owner: { select: USER_SELECT } },
      },
    },
  });
  res.json(memberships.map((m) => ({ ...m.project, memberRole: m.role })));
}));

export default router;
