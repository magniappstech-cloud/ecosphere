import { Router } from "express";
import prisma from "../lib/prisma.js";
import { wrap } from "../lib/errors.js";

const router = Router();

/*
  GET /stats/public
  ─────────────────────────────────────────────────────────────────────
  Возвращает агрегированные данные для главной страницы:
    - users:             сумма всех зарегистрированных пользователей
    - projects:          одобренные администратором проекты
                         (status = ACTIVE или COMPLETED)
    - articles:          опубликованные статьи (status = PUBLISHED)
    - countries:         количество уникальных стран в одобренных проектах,
                         где count > 0 (т.е. хотя бы один проект)
    - projectsByCountry: массив { country, count, status } для построения
                         пинов на карте — только страны с count > 0
  ─────────────────────────────────────────────────────────────────────
*/
router.get("/public", wrap(async (req, res) => {
  const [
    usersCount,
    projectsCount,
    articlesCount,
    countryAgg,
  ] = await Promise.all([

    /* 1. Все зарегистрированные пользователи */
    prisma.user.count(),

    /* 2. Одобренные проекты: status ACTIVE или COMPLETED */
    prisma.project.count({
      where: { status: { in: ["ACTIVE", "COMPLETED"] } },
    }),

    /* 3. Опубликованные статьи */
    prisma.article.count({
      where: { status: "PUBLISHED" },
    }),

    /* 4. Группировка проектов по стране (только одобренные) */
    prisma.project.groupBy({
      by:    ["location"],
      where: {
        status:   { in: ["ACTIVE", "COMPLETED"] },
        location: { not: null },
      },
      _count: { id: true },
    }),
  ]);

  /* Строим массив стран — только те где count > 0 */
  const projectsByCountry = countryAgg
    .filter((row) => row.location && row._count.id > 0)
    .map((row) => ({
      country: row.location,
      count:   row._count.id,
      /* Статус пина: ACTIVE если хоть один активный проект в стране */
      status:  "ACTIVE",   /* упрощение: отдельный запрос ниже при необходимости */
    }));

  /* Количество уникальных стран (count > 0 — уже отфильтровано выше) */
  const countriesCount = projectsByCountry.length;

  res.json({
    users:             usersCount,
    projects:          projectsCount,
    articles:          articlesCount,
    countries:         countriesCount,
    projectsByCountry,
  });
}));

export default router;
