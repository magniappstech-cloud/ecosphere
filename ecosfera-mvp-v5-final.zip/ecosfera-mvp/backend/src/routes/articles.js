import { Router } from "express";
import prisma from "../lib/prisma.js";
import { AppError, wrap } from "../lib/errors.js";
import { authenticate } from "../middleware/auth.js";
import { CreateArticleSchema, UpdateArticleSchema } from "../lib/schemas.js";

const router = Router();

// Публичные поля автора
const AUTHOR_SELECT = { id: true, name: true, avatarUrl: true, role: true };

// GET /articles — список опубликованных (+ черновики для автора)
router.get("/", wrap(async (req, res) => {
  const { tag, status, authorId, limit = 20, offset = 0 } = req.query;

  const where = {
    status: "PUBLISHED",   // по умолчанию только опубликованные
    ...(tag && { tag }),
    ...(authorId && { authorId }),
  };

  // Если запрашиваем черновики — нужна авторизация
  if (status === "DRAFT") {
    if (!req.headers.authorization) throw new AppError("Auth required for drafts", 401);
  }

  const [articles, total] = await Promise.all([
    prisma.article.findMany({
      where,
      include: { author: { select: AUTHOR_SELECT } },
      orderBy: { createdAt: "desc" },
      take: Number(limit),
      skip: Number(offset),
    }),
    prisma.article.count({ where }),
  ]);

  res.json({ articles, total, limit: Number(limit), offset: Number(offset) });
}));

// GET /articles/my — черновики и статьи текущего пользователя
router.get("/my", authenticate, wrap(async (req, res) => {
  const articles = await prisma.article.findMany({
    where: { authorId: req.user.id },
    orderBy: { updatedAt: "desc" },
  });
  res.json(articles);
}));

// GET /articles/id/:id — получить статью по UUID (для редактирования в dashboard)
router.get("/id/:id", wrap(async (req, res) => {
  const article = await prisma.article.findUnique({
    where: { id: req.params.id },
    include: { author: { select: AUTHOR_SELECT }, project: { select: { id: true, title: true } } },
  });
  if (!article) throw new AppError("Article not found", 404);
  if (article.status === "DRAFT") {
    const authHeader = req.headers.authorization;
    if (!authHeader) throw new AppError("Not found", 404);
  }
  res.json(article);
}));

// GET /articles/:slug
router.get("/:slug", wrap(async (req, res) => {
  const article = await prisma.article.findUnique({
    where: { slug: req.params.slug },
    include: { author: { select: AUTHOR_SELECT }, project: { select: { id: true, title: true } } },
  });
  if (!article) throw new AppError("Article not found", 404);
  if (article.status === "DRAFT") {
    // Черновик — только автор
    const authHeader = req.headers.authorization;
    if (!authHeader) throw new AppError("Not found", 404);
  }

  // Инкремент просмотров (fire-and-forget)
  prisma.article.update({ where: { slug: req.params.slug }, data: { views: { increment: 1 } } }).catch(() => {});

  res.json(article);
}));

// POST /articles — создать (авт.)
router.post("/", authenticate, wrap(async (req, res) => {
  const data = CreateArticleSchema.parse(req.body);

  const slug = slugify(data.title);
  const unique = await ensureUniqueSlug(slug);

  const article = await prisma.article.create({
    data: { ...data, slug: unique, authorId: req.user.id },
    include: { author: { select: AUTHOR_SELECT } },
  });

  res.status(201).json(article);
}));

// PATCH /articles/:id — обновить (автор или editor)
router.patch("/:id", authenticate, wrap(async (req, res) => {
  const existing = await prisma.article.findUnique({ where: { id: req.params.id } });
  if (!existing) throw new AppError("Article not found", 404);

  const isOwner = existing.authorId === req.user.id;
  const isEditor = req.user.role === "EDITOR" || req.user.role === "ADMIN";
  if (!isOwner && !isEditor) throw new AppError("Forbidden", 403);

  const data = UpdateArticleSchema.parse(req.body);

  // При смене заголовка — пересчитать slug
  if (data.title && data.title !== existing.title) {
    data.slug = await ensureUniqueSlug(slugify(data.title), existing.id);
  }

  const updated = await prisma.article.update({
    where: { id: req.params.id },
    data,
    include: { author: { select: AUTHOR_SELECT } },
  });

  res.json(updated);
}));

// DELETE /articles/:id — удалить (автор или admin)
router.delete("/:id", authenticate, wrap(async (req, res) => {
  const existing = await prisma.article.findUnique({ where: { id: req.params.id } });
  if (!existing) throw new AppError("Article not found", 404);

  const isOwner = existing.authorId === req.user.id;
  const isAdmin = req.user.role === "ADMIN";
  if (!isOwner && !isAdmin) throw new AppError("Forbidden", 403);

  await prisma.article.delete({ where: { id: req.params.id } });
  res.json({ ok: true });
}));

// POST /articles/:id/like — лайк (авт.), один юзер — один лайк
router.post("/:id/like", authenticate, wrap(async (req, res) => {
  const articleId = req.params.id;
  const userId    = req.user.id;

  // Проверяем существование статьи
  const article = await prisma.article.findUnique({ where: { id: articleId } });
  if (!article) throw new AppError("Article not found", 404);

  // Проверяем — уже лайкал?
  const existing = await prisma.articleLike.findUnique({
    where: { articleId_userId: { articleId, userId } },
  });

  if (existing) {
    // Убираем лайк (toggle)
    await prisma.$transaction([
      prisma.articleLike.delete({ where: { id: existing.id } }),
      prisma.article.update({ where: { id: articleId }, data: { likes: { decrement: 1 } } }),
    ]);
    return res.json({ id: articleId, liked: false, likes: Math.max(0, article.likes - 1) });
  }

  // Ставим лайк
  const [, updated] = await prisma.$transaction([
    prisma.articleLike.create({ data: { articleId, userId } }),
    prisma.article.update({ where: { id: articleId }, data: { likes: { increment: 1 } } }),
  ]);

  res.json({ id: articleId, liked: true, likes: updated.likes });
}));

// GET /articles/:id/liked — проверить, лайкал ли текущий юзер
router.get("/:id/liked", authenticate, wrap(async (req, res) => {
  const existing = await prisma.articleLike.findUnique({
    where: { articleId_userId: { articleId: req.params.id, userId: req.user.id } },
  });
  res.json({ liked: !!existing });
}));

// ─── helpers ───────────────────────────────────────────────────
function slugify(title) {
  return title
    .toLowerCase()
    .replace(/[а-яё]/g, (c) => RU_MAP[c] || c)
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 80);
}

async function ensureUniqueSlug(base, excludeId = null) {
  let slug = base;
  let i = 1;
  while (true) {
    const found = await prisma.article.findUnique({ where: { slug } });
    if (!found || found.id === excludeId) return slug;
    slug = `${base}-${i++}`;
  }
}

const RU_MAP = { а:"a",б:"b",в:"v",г:"g",д:"d",е:"e",ё:"yo",ж:"zh",з:"z",и:"i",й:"y",к:"k",л:"l",м:"m",н:"n",о:"o",п:"p",р:"r",с:"s",т:"t",у:"u",ф:"f",х:"kh",ц:"ts",ч:"ch",ш:"sh",щ:"sch",ъ:"",ы:"y",ь:"",э:"e",ю:"yu",я:"ya" };

export default router;
