// prisma/seed.js — тестовые данные для ЭкоСфера MVP v5.0
import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  console.log("🌱  Seeding database...");
  const hash = await bcrypt.hash("password123", 12);

  // ── Пользователи ─────────────────────────────────────────────────
  const admin = await prisma.user.upsert({
    where:  { email: "admin@ecosfera.ru" },
    update: {},
    create: {
      name:         "Александр Петров",
      email:        "admin@ecosfera.ru",
      passwordHash: hash,
      role:         "ADMIN",
      bio:          "Эксперт ISO 45001 · Москва",
      quote:        "«Безопасность — это не свод правил, это мировоззрение целого поколения.»",
      emoji:        "👷",
    },
  });

  const leader1 = await prisma.user.upsert({
    where:  { email: "elena@ecosfera.ru" },
    update: {},
    create: {
      name:         "Елена Смирнова",
      email:        "elena@ecosfera.ru",
      passwordHash: hash,
      role:         "LEADER",           // назначена лидером администратором
      bio:          "Эколог-исследователь · СПб",
      quote:        "«Каждое действие сегодня — это среда обитания для тех, кто придёт после нас.»",
      emoji:        "🔬",
    },
  });

  const leader2 = await prisma.user.upsert({
    where:  { email: "maria@ecosfera.ru" },
    update: {},
    create: {
      name:         "Мария Козлова",
      email:        "maria@ecosfera.ru",
      passwordHash: hash,
      role:         "LEADER",
      bio:          "Активист · Новосибирск",
      quote:        "«2000+ человек объединились за год. Следующий шаг — 10 000.»",
      emoji:        "🌿",
    },
  });

  const leader3 = await prisma.user.upsert({
    where:  { email: "dmitry@ecosfera.ru" },
    update: {},
    create: {
      name:         "Дмитрий Орлов",
      email:        "dmitry@ecosfera.ru",
      passwordHash: hash,
      role:         "LEADER",
      bio:          "Энергетик · Екатеринбург",
      quote:        "«ISO 50001 — не затраты. Это инвестиция в следующие 50 лет.»",
      emoji:        "⚡",
    },
  });

  // Лидер БЕЗ статей — карточка должна быть неактивной
  const leader4 = await prisma.user.upsert({
    where:  { email: "anna@ecosfera.ru" },
    update: {},
    create: {
      name:         "Анна Волкова",
      email:        "anna@ecosfera.ru",
      passwordHash: hash,
      role:         "LEADER",
      bio:          "Арт-директор · Казань",
      quote:        "«Искусство меняет сознание быстрее любого регламента.»",
      emoji:        "🎨",
    },
  });

  const user1 = await prisma.user.upsert({
    where:  { email: "user@ecosfera.ru" },
    update: {},
    create: {
      name:         "Игорь Николаев",
      email:        "user@ecosfera.ru",
      passwordHash: hash,
      role:         "USER",
      bio:          "Строитель · Краснодар",
    },
  });

  // ── Проекты (одобренные, status=ACTIVE/COMPLETED) ─────────────────
  const project1 = await prisma.project.upsert({
    where:  { id: "seed-project-msk" },
    update: {},
    create: {
      id:          "seed-project-msk",
      title:       "Нулевой травматизм на производстве",
      description: "Внедрение культуры безопасности и ISO 45001 на предприятиях Урала.",
      stage:       "ACTIVE",
      status:      "ACTIVE",           // одобрен — попадает в счётчик
      location:    "Россия",
      emoji:       "⚡",
      ownerId:     admin.id,
      members: { create: [
        { userId: admin.id,   role: "OWNER"  },
        { userId: leader1.id, role: "EDITOR" },
      ]},
    },
  });

  const project2 = await prisma.project.upsert({
    where:  { id: "seed-project-spb" },
    update: {},
    create: {
      id:          "seed-project-spb",
      title:       "Зелёная энергетика Северо-Запада",
      description: "Переход промышленных объектов на ВИЭ в Ленинградской области.",
      stage:       "PLANNING",
      status:      "ACTIVE",
      location:    "Россия",
      emoji:       "🌿",
      ownerId:     leader1.id,
      members: { create: [{ userId: leader1.id, role: "OWNER" }] },
    },
  });

  const project3 = await prisma.project.upsert({
    where:  { id: "seed-project-de" },
    update: {},
    create: {
      id:          "seed-project-de",
      title:       "Европейские стандарты безопасности",
      description: "Адаптация европейских норм охраны труда для российских компаний.",
      stage:       "ACTIVE",
      status:      "ACTIVE",
      location:    "Германия",           // другая страна → отдельный пин на карте
      emoji:       "🇩🇪",
      ownerId:     leader2.id,
      members: { create: [{ userId: leader2.id, role: "OWNER" }] },
    },
  });

  const project4 = await prisma.project.upsert({
    where:  { id: "seed-project-kz" },
    update: {},
    create: {
      id:          "seed-project-kz",
      title:       "Охрана труда в Казахстане",
      description: "Реализация стандартов ISO 45001 на горнодобывающих предприятиях.",
      stage:       "COMPLETED",
      status:      "COMPLETED",
      location:    "Казахстан",
      emoji:       "🏔️",
      ownerId:     leader3.id,
      members: { create: [{ userId: leader3.id, role: "OWNER" }] },
    },
  });

  // Проект ещё не одобрен (PAUSED/ARCHIVED) — НЕ должен попасть в счётчик
  await prisma.project.upsert({
    where:  { id: "seed-project-draft" },
    update: {},
    create: {
      id:          "seed-project-draft",
      title:       "Черновой проект",
      description: "Этот проект ещё не одобрен администратором.",
      stage:       "IDEA",
      status:      "PAUSED",             // не ACTIVE/COMPLETED → не в счётчике
      location:    "Россия",
      emoji:       "📋",
      ownerId:     user1.id,
      members: { create: [{ userId: user1.id, role: "OWNER" }] },
    },
  });

  // ── Статьи ───────────────────────────────────────────────────────
  // Елена (leader1) — 2 статьи → карточка активная
  await prisma.article.upsert({
    where:  { slug: "ekologiya-i-bezopasnost" },
    update: {},
    create: {
      title:     "Экология и безопасность труда: точки пересечения",
      slug:      "ekologiya-i-bezopasnost",
      lead:      "Как экологические риски влияют на здоровье работников и что с этим делать.",
      content:   [
        { type: "paragraph", text: "Промышленная экология и охрана труда долгое время развивались параллельно." },
        { type: "heading",   text: "Общие риски" },
        { type: "paragraph", text: "Загрязнение воздуха, воды и почвы напрямую влияет на здоровье персонала." },
      ],
      tag:       "ecology",
      status:    "PUBLISHED",
      readTime:  6,
      views:     847,
      likes:     34,
      authorId:  leader1.id,
      projectId: project2.id,
    },
  });

  await prisma.article.upsert({
    where:  { slug: "iso-14001-praktika" },
    update: {},
    create: {
      title:     "ISO 14001 на практике: опыт внедрения",
      slug:      "iso-14001-praktika",
      lead:      "Пошаговый опыт сертификации на примере предприятия в Ленинградской области.",
      content:   [
        { type: "paragraph", text: "Мы прошли путь от решения до сертификата за 14 месяцев." },
      ],
      tag:       "iso",
      status:    "PUBLISHED",
      readTime:  9,
      views:     1204,
      likes:     67,
      authorId:  leader1.id,
    },
  });

  // Мария (leader2) — 1 статья → карточка активная
  await prisma.article.upsert({
    where:  { slug: "kak-vovlech-sotrudnikov" },
    update: {},
    create: {
      title:     "Как вовлечь сотрудников в культуру безопасности",
      slug:      "kak-vovlech-sotrudnikov",
      lead:      "Практические инструменты для формирования проактивного поведения в области ОТ.",
      content:   [
        { type: "paragraph", text: "Вовлечённость — ключевой фактор снижения травматизма." },
        { type: "heading",   text: "Инструменты" },
        { type: "list",      items: ["Регулярные диалоги о безопасности", "Система наблюдений", "Геймификация"] },
      ],
      tag:       "safety",
      status:    "PUBLISHED",
      readTime:  7,
      views:     623,
      likes:     28,
      authorId:  leader2.id,
    },
  });

  // Дмитрий (leader3) — 1 статья → карточка активная
  await prisma.article.upsert({
    where:  { slug: "iso-50001-investitsiya" },
    update: {},
    create: {
      title:     "ISO 50001: инвестиция, а не затрата",
      slug:      "iso-50001-investitsiya",
      lead:      "Разбираем ROI системы энергоменеджмента на реальных данных.",
      content:   [
        { type: "paragraph", text: "Средняя окупаемость системы — 2.5 года при правильном внедрении." },
      ],
      tag:       "energy",
      status:    "PUBLISHED",
      readTime:  8,
      views:     445,
      likes:     19,
      authorId:  leader3.id,
    },
  });

  // Анна (leader4) — НЕТ статей → карточка неактивная (правильное поведение)

  console.log("\n✅  Seed complete!");
  console.log("─────────────────────────────────────────────");
  console.log("  admin@ecosfera.ru    / password123  (ADMIN)");
  console.log("  elena@ecosfera.ru    / password123  (LEADER, 2 статьи)");
  console.log("  maria@ecosfera.ru    / password123  (LEADER, 1 статья)");
  console.log("  dmitry@ecosfera.ru   / password123  (LEADER, 1 статья)");
  console.log("  anna@ecosfera.ru     / password123  (LEADER, 0 статей → неактивна)");
  console.log("  user@ecosfera.ru     / password123  (USER)");
  console.log("─────────────────────────────────────────────");
  console.log("  Проекты (4 одобренных в 3 странах):");
  console.log("    Россия    — 2 проекта → 1 пин");
  console.log("    Германия  — 1 проект  → 1 пин");
  console.log("    Казахстан — 1 проект  → 1 пин");
  console.log("  + 1 черновой проект (не в счётчике)");
  console.log("─────────────────────────────────────────────");
  console.log("  GET /stats/public     → users:6, projects:4, countries:3");
  console.log("  GET /users/leaders    → 4 лидера (Анна — articlesCount:0)");
}

main()
  .catch(console.error)
  .finally(() => prisma.$disconnect());

  // ── Треки ────────────────────────────────────────────────────
  const tracksData = [
    { title: "Звуки природы",     artist: "ЭкоСфера Band",    duration: "3:42", durationSec: 222, likes: 847,  emoji: "🌿", isNew: true,  sortOrder: 0 },
    { title: "Безопасный путь",   artist: "Алексей Волков",   duration: "4:15", durationSec: 255, likes: 623,  emoji: "🛤️", isNew: true,  sortOrder: 1 },
    { title: "Культура будущего", artist: "Мария Козлова",    duration: "5:02", durationSec: 302, likes: 1204, emoji: "🌟", isNew: false, sortOrder: 2 },
    { title: "Зелёная энергия",   artist: "Дмитрий Орлов",   duration: "3:28", durationSec: 208, likes: 445,  emoji: "⚡", isNew: false, sortOrder: 3 },
    { title: "Живая планета",     artist: "ЭкоСфера Хор",    duration: "6:11", durationSec: 371, likes: 980,  emoji: "🌍", isNew: false, sortOrder: 4 },
  ];

  for (const t of tracksData) {
    await prisma.track.upsert({
      where: { id: `seed-track-${t.sortOrder}` },
      update: {},
      create: { id: `seed-track-${t.sortOrder}`, ...t },
    });
  }

  // ── Галерея ──────────────────────────────────────────────────
  const galleryData = [
    { title: "Культура безопасности", imageUrl: "https://images.unsplash.com/photo-1504711434969-e33886168f5c?w=800&q=80", type: "GRID",    sortOrder: 0 },
    { title: "Жизнь леса",            imageUrl: "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=800&q=80", type: "GRID",    sortOrder: 1 },
    { title: "Чистый воздух",         imageUrl: "https://images.unsplash.com/photo-1497436072909-60f360e1d4b1?w=800&q=80", type: "GRID",    sortOrder: 2 },
    { title: "Зелёная планета",       imageUrl: "https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?w=800&q=80", type: "GRID",    sortOrder: 3 },
    { title: "Природа под защитой",   imageUrl: "https://images.unsplash.com/photo-1465146344425-f00d5f5c8f07?w=800&q=80", type: "GRID",    sortOrder: 4 },
    { title: "Истории безопасности",  imageUrl: "https://images.unsplash.com/photo-1504711434969-e33886168f5c?w=1200&q=80", type: "CASCADE", sortOrder: 0 },
    { title: "Экосистема",            imageUrl: "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=1200&q=80", type: "CASCADE", sortOrder: 1 },
    { title: "Будущее планеты",       imageUrl: "https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?w=1200&q=80", type: "CASCADE", sortOrder: 2 },
  ];

  for (const g of galleryData) {
    await prisma.galleryItem.upsert({
      where: { id: `seed-gallery-${g.type}-${g.sortOrder}` },
      update: {},
      create: { id: `seed-gallery-${g.type}-${g.sortOrder}`, ...g },
    });
  }

  // ── Новости ──────────────────────────────────────────────────
  await prisma.news.upsert({
    where: { id: "seed-news-1" },
    update: {},
    create: {
      id:         "seed-news-1",
      title:      "ЭкоСфера Безопасности достигла 12 000 участников",
      headline:   "Портал культуры безопасности объединил экспертов из 94 стран",
      body:       "С момента запуска платформы прошло два года. За это время сообщество выросло до 12 тысяч специалистов по охране труда, экологии и промышленной безопасности.",
      category:   "Проекты",
      isSplash:   true,
      authorName: "Редакция ЭкоСферы",
      readTime:   3,
      status:     "PUBLISHED",
      authorId:   admin.id,
    },
  });

  await prisma.news.upsert({
    where: { id: "seed-news-2" },
    update: {},
    create: {
      id:         "seed-news-2",
      title:      "Новые требования ISO 45001:2026 — что изменилось",
      headline:   "Обновлённый стандарт охраны труда вступает в силу с января 2026",
      body:       "Международная организация по стандартизации опубликовала обновлённую версию стандарта ISO 45001. Ключевые изменения касаются оценки рисков и управления поставщиками.",
      category:   "Наука",
      isSplash:   false,
      authorName: "Александр Петров",
      readTime:   5,
      status:     "PUBLISHED",
      authorId:   admin.id,
    },
  });

  console.log("\n✅  Seed v5.0 complete — all models populated!");
