# ЭкоСфера Безопасности — MVP

**Next.js 14 + Node.js/Express + Prisma + PostgreSQL**  
MagniApps Tech · 2026

---

## Быстрый старт (Docker)

```bash
# 1. Скопируй переменные окружения
cp backend/.env.example  backend/.env
cp frontend/.env.example frontend/.env.local

# 2. Запусти всё одной командой
docker compose up --build

# 3. Засей тестовые данные
docker compose exec backend node prisma/seed.js
```

Открой **http://localhost:3000**

Тестовые аккаунты:
| Email                  | Пароль      | Роль   |
|------------------------|-------------|--------|
| admin@ecosfera.ru      | password123 | ADMIN  |
| editor@ecosfera.ru     | password123 | EDITOR |
| user@ecosfera.ru       | password123 | USER   |

---

## Локальная разработка (без Docker)

### Требования
- Node.js 20+
- PostgreSQL 14+ (или Docker только для БД)

### Backend

```bash
cd backend
cp .env.example .env
# Отредактируй DATABASE_URL в .env

npm install
npx prisma db push       # Применить схему
node prisma/seed.js      # Тестовые данные
npm run dev              # http://localhost:4000
```

### Frontend

```bash
cd frontend
cp .env.example .env.local
# NEXT_PUBLIC_API_URL=http://localhost:4000

npm install
npm run dev              # http://localhost:3000
```

---

## Структура проекта

```
ecosfera-mvp/
├── backend/
│   ├── prisma/
│   │   ├── schema.prisma       ← БД-схема (User, Article, Project, ...)
│   │   └── seed.js             ← Тестовые данные
│   ├── src/
│   │   ├── lib/
│   │   │   ├── prisma.js       ← Singleton клиент
│   │   │   ├── jwt.js          ← sign/verify access + refresh токенов
│   │   │   ├── errors.js       ← AppError, wrap(), errorHandler
│   │   │   └── schemas.js      ← Zod схемы валидации
│   │   ├── middleware/
│   │   │   └── auth.js         ← authenticate, requireRole
│   │   ├── routes/
│   │   │   ├── auth.js         ← /auth/*
│   │   │   ├── articles.js     ← /articles/*
│   │   │   ├── projects.js     ← /projects/*
│   │   │   └── users.js        ← /users/*
│   │   └── server.js           ← Express app entry
│   ├── Dockerfile
│   └── package.json
│
├── frontend/
│   ├── src/
│   │   ├── app/
│   │   │   ├── dashboard/
│   │   │   │   ├── layout.tsx          ← Sidebar + auth guard
│   │   │   │   ├── page.tsx            ← Главная dashboard
│   │   │   │   ├── articles/page.tsx   ← Список статей
│   │   │   │   ├── articles/new/       ← Создать статью
│   │   │   │   ├── drafts/page.tsx     ← Черновики
│   │   │   │   ├── projects/           ← Список + создать + детали
│   │   │   │   ├── stats/page.tsx      ← Recharts статистика
│   │   │   │   └── settings/page.tsx   ← Настройки профиля
│   │   │   ├── articles/[slug]/        ← Публичный ридер
│   │   │   ├── projects/[id]/          ← Публичная страница проекта
│   │   │   ├── login/page.tsx
│   │   │   └── register/page.tsx
│   │   ├── components/
│   │   │   ├── ui/index.tsx            ← Spinner, Alert, StatCard, ...
│   │   │   └── articles/
│   │   │       └── ArticleEditor.tsx   ← Block editor (paragraph/heading/quote/list)
│   │   └── lib/
│   │       ├── api.ts                  ← Fetch клиент + TypeScript типы
│   │       ├── auth-context.tsx        ← AuthProvider + useAuth + useRequireAuth
│   │       └── use-api.ts             ← useApi (GET) + useMutation (POST/PATCH/DELETE)
│   ├── Dockerfile
│   └── package.json
│
└── docker-compose.yml
```

---

## API Endpoints

### Auth
| Method | Path            | Auth | Описание              |
|--------|-----------------|------|-----------------------|
| POST   | /auth/register  | —    | Регистрация           |
| POST   | /auth/login     | —    | Вход                  |
| POST   | /auth/refresh   | —    | Обновить токен        |
| POST   | /auth/logout    | —    | Выйти                 |
| GET    | /auth/me        | ✓    | Текущий пользователь  |

### Articles
| Method | Path                 | Auth | Описание            |
|--------|----------------------|------|---------------------|
| GET    | /articles            | —    | Список (published)  |
| GET    | /articles/my         | ✓    | Мои (все статусы)   |
| GET    | /articles/:slug      | —    | Одна статья         |
| POST   | /articles            | ✓    | Создать             |
| PATCH  | /articles/:id        | ✓    | Обновить            |
| DELETE | /articles/:id        | ✓    | Удалить             |
| POST   | /articles/:id/like   | ✓    | Лайк                |

### Projects
| Method | Path                             | Auth | Описание           |
|--------|----------------------------------|------|--------------------|
| GET    | /projects                        | —    | Список             |
| GET    | /projects/:id                    | —    | Один проект        |
| POST   | /projects                        | ✓    | Создать            |
| PATCH  | /projects/:id                    | ✓    | Обновить (owner)   |
| DELETE | /projects/:id                    | ✓    | Удалить (owner)    |
| GET    | /projects/my/owned               | ✓    | Мои (owner)        |
| GET    | /projects/my/member              | ✓    | Где я участник     |
| POST   | /projects/:id/request            | ✓    | Подать заявку      |
| GET    | /projects/:id/requests           | ✓    | Заявки (owner)     |
| PATCH  | /projects/:id/requests/:reqId    | ✓    | Approve / Reject   |

### Users
| Method | Path                   | Auth | Описание           |
|--------|------------------------|------|--------------------|
| GET    | /users/:id             | —    | Публичный профиль  |
| GET    | /users/dashboard/stats | ✓    | Личная статистика  |
| PATCH  | /users/me              | ✓    | Обновить профиль   |

---

## Ключевые решения

| Проблема | Решение |
|----------|---------|
| Хардкод `ownerId` в теле запроса | ID берётся из JWT (`req.user.id`) — клиент не может подделать |
| Нет обработки ошибок | `AppError` + `wrap()` + централизованный `errorHandler` |
| `axios` без токена | Централизованный `api.ts` с `token` параметром |
| `any` повсюду | TypeScript типы для всех сущностей в `api.ts` |
| Нет валидации | Zod схемы на бэкенде + клиентская валидация в формах |
| Refresh токен не ротируется | Старый токен удаляется, выдаётся новый при каждом `/auth/refresh` |
| Дублирование loading/error | `useApi` + `useMutation` хуки — одна точка управления состоянием |

---

## Production checklist

- [ ] Сменить `JWT_SECRET` и `JWT_REFRESH_SECRET` на случайные 64+ символа
- [ ] Настроить `DATABASE_URL` для production PostgreSQL
- [ ] Добавить rate limiting (`express-rate-limit`)
- [ ] Настроить S3/Cloudinary для загрузки изображений
- [ ] Добавить HTTPS (nginx reverse proxy или Caddy)
- [ ] Настроить мониторинг (Sentry или аналог)
